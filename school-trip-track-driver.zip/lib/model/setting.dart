
class Setting {
  String? currencyCode;
  bool? showAds;
  bool? simpleMode;
  bool? otpRequired;
  bool? hideSchools;
  int? distanceToDropOff;
  int? distanceToPickup;
  int? distanceToSlowDown;
  Setting({
    this.currencyCode,
    this.showAds,
    this.simpleMode,
    this.otpRequired,
    this.hideSchools,
    this.distanceToDropOff,
    this.distanceToPickup,
    this.distanceToSlowDown,
  });

  Map<String, dynamic> toJson() {
    return {
      'currency_code': currencyCode,
      'allow_ads_in_driver_app': showAds,
      'simple_mode': simpleMode,
      'otp_required': otpRequired,
      'hide_schools': hideSchools,
      'distance_to_drop_off': distanceToDropOff,
      'distance_to_pick_up': distanceToPickup,
      'distance_to_slow_down': distanceToSlowDown,
    };
  }

  static Setting fromJson(json) {
    return Setting(
      currencyCode: json['currency_code'],
      showAds: json['allow_ads_in_driver_app'] != null
          ? (json['allow_ads_in_driver_app'] == 1 ? true : false)
          : false,
      simpleMode: json['simple_mode'] != null ? (json['simple_mode'] == 1
          ? true
          : false) : false,
      hideSchools: json['hide_schools'] != null ? (json['hide_schools'] == 1
          ? true
          : false) : false,
      distanceToDropOff: json['distance_to_drop_off'],
      distanceToPickup: json['distance_to_pick_up'],
      distanceToSlowDown: json['distance_to_slow_down'],
      otpRequired: json['otp_required'] != null ? (json['otp_required'] == 1
          ? true
          : false) : false,
    );
  }

}
