import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_de.dart';
import 'app_localizations_en.dart';
import 'app_localizations_es.dart';
import 'app_localizations_fr.dart';
import 'app_localizations_hi.dart';
import 'app_localizations_it.dart';
import 'app_localizations_pt.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('de'),
    Locale('en'),
    Locale('es'),
    Locale('fr'),
    Locale('hi'),
    Locale('it'),
    Locale('pt'),
  ];

  /// No description provided for @myProfile.
  ///
  /// In en, this message translates to:
  /// **'My Profile'**
  String get myProfile;

  /// No description provided for @changeLanguage.
  ///
  /// In en, this message translates to:
  /// **'Change Language'**
  String get changeLanguage;

  /// No description provided for @aboutApp.
  ///
  /// In en, this message translates to:
  /// **'About App'**
  String get aboutApp;

  /// No description provided for @addDocument.
  ///
  /// In en, this message translates to:
  /// **'Add Document'**
  String get addDocument;

  /// No description provided for @editDocument.
  ///
  /// In en, this message translates to:
  /// **'Edit Document'**
  String get editDocument;

  /// No description provided for @documentName.
  ///
  /// In en, this message translates to:
  /// **'Document name'**
  String get documentName;

  /// No description provided for @documentNameIsRequired.
  ///
  /// In en, this message translates to:
  /// **'Document name is required'**
  String get documentNameIsRequired;

  /// No description provided for @linkedDevices.
  ///
  /// In en, this message translates to:
  /// **'Linked devices'**
  String get linkedDevices;

  /// No description provided for @devices.
  ///
  /// In en, this message translates to:
  /// **'Devices'**
  String get devices;

  /// No description provided for @schools.
  ///
  /// In en, this message translates to:
  /// **'Schools'**
  String get schools;

  /// No description provided for @networkError.
  ///
  /// In en, this message translates to:
  /// **'Network error'**
  String get networkError;

  /// No description provided for @anyDevicesYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any devices yet.'**
  String get anyDevicesYet;

  /// No description provided for @anyStudentsYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any students.'**
  String get anyStudentsYet;

  /// No description provided for @anySchoolsYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any schools.'**
  String get anySchoolsYet;

  /// No description provided for @currentDevice.
  ///
  /// In en, this message translates to:
  /// **'Current device'**
  String get currentDevice;

  /// No description provided for @scanTicket.
  ///
  /// In en, this message translates to:
  /// **'Scan Ticket'**
  String get scanTicket;

  /// No description provided for @documentNumber.
  ///
  /// In en, this message translates to:
  /// **'Document number'**
  String get documentNumber;

  /// No description provided for @noTripsAssignedToYou.
  ///
  /// In en, this message translates to:
  /// **'No trips assigned to you yet.'**
  String get noTripsAssignedToYou;

  /// No description provided for @driverInformation.
  ///
  /// In en, this message translates to:
  /// **'Driver information'**
  String get driverInformation;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @continueText.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continueText;

  /// No description provided for @paymentMethods.
  ///
  /// In en, this message translates to:
  /// **'Payment methods'**
  String get paymentMethods;

  /// No description provided for @termsConditions.
  ///
  /// In en, this message translates to:
  /// **'Terms and Conditions'**
  String get termsConditions;

  /// No description provided for @login.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get login;

  /// No description provided for @logout.
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get logout;

  /// No description provided for @requestDelete.
  ///
  /// In en, this message translates to:
  /// **'Request Delete'**
  String get requestDelete;

  /// No description provided for @shareApp.
  ///
  /// In en, this message translates to:
  /// **'Share this App'**
  String get shareApp;

  /// No description provided for @basicInformation.
  ///
  /// In en, this message translates to:
  /// **'Basic information'**
  String get basicInformation;

  /// No description provided for @accountInformation.
  ///
  /// In en, this message translates to:
  /// **'Account information'**
  String get accountInformation;

  /// No description provided for @bankAccount.
  ///
  /// In en, this message translates to:
  /// **'Bank Account'**
  String get bankAccount;

  /// No description provided for @accountNumber.
  ///
  /// In en, this message translates to:
  /// **'Account Number'**
  String get accountNumber;

  /// No description provided for @pleaseEnterYourAccountNumber.
  ///
  /// In en, this message translates to:
  /// **'Please enter your account number'**
  String get pleaseEnterYourAccountNumber;

  /// No description provided for @pleaseEnterValidAccountNumber.
  ///
  /// In en, this message translates to:
  /// **'Please enter valid account number'**
  String get pleaseEnterValidAccountNumber;

  /// No description provided for @routingNumber.
  ///
  /// In en, this message translates to:
  /// **'Routing Number'**
  String get routingNumber;

  /// No description provided for @pleaseEnterYourRoutingNumber.
  ///
  /// In en, this message translates to:
  /// **'Please enter your routing number'**
  String get pleaseEnterYourRoutingNumber;

  /// No description provided for @pleaseEnterValidRoutingNumber.
  ///
  /// In en, this message translates to:
  /// **'Please enter valid routing number'**
  String get pleaseEnterValidRoutingNumber;

  /// No description provided for @accountHolderName.
  ///
  /// In en, this message translates to:
  /// **'Account Holder Name'**
  String get accountHolderName;

  /// No description provided for @pleaseEnterYourAccountName.
  ///
  /// In en, this message translates to:
  /// **'Please enter your account holder name'**
  String get pleaseEnterYourAccountName;

  /// No description provided for @bankName.
  ///
  /// In en, this message translates to:
  /// **'Bank Name'**
  String get bankName;

  /// No description provided for @pleaseEnterYourBankName.
  ///
  /// In en, this message translates to:
  /// **'Please enter your bank name'**
  String get pleaseEnterYourBankName;

  /// No description provided for @saveBankAccount.
  ///
  /// In en, this message translates to:
  /// **'Save Bank Account'**
  String get saveBankAccount;

  /// No description provided for @instantTransferMobileNumber.
  ///
  /// In en, this message translates to:
  /// **'Instant Transfer Mobile Number'**
  String get instantTransferMobileNumber;

  /// No description provided for @pleaseEnterValidMobileNumber.
  ///
  /// In en, this message translates to:
  /// **'Please enter your mobile number'**
  String get pleaseEnterValidMobileNumber;

  /// No description provided for @instantTransferMobileNetwork.
  ///
  /// In en, this message translates to:
  /// **'Instant Transfer Mobile Network'**
  String get instantTransferMobileNetwork;

  /// No description provided for @pleaseEnterYourInstantTransferMobileNetwork.
  ///
  /// In en, this message translates to:
  /// **'Please enter your instant transfer mobile network'**
  String get pleaseEnterYourInstantTransferMobileNetwork;

  /// No description provided for @save.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// No description provided for @preferredPaymentMethod.
  ///
  /// In en, this message translates to:
  /// **'Preferred Payment Method'**
  String get preferredPaymentMethod;

  /// No description provided for @cash.
  ///
  /// In en, this message translates to:
  /// **'Cash'**
  String get cash;

  /// No description provided for @mobileMoneyTransfer.
  ///
  /// In en, this message translates to:
  /// **'Mobile Money Transfer'**
  String get mobileMoneyTransfer;

  /// No description provided for @preferredPaymentMethodHasValidationProblems.
  ///
  /// In en, this message translates to:
  /// **'Preferred payment method has validation problems'**
  String get preferredPaymentMethodHasValidationProblems;

  /// No description provided for @wallet.
  ///
  /// In en, this message translates to:
  /// **'Wallet'**
  String get wallet;

  /// No description provided for @camera.
  ///
  /// In en, this message translates to:
  /// **'Camera'**
  String get camera;

  /// No description provided for @gallery.
  ///
  /// In en, this message translates to:
  /// **'Gallery'**
  String get gallery;

  /// No description provided for @balance.
  ///
  /// In en, this message translates to:
  /// **'Balance'**
  String get balance;

  /// No description provided for @history.
  ///
  /// In en, this message translates to:
  /// **'History'**
  String get history;

  /// No description provided for @myWalletBalance.
  ///
  /// In en, this message translates to:
  /// **'My Wallet Balance'**
  String get myWalletBalance;

  /// No description provided for @activeTrips.
  ///
  /// In en, this message translates to:
  /// **'Active Trips'**
  String get activeTrips;

  /// No description provided for @morningTrips.
  ///
  /// In en, this message translates to:
  /// **'Morning Trips'**
  String get morningTrips;

  /// No description provided for @afternoonTrips.
  ///
  /// In en, this message translates to:
  /// **'Afternoon Trips'**
  String get afternoonTrips;

  /// No description provided for @students.
  ///
  /// In en, this message translates to:
  /// **'Students'**
  String get students;

  /// No description provided for @trips.
  ///
  /// In en, this message translates to:
  /// **'Trips'**
  String get trips;

  /// No description provided for @tripTimeline.
  ///
  /// In en, this message translates to:
  /// **'Trip Timeline'**
  String get tripTimeline;

  /// No description provided for @tripDetails.
  ///
  /// In en, this message translates to:
  /// **'Trip Details'**
  String get tripDetails;

  /// No description provided for @startTrip.
  ///
  /// In en, this message translates to:
  /// **'Start Trip'**
  String get startTrip;

  /// No description provided for @ok.
  ///
  /// In en, this message translates to:
  /// **'OK'**
  String get ok;

  /// No description provided for @no.
  ///
  /// In en, this message translates to:
  /// **'No'**
  String get no;

  /// No description provided for @yes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get yes;

  /// No description provided for @areYouSureYouWantToStartTrip.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to start trip?'**
  String get areYouSureYouWantToStartTrip;

  /// No description provided for @yourAccountUnderReview.
  ///
  /// In en, this message translates to:
  /// **'Your account is under review'**
  String get yourAccountUnderReview;

  /// No description provided for @accountReviewMessage.
  ///
  /// In en, this message translates to:
  /// **'Your account is under review. You will be notified once your account is approved.'**
  String get accountReviewMessage;

  /// No description provided for @exit.
  ///
  /// In en, this message translates to:
  /// **'Exit'**
  String get exit;

  /// No description provided for @forgetPassword.
  ///
  /// In en, this message translates to:
  /// **'Forget Password'**
  String get forgetPassword;

  /// No description provided for @forgetOrChangePassword.
  ///
  /// In en, this message translates to:
  /// **'Forget or change password'**
  String get forgetOrChangePassword;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// No description provided for @enterYourEmail.
  ///
  /// In en, this message translates to:
  /// **'Enter your email'**
  String get enterYourEmail;

  /// No description provided for @endTrip.
  ///
  /// In en, this message translates to:
  /// **'End Trip'**
  String get endTrip;

  /// No description provided for @endTripConfirmation.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to end the trip?'**
  String get endTripConfirmation;

  /// No description provided for @onRoute.
  ///
  /// In en, this message translates to:
  /// **'On Route'**
  String get onRoute;

  /// No description provided for @welcomeBack.
  ///
  /// In en, this message translates to:
  /// **'Welcome Back'**
  String get welcomeBack;

  /// No description provided for @rememberMe.
  ///
  /// In en, this message translates to:
  /// **'Remember Me'**
  String get rememberMe;

  /// No description provided for @dontHaveAccount.
  ///
  /// In en, this message translates to:
  /// **'Don\'t have an account? '**
  String get dontHaveAccount;

  /// No description provided for @signUp.
  ///
  /// In en, this message translates to:
  /// **'Sign Up'**
  String get signUp;

  /// No description provided for @logoutWarning.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to logout?'**
  String get logoutWarning;

  /// No description provided for @signOut.
  ///
  /// In en, this message translates to:
  /// **'Sign Out'**
  String get signOut;

  /// No description provided for @youNeedToLoginToContinue.
  ///
  /// In en, this message translates to:
  /// **'You need to login to continue.'**
  String get youNeedToLoginToContinue;

  /// No description provided for @emailAddress.
  ///
  /// In en, this message translates to:
  /// **'Email Address'**
  String get emailAddress;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @confirmPassword.
  ///
  /// In en, this message translates to:
  /// **'Confirm Password'**
  String get confirmPassword;

  /// No description provided for @signUpText.
  ///
  /// In en, this message translates to:
  /// **'Please fill in the form below to create a new account.'**
  String get signUpText;

  /// No description provided for @userName.
  ///
  /// In en, this message translates to:
  /// **'User Name'**
  String get userName;

  /// No description provided for @pleaseEnterValidEmail.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid email'**
  String get pleaseEnterValidEmail;

  /// No description provided for @pleaseEnterYourEmail.
  ///
  /// In en, this message translates to:
  /// **'Please enter email'**
  String get pleaseEnterYourEmail;

  /// No description provided for @lastActive.
  ///
  /// In en, this message translates to:
  /// **'Last active  '**
  String get lastActive;

  /// No description provided for @resetPassword.
  ///
  /// In en, this message translates to:
  /// **'Reset Password'**
  String get resetPassword;

  /// No description provided for @anyNotificationsYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any notifications yet.'**
  String get anyNotificationsYet;

  /// No description provided for @markAllNotificationsAsSeen.
  ///
  /// In en, this message translates to:
  /// **'Mark all notifications as seen'**
  String get markAllNotificationsAsSeen;

  /// No description provided for @notifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get notifications;

  /// No description provided for @markAllAsRead.
  ///
  /// In en, this message translates to:
  /// **'Mark all as read'**
  String get markAllAsRead;

  /// No description provided for @orderStudents.
  ///
  /// In en, this message translates to:
  /// **'Order Students'**
  String get orderStudents;

  /// No description provided for @orderStudentsMessage.
  ///
  /// In en, this message translates to:
  /// **'You can order students manually or automatically'**
  String get orderStudentsMessage;

  /// No description provided for @automatic.
  ///
  /// In en, this message translates to:
  /// **'Automatic'**
  String get automatic;

  /// No description provided for @manual.
  ///
  /// In en, this message translates to:
  /// **'Manual'**
  String get manual;

  /// No description provided for @automaticOrderMessage.
  ///
  /// In en, this message translates to:
  /// **'Students will be ordered automatically'**
  String get automaticOrderMessage;

  /// No description provided for @manualOrderMessage.
  ///
  /// In en, this message translates to:
  /// **'You can order students manually by dragging and dropping them below'**
  String get manualOrderMessage;

  /// No description provided for @firstStop.
  ///
  /// In en, this message translates to:
  /// **'First Stop'**
  String get firstStop;

  /// No description provided for @lastStop.
  ///
  /// In en, this message translates to:
  /// **'Last Stop'**
  String get lastStop;

  /// No description provided for @chooseLastStop.
  ///
  /// In en, this message translates to:
  /// **'Choose Last Stop'**
  String get chooseLastStop;

  /// No description provided for @preview.
  ///
  /// In en, this message translates to:
  /// **'Preview'**
  String get preview;

  /// No description provided for @add.
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get add;

  /// No description provided for @legalDocuments.
  ///
  /// In en, this message translates to:
  /// **'Legal Documents'**
  String get legalDocuments;

  /// No description provided for @firstName.
  ///
  /// In en, this message translates to:
  /// **'First Name'**
  String get firstName;

  /// No description provided for @lastName.
  ///
  /// In en, this message translates to:
  /// **'Last Name'**
  String get lastName;

  /// No description provided for @phoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Phone Number'**
  String get phoneNumber;

  /// No description provided for @address.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get address;

  /// No description provided for @school.
  ///
  /// In en, this message translates to:
  /// **'School'**
  String get school;

  /// No description provided for @driverLicense.
  ///
  /// In en, this message translates to:
  /// **'Driver License Number'**
  String get driverLicense;

  /// No description provided for @fieldIsRequired.
  ///
  /// In en, this message translates to:
  /// **'This field is required'**
  String get fieldIsRequired;

  /// No description provided for @next.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get next;

  /// No description provided for @previous.
  ///
  /// In en, this message translates to:
  /// **'Previous'**
  String get previous;

  /// No description provided for @submit.
  ///
  /// In en, this message translates to:
  /// **'Submit'**
  String get submit;

  /// No description provided for @documentImage.
  ///
  /// In en, this message translates to:
  /// **'Document Image'**
  String get documentImage;

  /// No description provided for @currentLocationFarMessage.
  ///
  /// In en, this message translates to:
  /// **'Your current location is far from the first stop of the trip'**
  String get currentLocationFarMessage;

  /// No description provided for @currentLocation.
  ///
  /// In en, this message translates to:
  /// **'Current Location'**
  String get currentLocation;

  /// No description provided for @tripNotTodayMessage.
  ///
  /// In en, this message translates to:
  /// **'You can\'t start a trip that is not scheduled for today'**
  String get tripNotTodayMessage;

  /// No description provided for @areYouSureDeleteDevice.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to delete this device?'**
  String get areYouSureDeleteDevice;

  /// No description provided for @warning.
  ///
  /// In en, this message translates to:
  /// **'Warning'**
  String get warning;

  /// No description provided for @hi.
  ///
  /// In en, this message translates to:
  /// **'Hi'**
  String get hi;

  /// No description provided for @orderOfStopsNotGuaranteed.
  ///
  /// In en, this message translates to:
  /// **'The order of the stops is not guaranteed \nto be the same as below if you\n are using automatic ordering'**
  String get orderOfStopsNotGuaranteed;

  /// No description provided for @requestDeleteAccountMessage.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to request account deletion? If you request account deletion, your account will be deleted after 3 days. You can cancel the request if you login to your account in the upcoming 3 days'**
  String get requestDeleteAccountMessage;

  /// No description provided for @deleteAllNotifications.
  ///
  /// In en, this message translates to:
  /// **'Delete all notifications'**
  String get deleteAllNotifications;

  /// No description provided for @checkIn.
  ///
  /// In en, this message translates to:
  /// **'Check in'**
  String get checkIn;

  /// No description provided for @notShowUp.
  ///
  /// In en, this message translates to:
  /// **'Not show up'**
  String get notShowUp;

  /// No description provided for @studentNotShowUp.
  ///
  /// In en, this message translates to:
  /// **'Student not show up'**
  String get studentNotShowUp;

  /// No description provided for @studentCheckIn.
  ///
  /// In en, this message translates to:
  /// **'Student check in'**
  String get studentCheckIn;

  /// No description provided for @areYouSureMarkStudentAsNotShowUp.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to mark this student as not show up?'**
  String get areYouSureMarkStudentAsNotShowUp;

  /// No description provided for @areYouSurePickUpStudent.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to pick up this student?'**
  String get areYouSurePickUpStudent;

  /// No description provided for @didntReceiveCode.
  ///
  /// In en, this message translates to:
  /// **'Didn\'t receive the code?'**
  String get didntReceiveCode;

  /// No description provided for @resend.
  ///
  /// In en, this message translates to:
  /// **'RESEND'**
  String get resend;

  /// No description provided for @back.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get back;

  /// No description provided for @verify.
  ///
  /// In en, this message translates to:
  /// **'VERIFY'**
  String get verify;

  /// No description provided for @emailVerification.
  ///
  /// In en, this message translates to:
  /// **'Email Verification'**
  String get emailVerification;

  /// No description provided for @enterCode.
  ///
  /// In en, this message translates to:
  /// **'Enter the code sent to '**
  String get enterCode;

  /// No description provided for @invalidOtp.
  ///
  /// In en, this message translates to:
  /// **'Invalid OTP'**
  String get invalidOtp;

  /// No description provided for @resendCode.
  ///
  /// In en, this message translates to:
  /// **'Code resent'**
  String get resendCode;

  /// No description provided for @select.
  ///
  /// In en, this message translates to:
  /// **'Select Manually'**
  String get select;

  /// No description provided for @dismissStop.
  ///
  /// In en, this message translates to:
  /// **'Dismiss Stop'**
  String get dismissStop;

  /// No description provided for @areYouSureDismissStop.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to dismiss this stop? All students in this stop will miss the bus'**
  String get areYouSureDismissStop;

  /// No description provided for @endOfTrip.
  ///
  /// In en, this message translates to:
  /// **'You have reached the end of the trip'**
  String get endOfTrip;

  /// No description provided for @connectionError.
  ///
  /// In en, this message translates to:
  /// **'Error connecting to the server'**
  String get connectionError;

  /// No description provided for @needHelp.
  ///
  /// In en, this message translates to:
  /// **'Need Help? '**
  String get needHelp;

  /// No description provided for @contactUs.
  ///
  /// In en, this message translates to:
  /// **'Contact Us'**
  String get contactUs;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>[
    'ar',
    'de',
    'en',
    'es',
    'fr',
    'hi',
    'it',
    'pt',
  ].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar':
      return AppLocalizationsAr();
    case 'de':
      return AppLocalizationsDe();
    case 'en':
      return AppLocalizationsEn();
    case 'es':
      return AppLocalizationsEs();
    case 'fr':
      return AppLocalizationsFr();
    case 'hi':
      return AppLocalizationsHi();
    case 'it':
      return AppLocalizationsIt();
    case 'pt':
      return AppLocalizationsPt();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
