// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get myProfile => 'ملفي الشخصي';

  @override
  String get changeLanguage => 'تغيير اللغة';

  @override
  String get aboutApp => 'عن التطبيق';

  @override
  String get addDocument => 'إضافة مستند';

  @override
  String get editDocument => 'تعديل مستند';

  @override
  String get documentName => 'اسم المستند';

  @override
  String get documentNameIsRequired => 'اسم المستند مطلوب';

  @override
  String get linkedDevices => 'الأجهزة المتصلة';

  @override
  String get devices => 'الأجهزة';

  @override
  String get schools => 'المدارس';

  @override
  String get networkError => 'خطأ في الشبكة';

  @override
  String get anyDevicesYet => 'عذرًا... لا توجد أي أجهزة بعد.';

  @override
  String get anyStudentsYet => 'عذرًا... لا توجد أي بيانات طلاب.';

  @override
  String get anySchoolsYet => 'عذرًا... لا توجد أي مدارس.';

  @override
  String get currentDevice => 'الجهاز الحالي';

  @override
  String get scanTicket => 'مسح التذكرة';

  @override
  String get documentNumber => 'رقم المستند';

  @override
  String get noTripsAssignedToYou => 'لا توجد رحلات مخصصة لك بعد.';

  @override
  String get driverInformation => 'معلومات السائق';

  @override
  String get cancel => 'إلغاء';

  @override
  String get continueText => 'متابعة';

  @override
  String get paymentMethods => 'طرق الدفع';

  @override
  String get termsConditions => 'الشروط والأحكام';

  @override
  String get login => 'تسجيل الدخول';

  @override
  String get logout => 'تسجيل الخروج';

  @override
  String get requestDelete => 'طلب الحذف';

  @override
  String get shareApp => 'مشاركة هذا التطبيق';

  @override
  String get basicInformation => 'المعلومات الأساسية';

  @override
  String get accountInformation => 'معلومات الحساب';

  @override
  String get bankAccount => 'الحساب البنكي';

  @override
  String get accountNumber => 'رقم الحساب';

  @override
  String get pleaseEnterYourAccountNumber => 'الرجاء إدخال رقم حسابك';

  @override
  String get pleaseEnterValidAccountNumber => 'الرجاء إدخال رقم حساب صحيح';

  @override
  String get routingNumber => 'رقم التوجيه';

  @override
  String get pleaseEnterYourRoutingNumber =>
      'الرجاء إدخال رقم التوجيه الخاص بك';

  @override
  String get pleaseEnterValidRoutingNumber => 'الرجاء إدخال رقم توجيه صحيح';

  @override
  String get accountHolderName => 'اسم صاحب الحساب';

  @override
  String get pleaseEnterYourAccountName => 'الرجاء إدخال اسم صاحب الحساب';

  @override
  String get bankName => 'اسم البنك';

  @override
  String get pleaseEnterYourBankName => 'الرجاء إدخال اسم البنك الخاص بك';

  @override
  String get saveBankAccount => 'حفظ الحساب البنكي';

  @override
  String get instantTransferMobileNumber => 'رقم الهاتف للتحويل الفوري';

  @override
  String get pleaseEnterValidMobileNumber => 'الرجاء إدخال رقم هاتفك المحمول';

  @override
  String get instantTransferMobileNetwork =>
      'شبكة التحويل الفوري للهاتف المحمول';

  @override
  String get pleaseEnterYourInstantTransferMobileNetwork =>
      'الرجاء إدخال شبكة التحويل الفوري للهاتف المحمول';

  @override
  String get save => 'حفظ';

  @override
  String get preferredPaymentMethod => 'طريقة الدفع المفضلة';

  @override
  String get cash => 'نقدًا';

  @override
  String get mobileMoneyTransfer => 'تحويل الأموال عبر الهاتف المحمول';

  @override
  String get preferredPaymentMethodHasValidationProblems =>
      'طريقة الدفع المفضلة بها مشاكل في التحقق';

  @override
  String get wallet => 'المحفظة';

  @override
  String get camera => 'الكاميرا';

  @override
  String get gallery => 'المعرض';

  @override
  String get balance => 'الرصيد';

  @override
  String get history => 'السجل';

  @override
  String get myWalletBalance => 'رصيد محفظتي';

  @override
  String get activeTrips => 'الرحلات النشطة';

  @override
  String get morningTrips => 'رحلات الصباح';

  @override
  String get afternoonTrips => 'رحلات الظهيرة';

  @override
  String get students => 'الطلاب';

  @override
  String get trips => 'الرحلات';

  @override
  String get tripTimeline => 'الجدول الزمني للرحلة';

  @override
  String get tripDetails => 'تفاصيل الرحلة';

  @override
  String get startTrip => 'بدء الرحلة';

  @override
  String get ok => 'موافق';

  @override
  String get no => 'لا';

  @override
  String get yes => 'نعم';

  @override
  String get areYouSureYouWantToStartTrip =>
      'هل أنت متأكد من أنك تريد بدء الرحلة؟';

  @override
  String get yourAccountUnderReview => 'حسابك قيد المراجعة';

  @override
  String get accountReviewMessage =>
      'حسابك قيد المراجعة. سيتم إخطارك بمجرد الموافقة على حسابك.';

  @override
  String get exit => 'خروج';

  @override
  String get forgetPassword => 'نسيت كلمة المرور';

  @override
  String get forgetOrChangePassword => 'نسيت أو غير كلمة المرور';

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get enterYourEmail => 'أدخل بريدك الإلكتروني';

  @override
  String get endTrip => 'إنهاء الرحلة';

  @override
  String get endTripConfirmation => 'هل أنت متأكد من أنك تريد إنهاء الرحلة؟';

  @override
  String get onRoute => 'في الطريق';

  @override
  String get welcomeBack => 'مرحبًا بعودتك';

  @override
  String get rememberMe => 'تذكرني';

  @override
  String get dontHaveAccount => 'ليس لديك حساب؟ ';

  @override
  String get signUp => 'اشتراك';

  @override
  String get logoutWarning => 'هل أنت متأكد من أنك تريد تسجيل الخروج؟';

  @override
  String get signOut => 'تسجيل الخروج';

  @override
  String get youNeedToLoginToContinue => 'يجب عليك تسجيل الدخول للمتابعة.';

  @override
  String get emailAddress => 'عنوان البريد الإلكتروني';

  @override
  String get password => 'كلمة المرور';

  @override
  String get confirmPassword => 'تأكيد كلمة المرور';

  @override
  String get signUpText => 'يرجى ملء النموذج أدناه لإنشاء حساب جديد.';

  @override
  String get userName => 'اسم المستخدم';

  @override
  String get pleaseEnterValidEmail => 'الرجاء إدخال بريد إلكتروني صحيح';

  @override
  String get pleaseEnterYourEmail => 'الرجاء إدخال البريد الإلكتروني';

  @override
  String get lastActive => 'نشط آخر مرة ';

  @override
  String get resetPassword => 'إعادة تعيين كلمة المرور';

  @override
  String get anyNotificationsYet => 'عذرًا... لا توجد أي إشعارات بعد.';

  @override
  String get markAllNotificationsAsSeen => 'تحديد جميع الإشعارات كمقروءة';

  @override
  String get notifications => 'الإشعارات';

  @override
  String get markAllAsRead => 'تحديد الكل كمقروء';

  @override
  String get orderStudents => 'ترتيب الطلاب';

  @override
  String get orderStudentsMessage => 'يمكنك ترتيب الطلاب يدويًا أو تلقائيًا';

  @override
  String get automatic => 'تلقائي';

  @override
  String get manual => 'يدوي';

  @override
  String get automaticOrderMessage => 'سيتم ترتيب الطلاب تلقائيًا';

  @override
  String get manualOrderMessage =>
      'يمكنك ترتيب الطلاب يدويًا عن طريق سحبهم وإفلاتهم أدناه';

  @override
  String get firstStop => 'المحطة الأولى';

  @override
  String get lastStop => 'المحطة الأخيرة';

  @override
  String get chooseLastStop => 'اختر المحطة الأخيرة';

  @override
  String get preview => 'معاينة';

  @override
  String get add => 'إضافة';

  @override
  String get legalDocuments => 'المستندات القانونية';

  @override
  String get firstName => 'الاسم الأول';

  @override
  String get lastName => 'الاسم الأخير';

  @override
  String get phoneNumber => 'رقم الهاتف';

  @override
  String get address => 'العنوان';

  @override
  String get school => 'المدرسة';

  @override
  String get driverLicense => 'رقم رخصة القيادة';

  @override
  String get fieldIsRequired => 'هذا الحقل مطلوب';

  @override
  String get next => 'التالي';

  @override
  String get previous => 'السابق';

  @override
  String get submit => 'إرسال';

  @override
  String get documentImage => 'صورة المستند';

  @override
  String get currentLocationFarMessage =>
      'موقعك الحالي بعيد عن المحطة الأولى للرحلة';

  @override
  String get currentLocation => 'الموقع الحالي';

  @override
  String get tripNotTodayMessage => 'لا يمكنك بدء رحلة غير مجدولة لليوم';

  @override
  String get areYouSureDeleteDevice =>
      'هل أنت متأكد من أنك تريد حذف هذا الجهاز؟';

  @override
  String get warning => 'تحذير';

  @override
  String get hi => 'مرحبًا';

  @override
  String get orderOfStopsNotGuaranteed =>
      'ترتيب المحطات غير مضمون \nأن يكون كما هو موضح أدناه إذا كنت \nتستخدم الترتيب التلقائي';

  @override
  String get requestDeleteAccountMessage =>
      'هل أنت متأكد من أنك تريد طلب حذف الحساب؟ إذا طلبت حذف الحساب، سيتم حذف حسابك بعد 3 أيام. يمكنك إلغاء الطلب إذا قمت بتسجيل الدخول إلى حسابك خلال الأيام الثلاثة القادمة';

  @override
  String get deleteAllNotifications => 'حذف جميع الإشعارات';

  @override
  String get checkIn => 'تسجيل الحضور';

  @override
  String get notShowUp => 'لم يحضر';

  @override
  String get studentNotShowUp => 'الطالب لم يحضر';

  @override
  String get studentCheckIn => 'تسجيل حضور الطالب';

  @override
  String get areYouSureMarkStudentAsNotShowUp =>
      'هل أنت متأكد من أنك تريد تحديد هذا الطالب على أنه لم يحضر؟';

  @override
  String get areYouSurePickUpStudent =>
      'هل أنت متأكد من أنك تريد استلام هذا الطالب؟';

  @override
  String get didntReceiveCode => 'لم تستلم الرمز؟';

  @override
  String get resend => 'إعادة الإرسال';

  @override
  String get back => 'رجوع';

  @override
  String get verify => 'تحقق';

  @override
  String get emailVerification => 'التحقق من البريد الإلكتروني';

  @override
  String get enterCode => 'أدخل الرمز المرسل إلى ';

  @override
  String get invalidOtp => 'رمز OTP غير صالح';

  @override
  String get resendCode => 'تمت إعادة إرسال الرمز';

  @override
  String get select => 'اختر يدويًا';

  @override
  String get dismissStop => 'تجاهل المحطة';

  @override
  String get areYouSureDismissStop =>
      'هل أنت متأكد من أنك تريد تجاهل هذه المحطة؟ جميع الطلاب في هذه المحطة سيفوتون الحافلة';

  @override
  String get endOfTrip => 'لقد وصلت إلى نهاية الرحلة';

  @override
  String get connectionError => 'خطأ في الاتصال بالخادم';

  @override
  String get needHelp => 'هل تحتاج إلى مساعدة؟ ';

  @override
  String get contactUs => 'اتصل بنا';
}
