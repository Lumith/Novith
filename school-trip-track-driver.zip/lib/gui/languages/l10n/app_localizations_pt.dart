// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Portuguese (`pt`).
class AppLocalizationsPt extends AppLocalizations {
  AppLocalizationsPt([String locale = 'pt']) : super(locale);

  @override
  String get myProfile => 'Meu perfil';

  @override
  String get changeLanguage => 'Mudar idioma';

  @override
  String get aboutApp => 'Sobre o App';

  @override
  String get addDocument => 'Adicionar documento';

  @override
  String get editDocument => 'Editar documento';

  @override
  String get documentName => 'Nome do Documento';

  @override
  String get documentNameIsRequired => 'O nome do documento é obrigatório';

  @override
  String get linkedDevices => 'Dispositivos vinculados';

  @override
  String get devices => 'Dispositivos';

  @override
  String get schools => 'Escolas';

  @override
  String get networkError => 'Erro de rede';

  @override
  String get anyDevicesYet => 'Ops... Ainda não existem dispositivos.';

  @override
  String get anyStudentsYet => 'Ops... Ainda não há alunos.';

  @override
  String get anySchoolsYet => 'Ops... Não há escolas.';

  @override
  String get currentDevice => 'Dispositivo atual';

  @override
  String get scanTicket => 'Ler QR Code';

  @override
  String get documentNumber => 'Número do documento';

  @override
  String get noTripsAssignedToYou => 'Nenhuma viagem atribuída a você ainda.';

  @override
  String get driverInformation => 'Informações do motorista';

  @override
  String get cancel => 'Cancelar';

  @override
  String get continueText => 'Continue';

  @override
  String get paymentMethods => 'Métodos de Pagamento';

  @override
  String get termsConditions => 'Termos & Condições';

  @override
  String get login => 'Login';

  @override
  String get logout => 'Sair';

  @override
  String get requestDelete => 'Solicitar exclusão';

  @override
  String get shareApp => 'Compartilhe este App';

  @override
  String get basicInformation => 'Informação básica';

  @override
  String get accountInformation => 'Informação da conta';

  @override
  String get bankAccount => 'Conta bancária';

  @override
  String get accountNumber => 'Número da conta';

  @override
  String get pleaseEnterYourAccountNumber =>
      'Por favor insira o número da sua conta';

  @override
  String get pleaseEnterValidAccountNumber =>
      'Insira um número de conta válido';

  @override
  String get routingNumber => 'Número IBAN';

  @override
  String get pleaseEnterYourRoutingNumber => 'Por favor insira seu número IBAN';

  @override
  String get pleaseEnterValidRoutingNumber => 'Insira um número IBAN válido';

  @override
  String get accountHolderName => 'Nome do titular da conta';

  @override
  String get pleaseEnterYourAccountName =>
      'Por favor insira o nome do titular da conta';

  @override
  String get bankName => 'Nome do banco';

  @override
  String get pleaseEnterYourBankName => 'Por favor insira o nome do seu banco';

  @override
  String get saveBankAccount => 'Salvar conta bancária';

  @override
  String get instantTransferMobileNumber =>
      'Telefone para transferência express/Pix';

  @override
  String get pleaseEnterValidMobileNumber =>
      'Por favor, insira seu número de telefone';

  @override
  String get instantTransferMobileNetwork => 'Transferência express/Pix';

  @override
  String get pleaseEnterYourInstantTransferMobileNetwork =>
      'Por favor, insira telefone para transferência express/Pix';

  @override
  String get save => 'Salvar';

  @override
  String get preferredPaymentMethod => 'Método de pagamento preferido';

  @override
  String get cash => 'Dinheiro';

  @override
  String get mobileMoneyTransfer => 'Transferência Express/Pix';

  @override
  String get preferredPaymentMethodHasValidationProblems =>
      'O método de pagamento preferido tem problemas de validação';

  @override
  String get wallet => 'Carteira';

  @override
  String get camera => 'Camera';

  @override
  String get gallery => 'Galeria';

  @override
  String get balance => 'Balanço';

  @override
  String get history => 'Histórico';

  @override
  String get myWalletBalance => 'Balanço da minha carteira';

  @override
  String get activeTrips => 'Viagens ativas';

  @override
  String get morningTrips => 'Viagens da manhã';

  @override
  String get afternoonTrips => 'Viagens da tarde';

  @override
  String get students => 'Alunos';

  @override
  String get trips => 'Viagens';

  @override
  String get tripTimeline => 'Cronograma da viagem';

  @override
  String get tripDetails => 'Detalhes da viagem';

  @override
  String get startTrip => 'Iniciar viagem';

  @override
  String get ok => 'OK';

  @override
  String get no => 'Não';

  @override
  String get yes => 'Sim';

  @override
  String get areYouSureYouWantToStartTrip =>
      'Tem certeza de que deseja iniciar a viagem?';

  @override
  String get yourAccountUnderReview => 'Sua conta está em análise';

  @override
  String get accountReviewMessage =>
      'Sua conta está em análise. Você será notificado assim que sua conta for aprovada.';

  @override
  String get exit => 'Saída';

  @override
  String get forgetPassword => 'Esqueceu a senha';

  @override
  String get forgetOrChangePassword => 'Esquecer ou alterar a senha';

  @override
  String get email => 'Email';

  @override
  String get enterYourEmail => 'Digite seu e-mail';

  @override
  String get endTrip => 'Finalizar viagem';

  @override
  String get endTripConfirmation =>
      'Tem certeza de que deseja encerrar a viagem?';

  @override
  String get onRoute => 'Na rota';

  @override
  String get welcomeBack => 'Bem vindo de volta';

  @override
  String get rememberMe => 'Lembre de mim';

  @override
  String get dontHaveAccount => 'Não tem uma conta?';

  @override
  String get signUp => 'Inscrever-se';

  @override
  String get logoutWarning => 'Tem certeza que deseja sair?';

  @override
  String get signOut => 'Sair';

  @override
  String get youNeedToLoginToContinue =>
      'Você precisa fazer login para continuar.';

  @override
  String get emailAddress => 'Endereço de email';

  @override
  String get password => 'Senha';

  @override
  String get confirmPassword => 'Confirme sua senha';

  @override
  String get signUpText =>
      'Por favor preencha o formulário abaixo para criar uma nova conta.';

  @override
  String get userName => 'Nome de usuário';

  @override
  String get pleaseEnterValidEmail => 'Por favor digite um email válido';

  @override
  String get pleaseEnterYourEmail => 'Por favor insira o e-mail';

  @override
  String get lastActive => 'Ativo pela última vez';

  @override
  String get resetPassword => 'Redefinir senha';

  @override
  String get anyNotificationsYet => 'Ops... Ainda não há notificações.';

  @override
  String get markAllNotificationsAsSeen =>
      'Marcar todas as notificações como vistas';

  @override
  String get notifications => 'Notificações';

  @override
  String get markAllAsRead => 'Marcar tudo como lido';

  @override
  String get orderStudents => 'Pedir alunos';

  @override
  String get orderStudentsMessage =>
      'Você pode solicitar alunos\n manualmente ou automaticamente';

  @override
  String get automatic => 'Automático';

  @override
  String get manual => 'Manual';

  @override
  String get automaticOrderMessage =>
      'Os alunos serão ordenados automaticamente';

  @override
  String get manualOrderMessage =>
      'Você pode ordenar os alunos manualmente arrastando e soltando-os abaixo';

  @override
  String get firstStop => 'Primeira parada';

  @override
  String get lastStop => 'Última parada';

  @override
  String get chooseLastStop => 'Escolha a última parada';

  @override
  String get preview => 'Visualização';

  @override
  String get add => 'Adicionar';

  @override
  String get legalDocuments => 'Documentos legais';

  @override
  String get firstName => 'Nome';

  @override
  String get lastName => 'Sobrenome';

  @override
  String get phoneNumber => 'Número de telefone';

  @override
  String get address => 'Endereço';

  @override
  String get school => 'Escola';

  @override
  String get driverLicense => 'Carteira de motorista';

  @override
  String get fieldIsRequired => 'Este campo é obrigatório';

  @override
  String get next => 'Próximo';

  @override
  String get previous => 'Anterior';

  @override
  String get submit => 'Enviar';

  @override
  String get documentImage => 'Imagem do documento';

  @override
  String get currentLocationFarMessage =>
      'Sua localização atual está longe da primeira parada da viagem';

  @override
  String get currentLocation => 'Localização atual';

  @override
  String get tripNotTodayMessage =>
      'Você não pode iniciar uma viagem que não está agendada para hoje';

  @override
  String get areYouSureDeleteDevice =>
      'Tem certeza de que deseja excluir este dispositivo?';

  @override
  String get warning => 'Aviso';

  @override
  String get hi => 'Oi';

  @override
  String get orderOfStopsNotGuaranteed =>
      'A ordem das paradas não é garantida \npara ser a mesma que abaixo se você\n estiver usando a ordenação automática';

  @override
  String get requestDeleteAccountMessage =>
      'Tem certeza de que deseja solicitar a exclusão da conta? Se você solicitar a exclusão da conta, sua conta será excluída após 3 dias. Você pode cancelar a solicitação se fizer login em sua conta nos próximos 3 dias';

  @override
  String get deleteAllNotifications => 'Excluir todas as notificações';

  @override
  String get checkIn => 'Check in';

  @override
  String get notShowUp => 'Not show up';

  @override
  String get studentNotShowUp => 'Student not show up';

  @override
  String get studentCheckIn => 'Student check in';

  @override
  String get areYouSureMarkStudentAsNotShowUp =>
      'Are you sure you want to mark this student as not show up?';

  @override
  String get areYouSurePickUpStudent =>
      'Are you sure you want to pick up this student?';

  @override
  String get didntReceiveCode => 'Didn\'t receive the code?';

  @override
  String get resend => 'RESEND';

  @override
  String get back => 'Back';

  @override
  String get verify => 'VERIFY';

  @override
  String get emailVerification => 'Email Verification';

  @override
  String get enterCode => 'Enter the code sent to ';

  @override
  String get invalidOtp => 'Invalid OTP';

  @override
  String get resendCode => 'Code resent';

  @override
  String get select => 'Select Manually';

  @override
  String get dismissStop => 'Dismiss Stop';

  @override
  String get areYouSureDismissStop =>
      'Are you sure you want to dismiss this stop? All students in this stop will miss the bus';

  @override
  String get endOfTrip => 'You have reached the end of the trip';

  @override
  String get connectionError => 'Error connecting to the server';

  @override
  String get needHelp => 'Need Help? ';

  @override
  String get contactUs => 'Contact Us';
}
