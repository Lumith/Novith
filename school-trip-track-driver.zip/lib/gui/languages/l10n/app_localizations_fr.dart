// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get myProfile => 'Mon profil';

  @override
  String get changeLanguage => 'Changer de langue';

  @override
  String get aboutApp => 'À propos de l\'application';

  @override
  String get addDocument => 'Ajouter un document';

  @override
  String get editDocument => 'Modifier le document';

  @override
  String get documentName => 'Nom du document';

  @override
  String get documentNameIsRequired => 'Le nom du document est requis';

  @override
  String get linkedDevices => 'Appareils liés';

  @override
  String get devices => 'Appareils';

  @override
  String get schools => 'Écoles';

  @override
  String get networkError => 'Erreur réseau';

  @override
  String get anyDevicesYet => 'Oups... Il n\'y a encore aucun appareil.';

  @override
  String get anyStudentsYet => 'Oups... Il n\'y a aucun étudiant.';

  @override
  String get anySchoolsYet => 'Oups... Il n\'y a aucune école.';

  @override
  String get currentDevice => 'Appareil actuel';

  @override
  String get scanTicket => 'Scanner le ticket';

  @override
  String get documentNumber => 'Numéro du document';

  @override
  String get noTripsAssignedToYou => 'Aucun trajet ne vous est encore assigné.';

  @override
  String get driverInformation => 'Informations du conducteur';

  @override
  String get cancel => 'Annuler';

  @override
  String get continueText => 'Continuer';

  @override
  String get paymentMethods => 'Moyens de paiement';

  @override
  String get termsConditions => 'Conditions générales';

  @override
  String get login => 'Connexion';

  @override
  String get logout => 'Déconnexion';

  @override
  String get requestDelete => 'Demander la suppression';

  @override
  String get shareApp => 'Partager cette application';

  @override
  String get basicInformation => 'Informations de base';

  @override
  String get accountInformation => 'Informations du compte';

  @override
  String get bankAccount => 'Compte bancaire';

  @override
  String get accountNumber => 'Numéro de compte';

  @override
  String get pleaseEnterYourAccountNumber =>
      'Veuillez saisir votre numéro de compte';

  @override
  String get pleaseEnterValidAccountNumber =>
      'Veuillez saisir un numéro de compte valide';

  @override
  String get routingNumber => 'Numéro de routage';

  @override
  String get pleaseEnterYourRoutingNumber =>
      'Veuillez saisir votre numéro de routage';

  @override
  String get pleaseEnterValidRoutingNumber =>
      'Veuillez saisir un numéro de routage valide';

  @override
  String get accountHolderName => 'Nom du titulaire du compte';

  @override
  String get pleaseEnterYourAccountName =>
      'Veuillez saisir le nom du titulaire du compte';

  @override
  String get bankName => 'Nom de la banque';

  @override
  String get pleaseEnterYourBankName =>
      'Veuillez saisir le nom de votre banque';

  @override
  String get saveBankAccount => 'Enregistrer le compte bancaire';

  @override
  String get instantTransferMobileNumber =>
      'Numéro de mobile pour transfert instantané';

  @override
  String get pleaseEnterValidMobileNumber =>
      'Veuillez saisir votre numéro de mobile';

  @override
  String get instantTransferMobileNetwork =>
      'Réseau mobile pour transfert instantané';

  @override
  String get pleaseEnterYourInstantTransferMobileNetwork =>
      'Veuillez saisir votre réseau mobile pour transfert instantané';

  @override
  String get save => 'Enregistrer';

  @override
  String get preferredPaymentMethod => 'Moyen de paiement préféré';

  @override
  String get cash => 'Espèces';

  @override
  String get mobileMoneyTransfer => 'Transfert d\'argent mobile';

  @override
  String get preferredPaymentMethodHasValidationProblems =>
      'Le moyen de paiement préféré a des problèmes de validation';

  @override
  String get wallet => 'Portefeuille';

  @override
  String get camera => 'Appareil photo';

  @override
  String get gallery => 'Galerie';

  @override
  String get balance => 'Solde';

  @override
  String get history => 'Historique';

  @override
  String get myWalletBalance => 'Solde de mon portefeuille';

  @override
  String get activeTrips => 'Trajets actifs';

  @override
  String get morningTrips => 'Trajets du matin';

  @override
  String get afternoonTrips => 'Trajets de l\'après-midi';

  @override
  String get students => 'Élèves';

  @override
  String get trips => 'Trajets';

  @override
  String get tripTimeline => 'Chronologie du trajet';

  @override
  String get tripDetails => 'Détails du trajet';

  @override
  String get startTrip => 'Démarrer le trajet';

  @override
  String get ok => 'OK';

  @override
  String get no => 'Non';

  @override
  String get yes => 'Oui';

  @override
  String get areYouSureYouWantToStartTrip =>
      'Êtes-vous sûr de vouloir démarrer le trajet ?';

  @override
  String get yourAccountUnderReview => 'Votre compte est en cours d\'examen';

  @override
  String get accountReviewMessage =>
      'Votre compte est en cours d\'examen. Vous serez informé une fois votre compte approuvé.';

  @override
  String get exit => 'Quitter';

  @override
  String get forgetPassword => 'Mot de passe oublié';

  @override
  String get forgetOrChangePassword =>
      'Mot de passe oublié ou changement de mot de passe';

  @override
  String get email => 'E-mail';

  @override
  String get enterYourEmail => 'Saisissez votre e-mail';

  @override
  String get endTrip => 'Terminer le trajet';

  @override
  String get endTripConfirmation =>
      'Êtes-vous sûr de vouloir terminer le trajet ?';

  @override
  String get onRoute => 'En route';

  @override
  String get welcomeBack => 'Bon retour';

  @override
  String get rememberMe => 'Se souvenir de moi';

  @override
  String get dontHaveAccount => 'Vous n\'avez pas de compte ? ';

  @override
  String get signUp => 'S\'inscrire';

  @override
  String get logoutWarning => 'Êtes-vous sûr de vouloir vous déconnecter ?';

  @override
  String get signOut => 'Se déconnecter';

  @override
  String get youNeedToLoginToContinue =>
      'Vous devez vous connecter pour continuer.';

  @override
  String get emailAddress => 'Adresse e-mail';

  @override
  String get password => 'Mot de passe';

  @override
  String get confirmPassword => 'Confirmer le mot de passe';

  @override
  String get signUpText =>
      'Veuillez remplir le formulaire ci-dessous pour créer un nouveau compte.';

  @override
  String get userName => 'Nom d\'utilisateur';

  @override
  String get pleaseEnterValidEmail => 'Veuillez saisir un e-mail valide';

  @override
  String get pleaseEnterYourEmail => 'Veuillez saisir l\'e-mail';

  @override
  String get lastActive => 'Dernière activité ';

  @override
  String get resetPassword => 'Réinitialiser le mot de passe';

  @override
  String get anyNotificationsYet =>
      'Oups... Il n\'y a encore aucune notification.';

  @override
  String get markAllNotificationsAsSeen =>
      'Marquer toutes les notifications comme vues';

  @override
  String get notifications => 'Notifications';

  @override
  String get markAllAsRead => 'Tout marquer comme lu';

  @override
  String get orderStudents => 'Ordonner les élèves';

  @override
  String get orderStudentsMessage =>
      'Vous pouvez ordonner les élèves manuellement ou automatiquement';

  @override
  String get automatic => 'Automatique';

  @override
  String get manual => 'Manuel';

  @override
  String get automaticOrderMessage =>
      'Les élèves seront ordonnés automatiquement';

  @override
  String get manualOrderMessage =>
      'Vous pouvez ordonner les élèves manuellement en les faisant glisser ci-dessous';

  @override
  String get firstStop => 'Premier arrêt';

  @override
  String get lastStop => 'Dernier arrêt';

  @override
  String get chooseLastStop => 'Choisir le dernier arrêt';

  @override
  String get preview => 'Aperçu';

  @override
  String get add => 'Ajouter';

  @override
  String get legalDocuments => 'Documents légaux';

  @override
  String get firstName => 'Prénom';

  @override
  String get lastName => 'Nom';

  @override
  String get phoneNumber => 'Numéro de téléphone';

  @override
  String get address => 'Adresse';

  @override
  String get school => 'École';

  @override
  String get driverLicense => 'Numéro de permis de conduire';

  @override
  String get fieldIsRequired => 'Ce champ est requis';

  @override
  String get next => 'Suivant';

  @override
  String get previous => 'Précédent';

  @override
  String get submit => 'Soumettre';

  @override
  String get documentImage => 'Image du document';

  @override
  String get currentLocationFarMessage =>
      'Votre position actuelle est éloignée du premier arrêt du trajet';

  @override
  String get currentLocation => 'Position actuelle';

  @override
  String get tripNotTodayMessage =>
      'Vous ne pouvez pas démarrer un trajet qui n\'est pas prévu pour aujourd\'hui';

  @override
  String get areYouSureDeleteDevice =>
      'Êtes-vous sûr de vouloir supprimer cet appareil ?';

  @override
  String get warning => 'Avertissement';

  @override
  String get hi => 'Bonjour';

  @override
  String get orderOfStopsNotGuaranteed =>
      'L\'ordre des arrêts n\'est pas garanti \nd\'être le même que ci-dessous si vous \nutilisez l\'ordonnancement automatique';

  @override
  String get requestDeleteAccountMessage =>
      'Êtes-vous sûr de vouloir demander la suppression du compte ? Si vous demandez la suppression du compte, votre compte sera supprimé après 3 jours. Vous pouvez annuler la demande si vous vous connectez à votre compte dans les 3 prochains jours';

  @override
  String get deleteAllNotifications => 'Supprimer toutes les notifications';

  @override
  String get checkIn => 'Enregistrement';

  @override
  String get notShowUp => 'Ne s\'est pas présenté';

  @override
  String get studentNotShowUp => 'L\'élève ne s\'est pas présenté';

  @override
  String get studentCheckIn => 'Enregistrement de l\'élève';

  @override
  String get areYouSureMarkStudentAsNotShowUp =>
      'Êtes-vous sûr de vouloir marquer cet élève comme absent ?';

  @override
  String get areYouSurePickUpStudent =>
      'Êtes-vous sûr de vouloir prendre en charge cet élève ?';

  @override
  String get didntReceiveCode => 'Vous n\'avez pas reçu le code ?';

  @override
  String get resend => 'RENVOYER';

  @override
  String get back => 'Retour';

  @override
  String get verify => 'VÉRIFIER';

  @override
  String get emailVerification => 'Vérification de l\'e-mail';

  @override
  String get enterCode => 'Saisissez le code envoyé à ';

  @override
  String get invalidOtp => 'OTP invalide';

  @override
  String get resendCode => 'Code renvoyé';

  @override
  String get select => 'Sélectionner manuellement';

  @override
  String get dismissStop => 'Ignorer l\'arrêt';

  @override
  String get areYouSureDismissStop =>
      'Êtes-vous sûr de vouloir ignorer cet arrêt ? Tous les élèves de cet arrêt manqueront le bus';

  @override
  String get endOfTrip => 'Vous avez atteint la fin du trajet';

  @override
  String get connectionError => 'Erreur de connexion au serveur';

  @override
  String get needHelp => 'Besoin d\'aide ? ';

  @override
  String get contactUs => 'Contactez-nous';
}
