// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Hindi (`hi`).
class AppLocalizationsHi extends AppLocalizations {
  AppLocalizationsHi([String locale = 'hi']) : super(locale);

  @override
  String get myProfile => 'मेरी प्रोफ़ाइल';

  @override
  String get changeLanguage => 'भाषा बदलो';

  @override
  String get aboutApp => 'About App';

  @override
  String get addDocument => 'Add Document';

  @override
  String get editDocument => 'Edit Document';

  @override
  String get documentName => 'Document name';

  @override
  String get documentNameIsRequired => 'Document name is required';

  @override
  String get linkedDevices => 'Linked devices';

  @override
  String get devices => 'Devices';

  @override
  String get schools => 'Schools';

  @override
  String get networkError => 'Network error';

  @override
  String get anyDevicesYet => 'Oops... There aren\'t any devices yet.';

  @override
  String get anyStudentsYet => 'Oops... There aren\'t any students.';

  @override
  String get anySchoolsYet => 'Oops... There aren\'t any schools.';

  @override
  String get currentDevice => 'Current device';

  @override
  String get scanTicket => 'Scan Ticket';

  @override
  String get documentNumber => 'Document number';

  @override
  String get noTripsAssignedToYou => 'No trips assigned to you yet.';

  @override
  String get driverInformation => 'Driver information';

  @override
  String get cancel => 'Cancel';

  @override
  String get continueText => 'Continue';

  @override
  String get paymentMethods => 'Payment methods';

  @override
  String get termsConditions => 'Terms and Conditions';

  @override
  String get login => 'Login';

  @override
  String get logout => 'Logout';

  @override
  String get requestDelete => 'Request Delete';

  @override
  String get shareApp => 'Share this App';

  @override
  String get basicInformation => 'Basic information';

  @override
  String get accountInformation => 'Account information';

  @override
  String get bankAccount => 'Bank Account';

  @override
  String get accountNumber => 'Account Number';

  @override
  String get pleaseEnterYourAccountNumber => 'Please enter your account number';

  @override
  String get pleaseEnterValidAccountNumber =>
      'Please enter valid account number';

  @override
  String get routingNumber => 'Routing Number';

  @override
  String get pleaseEnterYourRoutingNumber => 'Please enter your routing number';

  @override
  String get pleaseEnterValidRoutingNumber =>
      'Please enter valid routing number';

  @override
  String get accountHolderName => 'Account Holder Name';

  @override
  String get pleaseEnterYourAccountName =>
      'Please enter your account holder name';

  @override
  String get bankName => 'Bank Name';

  @override
  String get pleaseEnterYourBankName => 'Please enter your bank name';

  @override
  String get saveBankAccount => 'Save Bank Account';

  @override
  String get instantTransferMobileNumber => 'Instant Transfer Mobile Number';

  @override
  String get pleaseEnterValidMobileNumber => 'Please enter your mobile number';

  @override
  String get instantTransferMobileNetwork => 'Instant Transfer Mobile Network';

  @override
  String get pleaseEnterYourInstantTransferMobileNetwork =>
      'Please enter your instant transfer mobile network';

  @override
  String get save => 'Save';

  @override
  String get preferredPaymentMethod => 'Preferred Payment Method';

  @override
  String get cash => 'Cash';

  @override
  String get mobileMoneyTransfer => 'Mobile Money Transfer';

  @override
  String get preferredPaymentMethodHasValidationProblems =>
      'Preferred payment method has validation problems';

  @override
  String get wallet => 'Wallet';

  @override
  String get camera => 'Camera';

  @override
  String get gallery => 'Gallery';

  @override
  String get balance => 'Balance';

  @override
  String get history => 'History';

  @override
  String get myWalletBalance => 'My Wallet Balance';

  @override
  String get activeTrips => 'Active Trips';

  @override
  String get morningTrips => 'Morning Trips';

  @override
  String get afternoonTrips => 'Afternoon Trips';

  @override
  String get students => 'Students';

  @override
  String get trips => 'Trips';

  @override
  String get tripTimeline => 'Trip Timeline';

  @override
  String get tripDetails => 'Trip Details';

  @override
  String get startTrip => 'Start Trip';

  @override
  String get ok => 'OK';

  @override
  String get no => 'No';

  @override
  String get yes => 'Yes';

  @override
  String get areYouSureYouWantToStartTrip =>
      'Are you sure you want to start trip?';

  @override
  String get yourAccountUnderReview => 'Your account is under review';

  @override
  String get accountReviewMessage =>
      'Your account is under review. You will be notified once your account is approved.';

  @override
  String get exit => 'Exit';

  @override
  String get forgetPassword => 'Forget Password';

  @override
  String get forgetOrChangePassword => 'Forget or change password';

  @override
  String get email => 'Email';

  @override
  String get enterYourEmail => 'Enter your email';

  @override
  String get endTrip => 'End Trip';

  @override
  String get endTripConfirmation => 'Are you sure you want to end the trip?';

  @override
  String get onRoute => 'On Route';

  @override
  String get welcomeBack => 'Welcome Back';

  @override
  String get rememberMe => 'Remember Me';

  @override
  String get dontHaveAccount => 'Don\'t have an account? ';

  @override
  String get signUp => 'Sign Up';

  @override
  String get logoutWarning => 'Are you sure you want to logout?';

  @override
  String get signOut => 'Sign Out';

  @override
  String get youNeedToLoginToContinue => 'You need to login to continue.';

  @override
  String get emailAddress => 'Email Address';

  @override
  String get password => 'Password';

  @override
  String get confirmPassword => 'Confirm Password';

  @override
  String get signUpText =>
      'Please fill in the form below to create a new account.';

  @override
  String get userName => 'User Name';

  @override
  String get pleaseEnterValidEmail => 'Please enter a valid email';

  @override
  String get pleaseEnterYourEmail => 'Please enter email';

  @override
  String get lastActive => 'Last active  ';

  @override
  String get resetPassword => 'Reset Password';

  @override
  String get anyNotificationsYet =>
      'Oops... There aren\'t any notifications yet.';

  @override
  String get markAllNotificationsAsSeen => 'Mark all notifications as seen';

  @override
  String get notifications => 'Notifications';

  @override
  String get markAllAsRead => 'Mark all as read';

  @override
  String get orderStudents => 'Order Students';

  @override
  String get orderStudentsMessage =>
      'You can order students manually or automatically';

  @override
  String get automatic => 'Automatic';

  @override
  String get manual => 'Manual';

  @override
  String get automaticOrderMessage => 'Students will be ordered automatically';

  @override
  String get manualOrderMessage =>
      'You can order students manually by dragging and dropping them below';

  @override
  String get firstStop => 'First Stop';

  @override
  String get lastStop => 'Last Stop';

  @override
  String get chooseLastStop => 'Choose Last Stop';

  @override
  String get preview => 'Preview';

  @override
  String get add => 'Add';

  @override
  String get legalDocuments => 'Legal Documents';

  @override
  String get firstName => 'First Name';

  @override
  String get lastName => 'Last Name';

  @override
  String get phoneNumber => 'Phone Number';

  @override
  String get address => 'Address';

  @override
  String get school => 'School';

  @override
  String get driverLicense => 'Driver License Number';

  @override
  String get fieldIsRequired => 'This field is required';

  @override
  String get next => 'Next';

  @override
  String get previous => 'Previous';

  @override
  String get submit => 'Submit';

  @override
  String get documentImage => 'Document Image';

  @override
  String get currentLocationFarMessage =>
      'Your current location is far from the first stop of the trip';

  @override
  String get currentLocation => 'Current Location';

  @override
  String get tripNotTodayMessage =>
      'You can\'t start a trip that is not scheduled for today';

  @override
  String get areYouSureDeleteDevice =>
      'Are you sure you want to delete this device?';

  @override
  String get warning => 'Warning';

  @override
  String get hi => 'Hi';

  @override
  String get orderOfStopsNotGuaranteed =>
      'The order of the stops is not guaranteed \nto be the same as below if you\n are using automatic ordering';

  @override
  String get requestDeleteAccountMessage =>
      'Are you sure you want to request account deletion? If you request account deletion, your account will be deleted after 3 days. You can cancel the request if you login to your account in the upcoming 3 days';

  @override
  String get deleteAllNotifications => 'Delete all notifications';

  @override
  String get checkIn => 'Check in';

  @override
  String get notShowUp => 'Not show up';

  @override
  String get studentNotShowUp => 'Student not show up';

  @override
  String get studentCheckIn => 'Student check in';

  @override
  String get areYouSureMarkStudentAsNotShowUp =>
      'Are you sure you want to mark this student as not show up?';

  @override
  String get areYouSurePickUpStudent =>
      'Are you sure you want to pick up this student?';

  @override
  String get didntReceiveCode => 'Didn\'t receive the code?';

  @override
  String get resend => 'RESEND';

  @override
  String get back => 'Back';

  @override
  String get verify => 'VERIFY';

  @override
  String get emailVerification => 'Email Verification';

  @override
  String get enterCode => 'Enter the code sent to ';

  @override
  String get invalidOtp => 'Invalid OTP';

  @override
  String get resendCode => 'Code resent';

  @override
  String get select => 'Select Manually';

  @override
  String get dismissStop => 'Dismiss Stop';

  @override
  String get areYouSureDismissStop =>
      'Are you sure you want to dismiss this stop? All students in this stop will miss the bus';

  @override
  String get endOfTrip => 'You have reached the end of the trip';

  @override
  String get connectionError => 'Error connecting to the server';

  @override
  String get needHelp => 'Need Help? ';

  @override
  String get contactUs => 'Contact Us';
}
