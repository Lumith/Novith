// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get myProfile => 'Mi Perfil';

  @override
  String get changeLanguage => 'Cambiar Idioma';

  @override
  String get aboutApp => 'Acerca de la Aplicación';

  @override
  String get addDocument => 'Agregar Documento';

  @override
  String get editDocument => 'Editar Documento';

  @override
  String get documentName => 'Nombre del documento';

  @override
  String get documentNameIsRequired => 'El nombre del documento es obligatorio';

  @override
  String get linkedDevices => 'Dispositivos vinculados';

  @override
  String get devices => 'Dispositivos';

  @override
  String get schools => 'Escuelas';

  @override
  String get networkError => 'Error de red';

  @override
  String get anyDevicesYet => 'Ups... No hay ningún dispositivo todavía.';

  @override
  String get anyStudentsYet => 'Ups... No hay ningún estudiante.';

  @override
  String get anySchoolsYet => 'Ups... No hay ninguna escuela.';

  @override
  String get currentDevice => 'Dispositivo actual';

  @override
  String get scanTicket => 'Escanear Ticket';

  @override
  String get documentNumber => 'Número de documento';

  @override
  String get noTripsAssignedToYou => 'Aún no hay viajes asignados a ti.';

  @override
  String get driverInformation => 'Información del conductor';

  @override
  String get cancel => 'Cancelar';

  @override
  String get continueText => 'Continuar';

  @override
  String get paymentMethods => 'Métodos de pago';

  @override
  String get termsConditions => 'Términos y Condiciones';

  @override
  String get login => 'Iniciar sesión';

  @override
  String get logout => 'Cerrar sesión';

  @override
  String get requestDelete => 'Solicitar eliminación';

  @override
  String get shareApp => 'Compartir esta App';

  @override
  String get basicInformation => 'Información básica';

  @override
  String get accountInformation => 'Información de la cuenta';

  @override
  String get bankAccount => 'Cuenta Bancaria';

  @override
  String get accountNumber => 'Número de cuenta';

  @override
  String get pleaseEnterYourAccountNumber =>
      'Por favor ingrese su número de cuenta';

  @override
  String get pleaseEnterValidAccountNumber =>
      'Por favor ingrese un número de cuenta válido';

  @override
  String get routingNumber => 'Número de ruta';

  @override
  String get pleaseEnterYourRoutingNumber =>
      'Por favor ingrese su número de ruta';

  @override
  String get pleaseEnterValidRoutingNumber =>
      'Por favor ingrese un número de ruta válido';

  @override
  String get accountHolderName => 'Nombre del titular de la cuenta';

  @override
  String get pleaseEnterYourAccountName =>
      'Por favor ingrese el nombre del titular de la cuenta';

  @override
  String get bankName => 'Nombre del banco';

  @override
  String get pleaseEnterYourBankName =>
      'Por favor ingrese el nombre de su banco';

  @override
  String get saveBankAccount => 'Guardar cuenta bancaria';

  @override
  String get instantTransferMobileNumber =>
      'Número de móvil para transferencia instantánea';

  @override
  String get pleaseEnterValidMobileNumber =>
      'Por favor ingrese su número de móvil';

  @override
  String get instantTransferMobileNetwork =>
      'Red móvil para transferencia instantánea';

  @override
  String get pleaseEnterYourInstantTransferMobileNetwork =>
      'Por favor ingrese su red móvil para transferencia instantánea';

  @override
  String get save => 'Guardar';

  @override
  String get preferredPaymentMethod => 'Método de pago preferido';

  @override
  String get cash => 'Efectivo';

  @override
  String get mobileMoneyTransfer => 'Transferencia de dinero móvil';

  @override
  String get preferredPaymentMethodHasValidationProblems =>
      'El método de pago preferido tiene problemas de validación';

  @override
  String get wallet => 'Billetera';

  @override
  String get camera => 'Cámara';

  @override
  String get gallery => 'Galería';

  @override
  String get balance => 'Saldo';

  @override
  String get history => 'Historial';

  @override
  String get myWalletBalance => 'Saldo de mi billetera';

  @override
  String get activeTrips => 'Viajes activos';

  @override
  String get morningTrips => 'Viajes de la mañana';

  @override
  String get afternoonTrips => 'Viajes de la tarde';

  @override
  String get students => 'Estudiantes';

  @override
  String get trips => 'Viajes';

  @override
  String get tripTimeline => 'Cronología del viaje';

  @override
  String get tripDetails => 'Detalles del viaje';

  @override
  String get startTrip => 'Iniciar viaje';

  @override
  String get ok => 'Aceptar';

  @override
  String get no => 'No';

  @override
  String get yes => 'Sí';

  @override
  String get areYouSureYouWantToStartTrip =>
      '¿Estás seguro de que quieres iniciar el viaje?';

  @override
  String get yourAccountUnderReview => 'Tu cuenta está en revisión';

  @override
  String get accountReviewMessage =>
      'Tu cuenta está en revisión. Serás notificado una vez que tu cuenta sea aprobada.';

  @override
  String get exit => 'Salir';

  @override
  String get forgetPassword => 'Olvidé mi contraseña';

  @override
  String get forgetOrChangePassword => 'Olvidé o cambiar contraseña';

  @override
  String get email => 'Correo electrónico';

  @override
  String get enterYourEmail => 'Ingresa tu correo electrónico';

  @override
  String get endTrip => 'Finalizar viaje';

  @override
  String get endTripConfirmation =>
      '¿Estás seguro de que quieres finalizar el viaje?';

  @override
  String get onRoute => 'En ruta';

  @override
  String get welcomeBack => 'Bienvenido de nuevo';

  @override
  String get rememberMe => 'Recordarme';

  @override
  String get dontHaveAccount => '¿No tienes una cuenta? ';

  @override
  String get signUp => 'Registrarse';

  @override
  String get logoutWarning => '¿Estás seguro de que quieres cerrar sesión?';

  @override
  String get signOut => 'Cerrar sesión';

  @override
  String get youNeedToLoginToContinue => 'Debes iniciar sesión para continuar.';

  @override
  String get emailAddress => 'Dirección de correo electrónico';

  @override
  String get password => 'Contraseña';

  @override
  String get confirmPassword => 'Confirmar contraseña';

  @override
  String get signUpText =>
      'Por favor completa el formulario a continuación para crear una nueva cuenta.';

  @override
  String get userName => 'Nombre de usuario';

  @override
  String get pleaseEnterValidEmail =>
      'Por favor ingresa un correo electrónico válido';

  @override
  String get pleaseEnterYourEmail => 'Por favor ingresa el correo electrónico';

  @override
  String get lastActive => 'Última actividad ';

  @override
  String get resetPassword => 'Restablecer contraseña';

  @override
  String get anyNotificationsYet =>
      'Ups... No hay ninguna notificación todavía.';

  @override
  String get markAllNotificationsAsSeen =>
      'Marcar todas las notificaciones como vistas';

  @override
  String get notifications => 'Notificaciones';

  @override
  String get markAllAsRead => 'Marcar todas como leídas';

  @override
  String get orderStudents => 'Ordenar estudiantes';

  @override
  String get orderStudentsMessage =>
      'Puedes ordenar a los estudiantes manual o automáticamente';

  @override
  String get automatic => 'Automático';

  @override
  String get manual => 'Manual';

  @override
  String get automaticOrderMessage =>
      'Los estudiantes se ordenarán automáticamente';

  @override
  String get manualOrderMessage =>
      'Puedes ordenar a los estudiantes manualmente arrastrándolos y soltándolos a continuación';

  @override
  String get firstStop => 'Primera parada';

  @override
  String get lastStop => 'Última parada';

  @override
  String get chooseLastStop => 'Elegir última parada';

  @override
  String get preview => 'Vista previa';

  @override
  String get add => 'Agregar';

  @override
  String get legalDocuments => 'Documentos legales';

  @override
  String get firstName => 'Nombre';

  @override
  String get lastName => 'Apellido';

  @override
  String get phoneNumber => 'Número de teléfono';

  @override
  String get address => 'Dirección';

  @override
  String get school => 'Escuela';

  @override
  String get driverLicense => 'Número de licencia de conducir';

  @override
  String get fieldIsRequired => 'Este campo es obligatorio';

  @override
  String get next => 'Siguiente';

  @override
  String get previous => 'Anterior';

  @override
  String get submit => 'Enviar';

  @override
  String get documentImage => 'Imagen del documento';

  @override
  String get currentLocationFarMessage =>
      'Tu ubicación actual está lejos de la primera parada del viaje';

  @override
  String get currentLocation => 'Ubicación actual';

  @override
  String get tripNotTodayMessage =>
      'No puedes iniciar un viaje que no está programado para hoy';

  @override
  String get areYouSureDeleteDevice =>
      '¿Estás seguro de que quieres eliminar este dispositivo?';

  @override
  String get warning => 'Advertencia';

  @override
  String get hi => 'Hola';

  @override
  String get orderOfStopsNotGuaranteed =>
      'El orden de las paradas no está garantizado \nde ser el mismo que el de abajo si\n estás usando el orden automático';

  @override
  String get requestDeleteAccountMessage =>
      '¿Estás seguro de que quieres solicitar la eliminación de la cuenta? Si solicitas la eliminación de la cuenta, esta se eliminará después de 3 días. Puedes cancelar la solicitud si inicias sesión en tu cuenta en los próximos 3 días';

  @override
  String get deleteAllNotifications => 'Eliminar todas las notificaciones';

  @override
  String get checkIn => 'Registrarse';

  @override
  String get notShowUp => 'No se presentó';

  @override
  String get studentNotShowUp => 'El estudiante no se presentó';

  @override
  String get studentCheckIn => 'Registro del estudiante';

  @override
  String get areYouSureMarkStudentAsNotShowUp =>
      '¿Estás seguro de que quieres marcar a este estudiante como no presentado?';

  @override
  String get areYouSurePickUpStudent =>
      '¿Estás seguro de que quieres recoger a este estudiante?';

  @override
  String get didntReceiveCode => '¿No recibiste el código?';

  @override
  String get resend => 'REENVIAR';

  @override
  String get back => 'Atrás';

  @override
  String get verify => 'VERIFICAR';

  @override
  String get emailVerification => 'Verificación de correo electrónico';

  @override
  String get enterCode => 'Ingresa el código enviado a ';

  @override
  String get invalidOtp => 'OTP inválido';

  @override
  String get resendCode => 'Código reenviado';

  @override
  String get select => 'Seleccionar manualmente';

  @override
  String get dismissStop => 'Descartar parada';

  @override
  String get areYouSureDismissStop =>
      '¿Estás seguro de que quieres descartar esta parada? Todos los estudiantes en esta parada perderán el autobús';

  @override
  String get endOfTrip => 'Has llegado al final del viaje';

  @override
  String get connectionError => 'Error al conectar con el servidor';

  @override
  String get needHelp => '¿Necesitas ayuda? ';

  @override
  String get contactUs => 'Contáctanos';
}
