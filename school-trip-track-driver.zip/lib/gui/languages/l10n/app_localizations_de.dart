// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for German (`de`).
class AppLocalizationsDe extends AppLocalizations {
  AppLocalizationsDe([String locale = 'de']) : super(locale);

  @override
  String get myProfile => 'mein Profil';

  @override
  String get changeLanguage => 'Sprache ändern';

  @override
  String get aboutApp => 'Über die App';

  @override
  String get addDocument => 'Dokument hinzufügen';

  @override
  String get editDocument => 'Dokument bearbeiten';

  @override
  String get documentName => 'Dokumentname';

  @override
  String get documentNameIsRequired => 'Dokumentname ist erforderlich';

  @override
  String get linkedDevices => 'Verknüpfte Geräte';

  @override
  String get devices => 'Geräte';

  @override
  String get schools => 'Schulen';

  @override
  String get networkError => 'Netzwerkfehler';

  @override
  String get anyDevicesYet => 'Oops... Noch keine Geräte';

  @override
  String get anyStudentsYet => 'Oops... There aren\'t any students.';

  @override
  String get anySchoolsYet => 'Oops... Noch keine Schulen';

  @override
  String get currentDevice => 'Aktuelles Gerät';

  @override
  String get scanTicket => 'Ticket scannen';

  @override
  String get documentNumber => 'Dokumentnummer';

  @override
  String get noTripsAssignedToYou => 'Keine Reisen Ihnen zugewiesen';

  @override
  String get driverInformation => 'Fahrerinformationen';

  @override
  String get cancel => 'Stornieren';

  @override
  String get continueText => 'Fortsetzen';

  @override
  String get paymentMethods => 'Zahlungsmethoden';

  @override
  String get termsConditions => 'Geschäftsbedingungen';

  @override
  String get login => 'Anmeldung';

  @override
  String get logout => 'Ausloggen';

  @override
  String get requestDelete => 'Request Delete';

  @override
  String get shareApp => 'Teile diese App';

  @override
  String get basicInformation => 'Grundinformation';

  @override
  String get accountInformation => 'Kontoinformationen';

  @override
  String get bankAccount => 'Bankkonto';

  @override
  String get accountNumber => 'Kontonummer';

  @override
  String get pleaseEnterYourAccountNumber =>
      'Bitte geben Sie Ihre Kontonummer ein';

  @override
  String get pleaseEnterValidAccountNumber =>
      'Bitte geben Sie eine gültige Kontonummer ein';

  @override
  String get routingNumber => 'Routing-Nummer';

  @override
  String get pleaseEnterYourRoutingNumber =>
      'Bitte geben Sie Ihre Routing-Nummer ein';

  @override
  String get pleaseEnterValidRoutingNumber =>
      'Bitte geben Sie eine gültige Routing-Nummer ein';

  @override
  String get accountHolderName => 'Kontoinhaber Name';

  @override
  String get pleaseEnterYourAccountName =>
      'Bitte geben Sie Ihren Kontonamen ein';

  @override
  String get bankName => 'Bank Name';

  @override
  String get pleaseEnterYourBankName => 'Bitte geben Sie Ihren Banknamen ein';

  @override
  String get saveBankAccount => 'Bankkonto speichern';

  @override
  String get instantTransferMobileNumber =>
      'Sofortige Übertragung Mobilfunknummer';

  @override
  String get pleaseEnterValidMobileNumber =>
      'Bitte geben Sie eine gültige Handynummer ein';

  @override
  String get instantTransferMobileNetwork =>
      'Sofortige Übertragung Mobilfunknetz';

  @override
  String get pleaseEnterYourInstantTransferMobileNetwork =>
      'Bitte geben Sie Ihr Instant Transfer Mobilfunknetz ein';

  @override
  String get save => 'sparen';

  @override
  String get preferredPaymentMethod => 'Bevorzugte Zahlungsmethode';

  @override
  String get cash => 'Kasse';

  @override
  String get mobileMoneyTransfer => 'Mobile Geldüberweisung';

  @override
  String get preferredPaymentMethodHasValidationProblems =>
      'Bevorzugte Zahlungsmethode hat Validierungsprobleme';

  @override
  String get wallet => 'Brieftasche';

  @override
  String get camera => 'Kamera';

  @override
  String get gallery => 'Galerie';

  @override
  String get balance => 'Balance';

  @override
  String get history => 'Geschichte';

  @override
  String get myWalletBalance => 'Mein Brieftaschenguthaben';

  @override
  String get activeTrips => 'Aktive Reisen';

  @override
  String get morningTrips => 'Morgenreisen';

  @override
  String get afternoonTrips => 'Nachmittagsreisen';

  @override
  String get students => 'Students';

  @override
  String get trips => 'Reisen';

  @override
  String get tripTimeline => 'Reisezeitplan';

  @override
  String get tripDetails => 'Reisedetails';

  @override
  String get startTrip => 'Reise beginnen';

  @override
  String get ok => 'OK';

  @override
  String get no => 'No';

  @override
  String get yes => 'Yes';

  @override
  String get areYouSureYouWantToStartTrip =>
      'Sind Sie sicher, dass Sie die Reise beginnen möchten?';

  @override
  String get yourAccountUnderReview =>
      'Ihr Konto wird überprüft. Sie werden benachrichtigt, sobald Ihr Konto genehmigt wurde.';

  @override
  String get accountReviewMessage =>
      'Ihr Konto wird überprüft. Sie werden benachrichtigt, sobald Ihr Konto genehmigt wurde.';

  @override
  String get exit => 'Ausgang';

  @override
  String get forgetPassword => 'Passwort vergessen';

  @override
  String get forgetOrChangePassword => 'Forget or change password';

  @override
  String get email => 'Email';

  @override
  String get enterYourEmail => 'Geben Sie Ihre E-Mail-Adresse ein';

  @override
  String get endTrip => 'Reise beenden';

  @override
  String get endTripConfirmation =>
      'Sind Sie sicher, dass Sie die Reise beenden möchten?';

  @override
  String get onRoute => 'Auf der Route';

  @override
  String get welcomeBack => 'Willkommen zurück';

  @override
  String get rememberMe => 'Erinnere dich an mich';

  @override
  String get dontHaveAccount => 'Sie haben noch kein Konto? ';

  @override
  String get signUp => 'Anmelden';

  @override
  String get logoutWarning => 'Möchten Sie sich wirklich abmelden?';

  @override
  String get signOut => 'Ausloggen';

  @override
  String get youNeedToLoginToContinue =>
      'Sie müssen sich anmelden, um fortzufahren';

  @override
  String get emailAddress => 'E-Mail-Addresse';

  @override
  String get password => 'Passwort';

  @override
  String get confirmPassword => 'Bestätige das Passwort';

  @override
  String get signUpText =>
      'Bitte füllen Sie das untenstehende Formular aus, um ein neues Konto zu erstellen.';

  @override
  String get userName => 'Nutzername';

  @override
  String get pleaseEnterValidEmail =>
      'Bitte geben Sie eine gültige E-Mail-Adresse ein';

  @override
  String get pleaseEnterYourEmail => 'Bitte geben Sie Ihre E-Mail-Adresse ein';

  @override
  String get lastActive => 'Zuletzt aktiv ';

  @override
  String get resetPassword => 'Passwort zurücksetzen';

  @override
  String get anyNotificationsYet =>
      'Oops... There aren\'t any notifications yet.';

  @override
  String get markAllNotificationsAsSeen => 'Mark all notifications as seen';

  @override
  String get notifications => 'Notifications';

  @override
  String get markAllAsRead => 'Mark all as read';

  @override
  String get orderStudents => 'Order Students';

  @override
  String get orderStudentsMessage =>
      'You can order students manually or automatically';

  @override
  String get automatic => 'Automatic';

  @override
  String get manual => 'Manual';

  @override
  String get automaticOrderMessage => 'Students will be ordered automatically';

  @override
  String get manualOrderMessage =>
      'You can order students manually by dragging and dropping them below';

  @override
  String get firstStop => 'First Stop';

  @override
  String get lastStop => 'Last Stop';

  @override
  String get chooseLastStop => 'Choose Last Stop';

  @override
  String get preview => 'Preview';

  @override
  String get add => 'Add';

  @override
  String get legalDocuments => 'Legal Documents';

  @override
  String get firstName => 'First Name';

  @override
  String get lastName => 'Last Name';

  @override
  String get phoneNumber => 'Phone Number';

  @override
  String get address => 'Address';

  @override
  String get school => 'School';

  @override
  String get driverLicense => 'Driver License Number';

  @override
  String get fieldIsRequired => 'This field is required';

  @override
  String get next => 'Next';

  @override
  String get previous => 'Previous';

  @override
  String get submit => 'Submit';

  @override
  String get documentImage => 'Document Image';

  @override
  String get currentLocationFarMessage =>
      'Your current location is far from the first stop of the trip';

  @override
  String get currentLocation => 'Current Location';

  @override
  String get tripNotTodayMessage =>
      'You can\'t start a trip that is not scheduled for today';

  @override
  String get areYouSureDeleteDevice =>
      'Are you sure you want to delete this device?';

  @override
  String get warning => 'Warning';

  @override
  String get hi => 'Hi';

  @override
  String get orderOfStopsNotGuaranteed =>
      'The order of the stops is not guaranteed \nto be the same as below if you\n are using automatic ordering';

  @override
  String get requestDeleteAccountMessage =>
      'Are you sure you want to request account deletion? If you request account deletion, your account will be deleted after 3 days. You can cancel the request if you login to your account in the upcoming 3 days';

  @override
  String get deleteAllNotifications => 'Delete all notifications';

  @override
  String get checkIn => 'Check in';

  @override
  String get notShowUp => 'Not show up';

  @override
  String get studentNotShowUp => 'Student not show up';

  @override
  String get studentCheckIn => 'Student check in';

  @override
  String get areYouSureMarkStudentAsNotShowUp =>
      'Are you sure you want to mark this student as not show up?';

  @override
  String get areYouSurePickUpStudent =>
      'Are you sure you want to pick up this student?';

  @override
  String get didntReceiveCode => 'Didn\'t receive the code?';

  @override
  String get resend => 'RESEND';

  @override
  String get back => 'Back';

  @override
  String get verify => 'VERIFY';

  @override
  String get emailVerification => 'Email Verification';

  @override
  String get enterCode => 'Enter the code sent to ';

  @override
  String get invalidOtp => 'Invalid OTP';

  @override
  String get resendCode => 'Code resent';

  @override
  String get select => 'Select Manually';

  @override
  String get dismissStop => 'Dismiss Stop';

  @override
  String get areYouSureDismissStop =>
      'Are you sure you want to dismiss this stop? All students in this stop will miss the bus';

  @override
  String get endOfTrip => 'You have reached the end of the trip';

  @override
  String get connectionError => 'Error connecting to the server';

  @override
  String get needHelp => 'Need Help? ';

  @override
  String get contactUs => 'Contact Us';
}
