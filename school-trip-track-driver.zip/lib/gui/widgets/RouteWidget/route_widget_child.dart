import 'package:flutter/material.dart';

abstract class RouteWidgetChild extends StatelessWidget {
  const RouteWidgetChild({super.key});
  @override
  double get height;
}