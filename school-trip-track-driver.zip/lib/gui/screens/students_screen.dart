
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:school_trip_track_driver/gui/widgets/direction_positioned.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:school_trip_track_driver/gui/widgets/form_error.dart';
import 'package:school_trip_track_driver/gui/widgets/app_bar.dart';
import 'package:school_trip_track_driver/model/device.dart';
import 'package:school_trip_track_driver/model/user.dart';
import 'package:school_trip_track_driver/services/service_locator.dart';
import 'package:school_trip_track_driver/utils/tools.dart';
import 'package:school_trip_track_driver/utils/app_theme.dart';
import 'package:school_trip_track_driver/view_models/this_application_view_model.dart';
import 'package:provider/provider.dart';

import '../../connection/utils.dart';
import '../../utils/config.dart';
import '../../widgets.dart';
import '../languages/language_constants.dart';

class StudentsScreen extends StatefulWidget {
  const StudentsScreen({this.tripID, this.showSelectCheckInButtons, this.showDismissStopButton, this.lat, this.long, this.speed, Key? key}) : super(key: key);

  final int? tripID;
  final bool? showSelectCheckInButtons;
  final double? lat, long, speed;
  final bool? showDismissStopButton;
  @override
  StudentsScreenState createState() => StudentsScreenState();
}

class StudentsScreenState extends State<StudentsScreen> {
  ThisApplicationViewModel thisAppModel =
      serviceLocator<ThisApplicationViewModel>();

  @override
  void initState() {
    super.initState();
    thisAppModel.pickupPassengerLoadingState.setError(null);
    thisAppModel.updateBusLocationLoadingState.setError(null);
    thisAppModel.studentsToBePickedUpLoadingState.setError(null);
    thisAppModel.updateBusLocationResponse = null;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      thisAppModel.getStudentsToBePickedUpEndpoint(widget.tripID!);
    });
  }

  @override
  void dispose() {
    thisAppModel.pickupPassengerLoadingState.error = null;
    thisAppModel.updateBusLocationLoadingState.error = null;
    super.dispose();
  }

  Widget displayAllStudents() {
    return Scaffold(
      appBar: buildAppBar(context, translation(context)?.students ??  'Students'),
      body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Consumer<ThisApplicationViewModel>(
            builder: (context, thisApplicationViewModel, child) {

              if(thisAppModel.dismissNextStopLoadingState.loadingFinished() &&
                  thisAppModel.dismissNextStopLoadingState.loadError != null){
                Fluttertoast.showToast(
                    msg: thisAppModel.dismissNextStopLoadingState.error!,
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.BOTTOM,
                    timeInSecForIosWeb: 1,
                    backgroundColor: AppTheme.primary,
                    textColor: Colors.white,
                    fontSize: 16.0
                );
              }

              if(thisAppModel.pickupPassengerLoadingState.inLoading() || thisAppModel.studentsToBePickedUpLoadingState.inLoading()){
                return loadingStudents();
              }
              return displayStudents(context)!;
            },
          )),
    );
  }

  Widget? displayStudents(BuildContext context) {
    if (thisAppModel.studentsToBePickedUpLoadingState.inLoading()) {
      // loading. display animation
      return loadingStudents();
    } else if (thisAppModel.studentsToBePickedUpLoadingState.loadingFinished()) {
      //network call finished.
      if (thisAppModel.studentsToBePickedUpLoadingState.loadError != null) {
        if (kDebugMode) {
          print("page loading error. Display the error");
        }
        // page loading error. Display the error
        return failedScreen(
            context, thisAppModel.studentsToBePickedUpLoadingState.failState!);
      } else {
        return Consumer<ThisApplicationViewModel>(
          builder: (context, thisApplicationViewModel, child) {

            if (thisAppModel.pickupPassengerLoadingState.loadingFinished() &&
                thisAppModel.updateBusLocationLoadingState.loadingFinished() &&
                thisAppModel.updateBusLocationResponse != null && thisAppModel.updateBusLocationResponse!
                .countPassengersToBePickedUp == 0) {
              //wait 100 milliseconds before popping the screen
              Future.delayed(const Duration(milliseconds: 500), () {
                //dispose();
                if (mounted) {
                  Navigator.pop(context);
                }
              });
            }

            List<DbUser> allStudents;
            allStudents = thisAppModel.studentsToBePickedUp;
            if (allStudents.isEmpty) {
              return emptyScreen();
            } else {
              List<Widget> a = [];
              a.addAll(studentsListScreen(allStudents, thisApplicationViewModel));
              return ListView(children: a);
            }
          },
        );
      }
    }
    return null;
  }

  Widget failedScreen(BuildContext context, FailState failState) {
    return Stack(children: [
      Positioned.fill(
        child: Align(
          alignment: Alignment.topCenter,
          child: Column(
            children: [
              Container(),
            ],
          ),
        ),
      ),
      Container(
        constraints: BoxConstraints(
          minHeight: Tools.getScreenHeight(context) - 150,
        ),
        child: Center(
          child: onFailRequest(context, failState),
        ),
      )
    ]);
  }

  Widget emptyScreen() {
    return Stack(children: [
      Positioned.fill(
        child: Align(
          alignment: Alignment.topCenter,
          child: Column(
            children: [
              Container(),
            ],
          ),
        ),
      ),
      DirectionPositioned(
        top: 20,
        left: 10,
        right: 10,
        bottom: 10,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              "assets/images/img_no_place.png",
              height:
                  MediaQuery.of(context).orientation == Orientation.landscape
                      ? 50
                      : 150,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 30),
              child: Column(
                children: [
                  Text(
                    translation(context)?.anyStudentsYet ??  "Oops... There aren't any students yet.",
                    style: AppTheme.caption,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),
    ]);
  }

  List<Widget> studentsListScreen(List<DbUser> allStudents,
      ThisApplicationViewModel thisApplicationViewModel) {
    return List.generate(allStudents.length, (i) {
      return Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 1,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CircleAvatar(
                  backgroundImage: NetworkImage("${Config.serverUrl}${allStudents[i].avatar}"),
                  backgroundColor: AppTheme.veryLightGrey,
                  radius: 80.w,
                ),
                SizedBox(height: 15.h),
                Text(
                  allStudents[i].name!,
                  style: AppTheme.textSecondaryLarge,
                ),
                SizedBox(height: 15.h),
                Text(
                  allStudents[i].notes ?? "",
                  style: AppTheme.textPrimarySmall,
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 15.h),
                widget.showSelectCheckInButtons != null && widget.showSelectCheckInButtons == true ?
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          pickupMissPassenger(allStudents[i], false);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.symmetric(
                              horizontal: 10.h, vertical: 10.h),
                        ),
                        child: Text(
                          translation(context)?.checkIn ?? 'Check In',
                          style: AppTheme.textSecondaryMedium,
                        ),
                      ),
                      OutlinedButton(
                        onPressed: () {
                          pickupMissPassenger(allStudents[i], true);
                        },
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          side: const BorderSide(
                              color: AppTheme.primary, width: 2),
                          padding: EdgeInsets.symmetric(
                              horizontal: 10.h, vertical: 10.h),
                        ),
                        child: Text(
                          translation(context)?.notShowUp ?? 'Not show up',
                          style: AppTheme.textSecondaryMedium,
                        ),
                      ),
                    ],
                  ),
                ) : Container()
              ],
            ),
        ),
      );
    });
  }

  @override
  Widget build(context) {
    return displayAllStudents();
  }

  Widget loadingStudents() {
    return const Center(
      child: SizedBox(
        width: 30,
        height: 30,
        child: CircularProgressIndicator(
          backgroundColor: Colors.transparent,
          valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primary),
        ),
      ),
    );
  }

  void pickupMissPassenger(DbUser student, bool missed) {
    showOkCancelDialog(
        context,
        thisAppModel,
        missed? (translation(context)?.studentNotShowUp ??  'Student not show up') : (translation(context)?.studentCheckIn ?? 'Student check in'),
        missed? (translation(context)?.areYouSureMarkStudentAsNotShowUp ?? 'Are you sure the student did not show up?') : (translation(context)?.areYouSurePickUpStudent ?? 'Are you sure the student checked in?'),
        translation(context)?.yes ?? 'Yes',
        translation(context)?.no ?? 'No',
            () {
          Navigator.of(context, rootNavigator: true)
              .pop();
          thisAppModel.pickupPassengerLoadingState
              .error = null;
          thisAppModel.pickupPassengerEndpoint(
              student.studentIdentification,
              widget.tripID,
              widget.lat,
              widget.long,
              widget.speed,
              missed ? 1 : 0);
        },
            () {
          Navigator.of(context, rootNavigator: true)
              .pop();
        }
    );
  }
}
