
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:school_trip_track_driver/gui/widgets/direction_positioned.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:school_trip_track_driver/gui/widgets/form_error.dart';
import 'package:school_trip_track_driver/gui/widgets/app_bar.dart';
import 'package:school_trip_track_driver/model/device.dart';
import 'package:school_trip_track_driver/model/user.dart';
import 'package:school_trip_track_driver/services/service_locator.dart';
import 'package:school_trip_track_driver/utils/tools.dart';
import 'package:school_trip_track_driver/utils/app_theme.dart';
import 'package:school_trip_track_driver/view_models/this_application_view_model.dart';
import 'package:provider/provider.dart';

import '../../connection/utils.dart';
import '../../model/stop.dart';
import '../../utils/config.dart';
import '../../widgets.dart';
import '../languages/language_constants.dart';

class TripStudentsScreen extends StatefulWidget {
  const TripStudentsScreen({this.tripID, this.showButtons, Key? key}) : super(key: key);

  final int? tripID;
  final bool? showButtons;
  @override
  TripStudentsScreenState createState() => TripStudentsScreenState();
}

class TripStudentsScreenState extends State<TripStudentsScreen> {
  ThisApplicationViewModel thisAppModel =
      serviceLocator<ThisApplicationViewModel>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) {
      thisAppModel.getAllStudentsOnTripEndpoint(widget.tripID!);
    });
  }

  Widget displayAllStudents() {
    return Scaffold(
      appBar: buildAppBar(context, translation(context)?.students ??  'Students'),
      body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Consumer<ThisApplicationViewModel>(
            builder: (context, thisApplicationViewModel, child) {
              return displayStudents(context)!;
            },
          )),
    );
  }

  Widget? displayStudents(BuildContext context) {
    if (thisAppModel.allStudentsOnTripLoadingState.inLoading()) {
      // loading. display animation
      return loadingStudents();
    } else if (thisAppModel.allStudentsOnTripLoadingState.loadingFinished()) {
      //network call finished.
      if (thisAppModel.allStudentsOnTripLoadingState.loadError != null) {
        if (kDebugMode) {
          print("page loading error. Display the error");
        }
        // page loading error. Display the error
        return failedScreen(
            context, thisAppModel.allStudentsOnTripLoadingState.failState!);
      } else {
        return Consumer<ThisApplicationViewModel>(
          builder: (context, thisApplicationViewModel, child) {
            List<DbUser> allStudents;
            List<Stop> allStartStops = [];
            List<String> allPlannedStartTimes = [];
            allStudents = thisAppModel.allStudentsOnTrip;
            allStartStops = thisAppModel.allStartStops;
            allPlannedStartTimes = thisAppModel.allPlannedStartTimes;
            if (allStudents.isEmpty) {
              return emptyScreen();
            } else {
              List<Widget> a = [];
              a.addAll(studentsListScreen(allStudents, allStartStops,
                  allPlannedStartTimes, thisApplicationViewModel));
              return ListView(children: a);
            }
          },
        );
      }
    }
    return null;
  }

  Widget failedScreen(BuildContext context, FailState failState) {
    return Stack(children: [
      Positioned.fill(
        child: Align(
          alignment: Alignment.topCenter,
          child: Column(
            children: [
              Container(),
            ],
          ),
        ),
      ),
      Container(
        constraints: BoxConstraints(
          minHeight: Tools.getScreenHeight(context) - 150,
        ),
        child: Center(
          child: onFailRequest(context, failState),
        ),
      )
    ]);
  }

  Widget emptyScreen() {
    return Stack(children: [
      Positioned.fill(
        child: Align(
          alignment: Alignment.topCenter,
          child: Column(
            children: [
              Container(),
            ],
          ),
        ),
      ),
      DirectionPositioned(
        top: 20,
        left: 10,
        right: 10,
        bottom: 10,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              "assets/images/img_no_place.png",
              height:
                  MediaQuery.of(context).orientation == Orientation.landscape
                      ? 50
                      : 350,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 30),
              child: Column(
                children: [
                  Text(
                    translation(context)?.anyStudentsYet ??  "Oops... There aren't any students yet.",
                    style: AppTheme.caption,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),
    ]);
  }

  List<Widget> studentsListScreen(List<DbUser> allStudents,
  List<Stop> allStartStops,
  List<String> allPlannedStartTimes,
      ThisApplicationViewModel thisApplicationViewModel) {
    return List.generate(allStudents.length, (i) {
      return Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          elevation: 1,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      backgroundImage: NetworkImage(
                          "${Config.serverUrl}${allStudents[i].avatar}"),
                      backgroundColor: AppTheme.veryLightGrey,
                      radius: 40.w,
                    ),
                    SizedBox(width: 20.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            allStudents[i].name!,
                            style: AppTheme.textSecondaryLarge,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(height: 15.h),
                          Text(
                            allStudents[i].notes ?? "",
                            style: AppTheme.textPrimarySmall,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                SizedBox(height: 25.h,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(width: 20.w),
                    //location icon
                    Column(
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          color: AppTheme.primary,
                          size: 30.h,
                        ),
                        SizedBox(height: 3.h),
                        thisAppModel.settings?.simpleMode == true
                            ? Container()
                            :
                        Text(
                          allPlannedStartTimes[i] ?? "",
                          style: AppTheme.textPrimarySmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                    SizedBox(width: 20.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            allStartStops[i].name!,
                            style: AppTheme.textSecondaryMedium,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(height: 10.h),
                          Text(
                            allStartStops[i].address ?? "",
                            style: AppTheme.textPrimarySmall,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                widget.showButtons != null && widget.showButtons == true
                    ? SizedBox(height: 15.h,)
                    : Container(),
                //buttons
                widget.showButtons != null && widget.showButtons == true ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: EdgeInsets.symmetric(
                            horizontal: 10.h, vertical: 10.h),
                      ),
                      child: Text(
                        translation(context)?.checkIn ?? 'Check In',
                        style: AppTheme.textSecondaryMedium,
                      ),
                    ),
                    OutlinedButton(
                      onPressed: () {},
                      style: OutlinedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        side: const BorderSide(
                            color: AppTheme.primary, width: 2),
                        padding: EdgeInsets.symmetric(
                            horizontal: 10.h, vertical: 10.h),
                      ),
                      child: Text(
                        translation(context)?.notShowUp ?? 'Not show up',
                        style: AppTheme.textSecondaryMedium,
                      ),
                    ),
                  ],
                ) : Container(),
              ],
            ),
          ),
        ),
      );
    });
  }

  @override
  Widget build(context) {
    return displayAllStudents();
  }

  Widget loadingStudents() {
    return const Center(
      child: SizedBox(
        width: 30,
        height: 30,
        child: CircularProgressIndicator(
          backgroundColor: Colors.transparent,
          valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primary),
        ),
      ),
    );
  }
}
