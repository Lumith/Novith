import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../services/service_locator.dart';
import '../../utils/app_theme.dart';
import '../../utils/config.dart';
import '../../view_models/this_application_view_model.dart';
import '../../widgets.dart';
import '../languages/language_constants.dart';
import '../widgets/app_bar.dart';

class ContactUsScreen extends StatefulWidget {
  const ContactUsScreen({super.key});

  @override
  ContactUsScreenState createState() => ContactUsScreenState();
}

class ContactUsScreenState extends State<ContactUsScreen> {

  ThisApplicationViewModel thisAppModel = serviceLocator<
      ThisApplicationViewModel>();
  
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      thisAppModel.getAdminInfoEndpoint();
    });
  }

  Widget displayAdminInfo(ThisApplicationViewModel thisApplicationViewModel) {
    if (thisApplicationViewModel.adminInfoLoadingState.inLoading()) {
      // loading. display animation
      return loadingScreen();
    }
    else {
      if (kDebugMode) {
        print("network call finished");
      }
      //network call finished.
      if (thisApplicationViewModel.adminInfoLoadingState.loadError != null) {
        if (kDebugMode) {
          print("page loading error. Display the error");
        }
        // page loading error. Display the error
        return failedScreen(context,
            thisApplicationViewModel.adminInfoLoadingState.failState);
      }
      else {
        return SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.only(top: 20.h, left: 20.w, right: 20.w),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Text(
                          translation(context)?.phoneNumber ?? 'phoneNumber',
                          style: AppTheme.bold16Black,
                        ),
                        SizedBox(width: 10.w),
                        InkWell(
                          child: Text(
                            thisApplicationViewModel.adminInfo?.phone ?? '',
                            style: AppTheme.textDarkPrimaryMedium,
                          ),
                          onTap: () {
                            Uri phoneUri = Uri(
                                scheme: 'tel',
                                path: thisApplicationViewModel.adminInfo
                                    ?.phone);
                            canLaunchUrl(phoneUri)
                                .then((value) {
                              if (value) {
                                launchUrl(phoneUri);
                              }
                            });
                          }
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    Row(
                      children: [
                        Text(
                          translation(context)?.email ?? 'email',
                          style: AppTheme.bold16Black,
                        ),
                        SizedBox(width: 10.w),
                        InkWell(
                          child: Text(
                            thisApplicationViewModel.adminInfo?.email ?? '',
                            style: AppTheme.textDarkPrimaryMedium,
                          ),
                          onTap: () {
                            Uri emailUri = Uri(
                                scheme: 'mailto',
                                path: thisApplicationViewModel.adminInfo
                                    ?.email,
                                queryParameters: {
                                  'subject': 'Contact Us',
                                  'body': 'Hello,'
                                }
                            );
                            canLaunchUrl(emailUri)
                                .then((value) {
                              if (value) {
                                launchUrl(emailUri);
                              }
                            });
                          }
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    Row(
                      children: [
                        Text(
                          translation(context)?.address ?? 'Address',
                          style: AppTheme.bold16Black,
                        ),
                        SizedBox(width: 10.w),
                        Text(
                          thisApplicationViewModel.adminInfo?.address ?? '',
                          style: AppTheme.textDarkPrimaryMedium,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ThisApplicationViewModel>(
      builder: (context, thisApplicationViewModel, child) {
        return Scaffold(
            backgroundColor: AppTheme.backgroundColor,
            appBar: buildAppBar(context, translation(context)?.contactUs ??  'Contact Us'),
            body: displayAdminInfo(thisApplicationViewModel)
        );
      },
    );
  }
}