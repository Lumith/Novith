import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:school_trip_track_driver/gui/screens/students_screen.dart';
import 'package:school_trip_track_driver/utils/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:school_trip_track_driver/gui/widgets/app_bar.dart';
import 'package:school_trip_track_driver/services/service_locator.dart';
import 'package:school_trip_track_driver/utils/config.dart';
import 'package:school_trip_track_driver/view_models/this_application_view_model.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';
import 'package:provider/provider.dart';
import '../../widgets.dart';
import '../languages/language_constants.dart';

class PickUpScreen extends StatefulWidget {
  final int? tripID;
  final Position? currentLocation;
  const PickUpScreen(this.tripID, this.currentLocation, {super.key});

  @override
  PickUpScreenState createState() => PickUpScreenState();
}

class PickUpScreenState extends State<PickUpScreen> {
  CameraController? controller;
  ThisApplicationViewModel thisAppModel = serviceLocator<
      ThisApplicationViewModel>();

  List<CameraDescription>? _cameras;
  bool cameraReady = false;
  bool? cameraAccessDenied;

  final _orientations = {
    DeviceOrientation.portraitUp: 0,
    DeviceOrientation.landscapeLeft: 90,
    DeviceOrientation.portraitDown: 180,
    DeviceOrientation.landscapeRight: 270,
  };

  final barcodeScanner = BarcodeScanner(formats: [BarcodeFormat.qrCode]);

  @override
  void initState() {
    super.initState();

    availableCameras().then((value)
    {
      _cameras = value;
      if(_cameras == null || _cameras!.isEmpty)
      {
        return;
      }
      controller = CameraController(
          _cameras![0],
          enableAudio: false,
          imageFormatGroup: Platform.isAndroid
              ? ImageFormatGroup.nv21 // for Android
              : ImageFormatGroup.bgra8888, // for iOS
          ResolutionPreset.max);
      controller?.initialize().then((_) {
        if (!mounted) {
          return;
        }
        setState(() {

        });
      }).catchError((Object e) {
        if (e is CameraException) {
          switch (e.code) {
            case 'CameraAccessDenied':
            // Handle access errors here.
            setState(() {
              cameraAccessDenied = true;
            });
              break;
            default:
            // Handle other errors here.
              break;
          }
        }
      });
    });

  }

  Future<XFile?> takePicture() async {
    final CameraController? cameraController = controller;
    if (cameraController == null || !cameraController.value.isInitialized) {
      _showCameraError('Camera is not initialized.');
      return null;
    }

    if (cameraController.value.isTakingPicture) {
      _showCameraError('A capture is already pending, do nothing.');
      // A capture is already pending, do nothing.
      return null;
    }

    try {
      final XFile file = await cameraController.takePicture();
      return file;
    } on CameraException catch (e) {
      _showCameraError(e.description);
      return null;
    }
  }

  void _showCameraError(String? message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message ?? "",
          style: const TextStyle(color: Colors.white),
        ),
      ),
    );
  }

  @override
  void dispose() {
    //check if controller is not null before disposing and not disposed
    if (controller != null && controller!.value.isInitialized) {
      controller?.dispose();
    }
    thisAppModel.pickupPassengerLoadingState.error = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (controller == null || !controller!.value.isInitialized) {
      //show loading spinner
      return loadingScreen();
    }
    else {
      if (cameraAccessDenied == true) {
        return Scaffold(
          appBar: buildAppBar(context, translation(context)?.scanTicket ?? 'Scan Ticket'),
          body: const Center(
            child: Text(
              'Camera access denied',
              style: TextStyle(color: AppTheme.colorError),
            ),
          ),
        );
      }
    }
    return Consumer<ThisApplicationViewModel>(
        builder: (context, thisAppModel, child) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (thisAppModel.pickupPassengerLoadingState.error != null) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    thisAppModel.pickupPassengerLoadingState
                        .error!,
                  ),
                ),
              );
              thisAppModel.pickupPassengerLoadingState.error = null;
            }

            if (thisAppModel.updateBusLocationResponse != null &&
                thisAppModel.updateBusLocationResponse!
                .countPassengersToBePickedUp == 0) {
              if (mounted) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (Navigator.canPop(context)) {
                    Navigator.pop(context);
                  }
                });
              }
            }
          });
          return Scaffold(
            appBar: buildAppBar(context, 'Scan Ticket'),
            body: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: <Widget>[
                  const SizedBox(height: 20,),
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              thisAppModel.updateBusLocationResponse != null ?
                              Text("${thisAppModel.updateBusLocationResponse!
                                  .countPassengersToBePickedUp} ${thisAppModel.updateBusLocationResponse!
                                  .countPassengersToBePickedUp==1?"Student":"Students"}", style: AppTheme.textSecondaryLarge,)
                              : const SizedBox(),
                              const SizedBox(width: 10,),
                              InkWell(
                                child: Container(
                                    width: 25.w,
                                    height: 25.w,
                                    decoration: BoxDecoration(
                                      color: AppTheme.primary,
                                      borderRadius: BorderRadius.circular(10.r),
                                    ),
                                    child: const Icon(Icons.list_sharp, color: AppTheme.secondary, size: 20,)
                                ),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            StudentsScreen(
                                              tripID: widget.tripID,
                                              showSelectCheckInButtons: true,
                                              lat: widget.currentLocation?.latitude,
                                              long: widget.currentLocation?.longitude,
                                              speed: widget.currentLocation?.speed
                                            )),
                                  );
                                },
                              )
                            ],
                          ),
                          SizedBox(height: 50.h,),
                          Align(
                              alignment: AlignmentDirectional.centerStart,
                              child: Text("Place QR code in the middle of the box", style: AppTheme.textSecondarySmall,),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 10.h,),
                  SizedBox(
                    width: 270.w,
                    height: 270.w,
                    child: (controller != null && controller!.value.isInitialized)
                        ? CameraPreview(controller!)
                        : const Center(
                      child: CircularProgressIndicator(),
                    ),
                  ),
                  SizedBox(height: 10.h,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      OutlinedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    StudentsScreen(
                                        tripID: widget.tripID,
                                        showSelectCheckInButtons: true,
                                        lat: widget.currentLocation?.latitude,
                                        long: widget.currentLocation?.longitude,
                                        speed: widget.currentLocation?.speed
                                    )),
                          );
                        },
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          side: const BorderSide(color: AppTheme.primary, width: 2),
                          padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
                        ),
                        child: Text(
                          translation(context)?.select ?? 'Select',
                          style: AppTheme.textSecondaryMedium,
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: () async {
                          final image = await takePicture();

                          if (image == null) {
                            return;
                          }
                          final inputImage = InputImage.fromFilePath(
                              image.path);
                          final List<
                              Barcode> barcodes = await barcodeScanner
                              .processImage(inputImage);
                          if(Config.localTest)
                          {
                            thisAppModel.pickupPassengerLoadingState
                                .error = null;
                            thisAppModel.pickupPassengerEndpoint(
                                "123456789",
                                widget.tripID,
                                widget.currentLocation?.latitude,
                                widget.currentLocation?.longitude,
                                widget.currentLocation?.speed, null);
                          }
                          else
                          {
                            //make HapticFeedback and beep
                            HapticFeedback.vibrate();
                            FlutterRingtonePlayer().playNotification();
                            if (barcodes.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    'No QR code found',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              );
                              return;
                            }
                            else {
                              thisAppModel.pickupPassengerLoadingState
                                  .error = null;
                              thisAppModel.pickupPassengerEndpoint(
                                  barcodes[0].displayValue, //"123456789",
                                  widget.tripID,
                                  widget.currentLocation?.latitude,
                                  widget.currentLocation?.longitude,
                                  widget.currentLocation?.speed, null);
                            }
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
                        ),
                        child: thisAppModel.updateBusLocationResponse != null?
                        Text('Scan (${thisAppModel.updateBusLocationResponse!
                            .countPassengersToBePickedUp})', style: AppTheme.textSecondarySmall,)
                        : Text('Scan', style: AppTheme.textSecondarySmall,),
                      ),
                    ],
                  ),
                  SizedBox(height: 30.h,),
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text("Students do not show up? Report below", style: AppTheme.textSecondarySmall,),
                    ),
                  ),
                  SizedBox(height: 10.h,),
                  ElevatedButton(
                    onPressed: () async {
                      showOkCancelDialog(
                          context,
                          thisAppModel,
                          "No Students",
                          "Are you sure you want to mark these students as not show up?",
                          "Yes",
                          "No",
                              () {
                            Navigator.of(context, rootNavigator: true)
                                .pop();
                            thisAppModel.pickupPassengerLoadingState
                                .error = null;
                            thisAppModel.pickupPassengerEndpoint(
                                null,
                                widget.tripID,
                                widget.currentLocation?.latitude,
                                widget.currentLocation?.longitude,
                                widget.currentLocation?.speed, 1);
                          },
                              () {
                            Navigator.of(context, rootNavigator: true)
                                .pop();
                          }
                      );
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.normalGrey,
                        shape: const StadiumBorder()
                    ),
                    child: Padding(
                      padding: EdgeInsets.only(left:20.w, right: 20.w, top: 15.h, bottom: 15.h),
                      child: Text(
                          "Students do not show up",
                          style: AppTheme.textWhiteMedium
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}