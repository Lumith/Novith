

// ignore: unused_import
import 'package:school_trip_track_driver/model/device.dart';
import 'package:school_trip_track_driver/model/user.dart';

import '../../model/reservation.dart';
import '../../model/stop.dart';

class StudentsResponse {
  List<DbUser>? students;
  List<Stop>? startStops;
  List<Stop>? endStops;
  List<String>? plannedStartTimes;

  StudentsResponse({this.students, this.startStops, this.endStops, this.plannedStartTimes});

  factory StudentsResponse.fromJson(Map<String, dynamic> json) {
    return StudentsResponse(
        students: json['students'] != null ? (json['students'] as List).map((p) => DbUser.fromJson(p)).toList() : null,
        startStops: json['start_stops'] != null ? (json['start_stops'] as List).map((p) => Stop.fromJson(p)).toList() : null,
        endStops: json['end_stops'] != null ? (json['end_stops'] as List).map((p) => Stop.fromJson(p)).toList() : null,
        plannedStartTimes: json['planned_start_times'] != null ? (json['planned_start_times'] as List).map((p) => p.toString()).toList() : null
    );
  }
}