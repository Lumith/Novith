package com.creativeapps.school_trip_track_guardian;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
