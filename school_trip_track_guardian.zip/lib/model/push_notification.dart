
class PushNotification {

  PushNotification({
    this.id,
    this.title,
    this.body,
    this.type,
    this.imgUrl,
    this.userId,
  });

  String? id;
  String? title;
  String? body;
  String? type;
  String? imgUrl;
  int? userId;
}