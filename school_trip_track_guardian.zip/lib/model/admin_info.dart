
import 'package:intl/intl.dart';

class AdminInfo{
    String? address, phone, email;

    AdminInfo({
        this.address,
        this.phone,
        this.email,
    });

    Map<String, dynamic> toJson() {
        return {
            'address': address,
            'phone': phone,
            'email': email,
        };
    }

    static AdminInfo fromJson(json) {
        return AdminInfo(
            address: json['address'] ?? '',
            phone: json['phone'] ?? '',
            email: json['email'] ?? '',
        );
    }
}
