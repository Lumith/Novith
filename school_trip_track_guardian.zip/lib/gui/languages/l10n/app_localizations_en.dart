// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get students => 'Students';

  @override
  String get notificationSettings => 'Notification Settings';

  @override
  String get busArrivedAtPickupLocationNotification =>
      'Bus arrived at pickup location';

  @override
  String get busArrivedAtDropOffLocationNotification =>
      'Bus arrived at drop off location';

  @override
  String get busLeftPickupLocationNotification => 'Bus left pickup location';

  @override
  String get busLeftDropOffLocationNotification => 'Bus left drop off location';

  @override
  String get busArrivedAtSchoolNotification => 'Bus arrived at school';

  @override
  String get busLeftSchoolNotification => 'Bus left school';

  @override
  String get busNearPickupLocationNotificationByDistance =>
      'Bus is near pickup location';

  @override
  String get busNearDropOffLocationNotification =>
      'Bus is near drop off location';

  @override
  String get nextStopIsYourPickupLocationNotification =>
      'Next Stop Is Your Pickup Location';

  @override
  String get studentIsPickedUpNotification => 'Student is picked up';

  @override
  String get studentIsMissedPickupNotification => 'Student is missed pickup';

  @override
  String get pickupNotifications => 'Pickup Notifications';

  @override
  String get dropOffNotifications => 'Drop Off Notifications';

  @override
  String get guardians => 'Guardians';

  @override
  String get myProfile => 'My Profile';

  @override
  String get changeLanguage => 'Change Language';

  @override
  String get aboutApp => 'About App';

  @override
  String get linkedDevices => 'Linked devices';

  @override
  String get devices => 'Devices';

  @override
  String get networkError => 'Network error';

  @override
  String get anyDevicesYet => 'Oops... There aren\'t any devices yet.';

  @override
  String get currentDevice => 'Current device';

  @override
  String get cancel => 'Cancel';

  @override
  String get continueText => 'Continue';

  @override
  String get termsConditions => 'Terms and Conditions';

  @override
  String get login => 'Login';

  @override
  String get logout => 'Logout';

  @override
  String get requestDelete => 'Request Delete';

  @override
  String get shareApp => 'Share this App';

  @override
  String get basicInformation => 'Basic information';

  @override
  String get accountInformation => 'Account information';

  @override
  String get save => 'Save';

  @override
  String get wallet => 'Wallet';

  @override
  String get camera => 'Camera';

  @override
  String get gallery => 'Gallery';

  @override
  String get balance => 'Balance';

  @override
  String get history => 'History';

  @override
  String get myWalletBalance => 'My Wallet Balance';

  @override
  String get activeTrips => 'Active Trips';

  @override
  String get trips => 'Trips';

  @override
  String get tripTimeline => 'Trip Timeline';

  @override
  String get tripDetails => 'Trip Details';

  @override
  String get startTrip => 'Start Trip';

  @override
  String get ok => 'OK';

  @override
  String get no => 'No';

  @override
  String get yes => 'Yes';

  @override
  String get exit => 'Exit';

  @override
  String get forgetOrChangePassword => 'Forget or change password';

  @override
  String get email => 'Email';

  @override
  String get enterYourEmail => 'Enter your email';

  @override
  String get welcomeBack => 'Welcome Back';

  @override
  String get rememberMe => 'Remember Me';

  @override
  String get dontHaveAccount => 'Don\'t have an account? ';

  @override
  String get signUp => 'Sign Up';

  @override
  String get logoutWarning => 'Are you sure you want to logout?';

  @override
  String get signOut => 'Sign Out';

  @override
  String get youNeedToLoginToContinue => 'You need to login to continue.';

  @override
  String get emailAddress => 'Email Address';

  @override
  String get password => 'Password';

  @override
  String get confirmPassword => 'Confirm Password';

  @override
  String get signUpText =>
      'Please fill in the form below to create a new account.';

  @override
  String get userName => 'User Name';

  @override
  String get pleaseEnterValidEmail => 'Please enter a valid email';

  @override
  String get pleaseEnterYourEmail => 'Please enter email';

  @override
  String get stops => 'Stops';

  @override
  String get routes => 'Routes';

  @override
  String get phoneNumber => 'Phone Number';

  @override
  String get pleaseEnterPhoneNumber => 'Please enter phone number';

  @override
  String get address => 'Address';

  @override
  String get pleaseEnterAddress => 'Please enter your address';

  @override
  String get noStops => 'Oops... No stops found.';

  @override
  String get noRoutes => 'Oops... No routes found.';

  @override
  String get warning => 'Warning';

  @override
  String get areYouSureDeleteDevice => 'Are you sure to delete this device?';

  @override
  String get lastActive => 'Last active  ';

  @override
  String get deposit => 'Deposit';

  @override
  String get addMoney => 'Add Money';

  @override
  String get noTransactionsYet => 'Oops... No transactions yet.';

  @override
  String get active => 'Active';

  @override
  String get noTrips => 'Oops... No trips.';

  @override
  String get sendComplaint => 'Send Complaint';

  @override
  String get enterComplaint => 'Enter your complaint';

  @override
  String get pleaseEnterComplaint => 'Please enter your complaint';

  @override
  String get pleaseEnterValidComplaint =>
      'Please enter a valid complaint (more than 10 characters)';

  @override
  String get paidOn => 'Paid on ';

  @override
  String get startSearch => 'Start search';

  @override
  String get favorites => 'Favorites';

  @override
  String get addNew => '+ Add new';

  @override
  String get lastTrips => 'Last Trips';

  @override
  String get start => 'Start';

  @override
  String get destination => 'Destination';

  @override
  String get go => 'Go';

  @override
  String get chooseYourTrip => 'Choose your trip';

  @override
  String get book => 'Book';

  @override
  String get bookTrip => 'Book trip';

  @override
  String get notEnoughMoney => 'You don\'t have enough money in your wallet.';

  @override
  String get error => 'Error';

  @override
  String get areYouSureDeletePlace => 'Are you sure to delete this place?';

  @override
  String get savePlace => 'Save Place';

  @override
  String get newPlace => 'New Place';

  @override
  String get addFavoritePlace => 'Add Favorite Place';

  @override
  String get editPlace => 'Edit Place';

  @override
  String get setAddress => 'Set Address';

  @override
  String get noTripsMatchYourSearch =>
      'Oops... There aren\'t any trip that match your search.';

  @override
  String get recentPlaces => 'Recent Places';

  @override
  String get noRecentPlacesYet =>
      'Oops... There aren\'t any recent places yet.';

  @override
  String get areYouSureLogout => 'Are you sure to log out?';

  @override
  String get tripHasEnded => 'Trip has ended';

  @override
  String get tripNotStartedYet => 'Trip has not started yet';

  @override
  String get resetPassword => 'Reset Password';

  @override
  String get newAccount => 'New Account';

  @override
  String get favoritePlaces => 'Favorite Places';

  @override
  String get noFavoritePlacesYet =>
      'Oops... There aren\'t any favorite places yet.';

  @override
  String get addMoneyToWallet => 'Add Money to Wallet';

  @override
  String get notifications => 'Notifications';

  @override
  String get date => 'Date';

  @override
  String get time => 'Time';

  @override
  String get from => 'From';

  @override
  String get price => 'Price';

  @override
  String get ticketDetails => 'Ticket Details';

  @override
  String get anyNotificationsYet =>
      'Oops... There aren\'t any notifications yet.';

  @override
  String get showMore => 'Show More';

  @override
  String get showLess => 'Show Less';

  @override
  String get alert => 'Alert';

  @override
  String get markAllNotificationsAsSeen => 'Mark all notifications as seen';

  @override
  String get markAllAsRead => 'Mark all as read';

  @override
  String get newStudent => 'New Student';

  @override
  String get studentName => 'Student Name';

  @override
  String get studentNameRequired => 'Student name is required';

  @override
  String get studentId => 'Student ID';

  @override
  String get studentIdRequired => 'Student ID is required';

  @override
  String get studentNotes => 'Student Notes';

  @override
  String get studentNotesRequired => 'Student notes are required';

  @override
  String get studentPicture => 'Student Picture';

  @override
  String get submit => 'Submit';

  @override
  String get studentPicRequired => 'Student picture is required';

  @override
  String get schools => 'Schools';

  @override
  String get school => 'School';

  @override
  String get schoolIsRequired => 'School is required';

  @override
  String get anySchoolsYet => 'Oops... There aren\'t any schools.';

  @override
  String get addStudent => 'Add Student';

  @override
  String get editStudent => 'Edit Student';

  @override
  String get delete => 'Delete';

  @override
  String get areYouSureAbsent =>
      'Are you sure that you want to mark this student as absent?';

  @override
  String get deleteStudent => 'Delete Student';

  @override
  String get deleteStudentWarning =>
      'Are you sure that you want to delete this student?';

  @override
  String get add => 'Add';

  @override
  String get noStudents => 'No students.';

  @override
  String get noStudentsYet =>
      'There aren\'t any students yet. Please add students to your account.';

  @override
  String get notesHint => 'Notes: e.g. class, year, etc.';

  @override
  String get rejected => 'Rejected';

  @override
  String get suspended => 'Suspended';

  @override
  String get outOfCredit => 'Out of credit';

  @override
  String get underReview => 'Under review';

  @override
  String get noGuardians => 'No guardians';

  @override
  String get noGuardiansYet =>
      'There aren\'t any guardians yet. Please add guardians to your account.';

  @override
  String get coins => 'Coins';

  @override
  String get oneCoinInfo =>
      'One coin allows you to track one student\n for one day.';

  @override
  String get updatingStatus => 'Updating status...';

  @override
  String get absent => 'Absent';

  @override
  String get notAbsent => 'Not absent';

  @override
  String get areYouSureNotAbsent =>
      'Are you sure that you want to mark this student as not absent?';

  @override
  String get studentIsNotAbsent => 'Student is not absent';

  @override
  String get adjustNotificationSettings =>
      'Adjust notification settings for student.';

  @override
  String get pickup => 'Pickup';

  @override
  String get dropOff => 'Drop Off';

  @override
  String get morning => 'Morning';

  @override
  String get afternoon => 'Afternoon';

  @override
  String get morningBusNotAssigned =>
      'Morning bus is not assigned to the student.';

  @override
  String get afternoonBusNotAssigned =>
      'Afternoon bus is not assigned to the student.';

  @override
  String get selectTime => 'Select Time';

  @override
  String get settings => 'Settings';

  @override
  String get selectPickupStop => 'Select Pickup Stop';

  @override
  String get selectDropOffStop => 'Select Drop Off Stop';

  @override
  String get selectPickupStopStudent => 'Select pickup stop for this student.';

  @override
  String get selectDropOffStopStudent =>
      'Select drop off stop for this student.';

  @override
  String get trackMorningBus => 'Track Morning Bus';

  @override
  String get trackAfternoonBus => 'Track Afternoon Bus';

  @override
  String get addGuardian => 'Add Guardian';

  @override
  String get enterGuardianEmail =>
      'Enter name and email address of the guardian.';

  @override
  String get name => 'Name';

  @override
  String get confirmEmail => 'Confirm Email';

  @override
  String get selectStopForStudent => 'Select stop for this student.';

  @override
  String get noTripIsAvailable => 'No trip is available.';

  @override
  String get deleteAllNotifications => 'Delete all notifications';

  @override
  String get printStudentCard => 'Print Student Card';

  @override
  String get printStudentCardMessage =>
      'You will get a PDF file at your email address with the student card. Please print it and give it to the student.';

  @override
  String get requestDeleteAccountMessage =>
      'Are you sure you want to request account deletion? If you request account deletion, your account will be deleted after 3 days. You can cancel the request if you login to your account in the upcoming 3 days';

  @override
  String get requestCoins => 'Request Coins';

  @override
  String get emailVerification => 'Email Verification';

  @override
  String get enterCode => 'Enter the code sent to ';

  @override
  String get invalidOtp => 'Invalid OTP';

  @override
  String get resendCode => 'Code resent';

  @override
  String get back => 'Back';

  @override
  String get verify => 'VERIFY';

  @override
  String get needHelp => 'Need Help? ';

  @override
  String get contactUs => 'Contact Us';

  @override
  String get languageUpdatedSuccessfully => 'Language updated successfully.';
}
