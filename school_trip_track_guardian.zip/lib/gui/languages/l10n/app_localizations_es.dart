// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get students => 'Estudiantes';

  @override
  String get notificationSettings => 'Configuración de notificaciones';

  @override
  String get busArrivedAtPickupLocationNotification =>
      'El autobús llegó al punto de recogida';

  @override
  String get busArrivedAtDropOffLocationNotification =>
      'El autobús llegó al punto de entrega';

  @override
  String get busLeftPickupLocationNotification =>
      'El autobús salió del punto de recogida';

  @override
  String get busLeftDropOffLocationNotification =>
      'El autobús salió del punto de entrega';

  @override
  String get busArrivedAtSchoolNotification => 'El autobús llegó a la escuela';

  @override
  String get busLeftSchoolNotification => 'El autobús salió de la escuela';

  @override
  String get busNearPickupLocationNotificationByDistance =>
      'El autobús está cerca del punto de recogida';

  @override
  String get busNearDropOffLocationNotification =>
      'El autobús está cerca del punto de entrega';

  @override
  String get nextStopIsYourPickupLocationNotification =>
      'La próxima parada es su punto de recogida';

  @override
  String get studentIsPickedUpNotification => 'El estudiante fue recogido';

  @override
  String get studentIsMissedPickupNotification =>
      'El estudiante no fue recogido';

  @override
  String get pickupNotifications => 'Notificaciones de recogida';

  @override
  String get dropOffNotifications => 'Notificaciones de entrega';

  @override
  String get guardians => 'Tutores';

  @override
  String get myProfile => 'Mi perfil';

  @override
  String get changeLanguage => 'Cambiar idioma';

  @override
  String get aboutApp => 'Acerca de la aplicación';

  @override
  String get linkedDevices => 'Dispositivos vinculados';

  @override
  String get devices => 'Dispositivos';

  @override
  String get networkError => 'Error de red';

  @override
  String get anyDevicesYet => 'Ups... No hay dispositivos aún.';

  @override
  String get currentDevice => 'Dispositivo actual';

  @override
  String get cancel => 'Cancelar';

  @override
  String get continueText => 'Continuar';

  @override
  String get termsConditions => 'Términos y condiciones';

  @override
  String get login => 'Iniciar sesión';

  @override
  String get logout => 'Cerrar sesión';

  @override
  String get requestDelete => 'Solicitar eliminación';

  @override
  String get shareApp => 'Compartir esta aplicación';

  @override
  String get basicInformation => 'Información básica';

  @override
  String get accountInformation => 'Información de la cuenta';

  @override
  String get save => 'Guardar';

  @override
  String get wallet => 'Billetera';

  @override
  String get camera => 'Cámara';

  @override
  String get gallery => 'Galería';

  @override
  String get balance => 'Saldo';

  @override
  String get history => 'Historial';

  @override
  String get myWalletBalance => 'Saldo de mi billetera';

  @override
  String get activeTrips => 'Viajes activos';

  @override
  String get trips => 'Viajes';

  @override
  String get tripTimeline => 'Cronología del viaje';

  @override
  String get tripDetails => 'Detalles del viaje';

  @override
  String get startTrip => 'Iniciar viaje';

  @override
  String get ok => 'Aceptar';

  @override
  String get no => 'No';

  @override
  String get yes => 'Sí';

  @override
  String get exit => 'Salir';

  @override
  String get forgetOrChangePassword => 'Olvidé o cambiar contraseña';

  @override
  String get email => 'Correo electrónico';

  @override
  String get enterYourEmail => 'Ingrese su correo electrónico';

  @override
  String get welcomeBack => 'Bienvenido de nuevo';

  @override
  String get rememberMe => 'Recordarme';

  @override
  String get dontHaveAccount => '¿No tiene una cuenta? ';

  @override
  String get signUp => 'Registrarse';

  @override
  String get logoutWarning => '¿Está seguro de que desea cerrar sesión?';

  @override
  String get signOut => 'Cerrar sesión';

  @override
  String get youNeedToLoginToContinue => 'Debe iniciar sesión para continuar.';

  @override
  String get emailAddress => 'Dirección de correo electrónico';

  @override
  String get password => 'Contraseña';

  @override
  String get confirmPassword => 'Confirmar contraseña';

  @override
  String get signUpText =>
      'Complete el formulario a continuación para crear una nueva cuenta.';

  @override
  String get userName => 'Nombre de usuario';

  @override
  String get pleaseEnterValidEmail => 'Ingrese un correo electrónico válido';

  @override
  String get pleaseEnterYourEmail => 'Ingrese su correo electrónico';

  @override
  String get stops => 'Paradas';

  @override
  String get routes => 'Rutas';

  @override
  String get phoneNumber => 'Número de teléfono';

  @override
  String get pleaseEnterPhoneNumber => 'Ingrese su número de teléfono';

  @override
  String get address => 'Dirección';

  @override
  String get pleaseEnterAddress => 'Ingrese su dirección';

  @override
  String get noStops => 'Ups... No se encontraron paradas.';

  @override
  String get noRoutes => 'Ups... No se encontraron rutas.';

  @override
  String get warning => 'Advertencia';

  @override
  String get areYouSureDeleteDevice =>
      '¿Está seguro de eliminar este dispositivo?';

  @override
  String get lastActive => 'Última actividad ';

  @override
  String get deposit => 'Depósito';

  @override
  String get addMoney => 'Agregar dinero';

  @override
  String get noTransactionsYet => 'Ups... No hay transacciones aún.';

  @override
  String get active => 'Activo';

  @override
  String get noTrips => 'Ups... No hay viajes.';

  @override
  String get sendComplaint => 'Enviar queja';

  @override
  String get enterComplaint => 'Ingrese su queja';

  @override
  String get pleaseEnterComplaint => 'Ingrese su queja';

  @override
  String get pleaseEnterValidComplaint =>
      'Ingrese una queja válida (más de 10 caracteres)';

  @override
  String get paidOn => 'Pagado el ';

  @override
  String get startSearch => 'Iniciar búsqueda';

  @override
  String get favorites => 'Favoritos';

  @override
  String get addNew => '+ Agregar nuevo';

  @override
  String get lastTrips => 'Últimos viajes';

  @override
  String get start => 'Inicio';

  @override
  String get destination => 'Destino';

  @override
  String get go => 'Ir';

  @override
  String get chooseYourTrip => 'Elija su viaje';

  @override
  String get book => 'Reservar';

  @override
  String get bookTrip => 'Reservar viaje';

  @override
  String get notEnoughMoney => 'No tiene suficiente dinero en su billetera.';

  @override
  String get error => 'Error';

  @override
  String get areYouSureDeletePlace => '¿Está seguro de eliminar este lugar?';

  @override
  String get savePlace => 'Guardar lugar';

  @override
  String get newPlace => 'Nuevo lugar';

  @override
  String get addFavoritePlace => 'Agregar lugar favorito';

  @override
  String get editPlace => 'Editar lugar';

  @override
  String get setAddress => 'Establecer dirección';

  @override
  String get noTripsMatchYourSearch =>
      'Ups... No hay viajes que coincidan con su búsqueda.';

  @override
  String get recentPlaces => 'Lugares recientes';

  @override
  String get noRecentPlacesYet => 'Ups... No hay lugares recientes aún.';

  @override
  String get areYouSureLogout => '¿Está seguro de cerrar sesión?';

  @override
  String get tripHasEnded => 'El viaje ha terminado';

  @override
  String get tripNotStartedYet => 'El viaje no ha comenzado aún';

  @override
  String get resetPassword => 'Restablecer contraseña';

  @override
  String get newAccount => 'Cuenta nueva';

  @override
  String get favoritePlaces => 'Lugares favoritos';

  @override
  String get noFavoritePlacesYet => 'Ups... No hay lugares favoritos aún.';

  @override
  String get addMoneyToWallet => 'Agregar dinero a la billetera';

  @override
  String get notifications => 'Notificaciones';

  @override
  String get date => 'Fecha';

  @override
  String get time => 'Hora';

  @override
  String get from => 'Desde';

  @override
  String get price => 'Precio';

  @override
  String get ticketDetails => 'Detalles del boleto';

  @override
  String get anyNotificationsYet => 'Ups... No hay notificaciones aún.';

  @override
  String get showMore => 'Mostrar más';

  @override
  String get showLess => 'Mostrar menos';

  @override
  String get alert => 'Alerta';

  @override
  String get markAllNotificationsAsSeen =>
      'Marcar todas las notificaciones como vistas';

  @override
  String get markAllAsRead => 'Marcar todo como leído';

  @override
  String get newStudent => 'Nuevo estudiante';

  @override
  String get studentName => 'Nombre del estudiante';

  @override
  String get studentNameRequired => 'El nombre del estudiante es obligatorio';

  @override
  String get studentId => 'ID del estudiante';

  @override
  String get studentIdRequired => 'El ID del estudiante es obligatorio';

  @override
  String get studentNotes => 'Notas del estudiante';

  @override
  String get studentNotesRequired =>
      'Las notas del estudiante son obligatorias';

  @override
  String get studentPicture => 'Foto del estudiante';

  @override
  String get submit => 'Enviar';

  @override
  String get studentPicRequired => 'La foto del estudiante es obligatoria';

  @override
  String get schools => 'Escuelas';

  @override
  String get school => 'Escuela';

  @override
  String get schoolIsRequired => 'La escuela es obligatoria';

  @override
  String get anySchoolsYet => 'Ups... No hay escuelas aún.';

  @override
  String get addStudent => 'Agregar estudiante';

  @override
  String get editStudent => 'Editar estudiante';

  @override
  String get delete => 'Eliminar';

  @override
  String get areYouSureAbsent =>
      '¿Está seguro de marcar a este estudiante como ausente?';

  @override
  String get deleteStudent => 'Eliminar estudiante';

  @override
  String get deleteStudentWarning =>
      '¿Está seguro de eliminar a este estudiante?';

  @override
  String get add => 'Agregar';

  @override
  String get noStudents => 'No hay estudiantes.';

  @override
  String get noStudentsYet =>
      'No hay estudiantes aún. Agregue estudiantes a su cuenta.';

  @override
  String get notesHint => 'Notas: ej. clase, año, etc.';

  @override
  String get rejected => 'Rechazado';

  @override
  String get suspended => 'Suspendido';

  @override
  String get outOfCredit => 'Sin crédito';

  @override
  String get underReview => 'En revisión';

  @override
  String get noGuardians => 'No hay tutores';

  @override
  String get noGuardiansYet =>
      'No hay tutores aún. Agregue tutores a su cuenta.';

  @override
  String get coins => 'Monedas';

  @override
  String get oneCoinInfo =>
      'Una moneda le permite rastrear un estudiante\n por un día.';

  @override
  String get updatingStatus => 'Actualizando estado...';

  @override
  String get absent => 'Ausente';

  @override
  String get notAbsent => 'No ausente';

  @override
  String get areYouSureNotAbsent =>
      '¿Está seguro de marcar a este estudiante como no ausente?';

  @override
  String get studentIsNotAbsent => 'El estudiante no está ausente';

  @override
  String get adjustNotificationSettings =>
      'Ajustar configuración de notificaciones para el estudiante.';

  @override
  String get pickup => 'Recogida';

  @override
  String get dropOff => 'Entrega';

  @override
  String get morning => 'Mañana';

  @override
  String get afternoon => 'Tarde';

  @override
  String get morningBusNotAssigned =>
      'No se asignó autobús de la mañana al estudiante.';

  @override
  String get afternoonBusNotAssigned =>
      'No se asignó autobús de la tarde al estudiante.';

  @override
  String get selectTime => 'Seleccionar hora';

  @override
  String get settings => 'Configuración';

  @override
  String get selectPickupStop => 'Seleccionar parada de recogida';

  @override
  String get selectDropOffStop => 'Seleccionar parada de entrega';

  @override
  String get selectPickupStopStudent =>
      'Seleccionar parada de recogida para este estudiante.';

  @override
  String get selectDropOffStopStudent =>
      'Seleccionar parada de entrega para este estudiante.';

  @override
  String get trackMorningBus => 'Rastrear autobús de la mañana';

  @override
  String get trackAfternoonBus => 'Rastrear autobús de la tarde';

  @override
  String get addGuardian => 'Agregar tutor';

  @override
  String get enterGuardianEmail =>
      'Ingrese el nombre y correo electrónico del tutor.';

  @override
  String get name => 'Nombre';

  @override
  String get confirmEmail => 'Confirmar correo electrónico';

  @override
  String get selectStopForStudent => 'Seleccionar parada para este estudiante.';

  @override
  String get noTripIsAvailable => 'No hay viaje disponible.';

  @override
  String get deleteAllNotifications => 'Eliminar todas las notificaciones';

  @override
  String get printStudentCard => 'Imprimir tarjeta de estudiante';

  @override
  String get printStudentCardMessage =>
      'Recibirá un archivo PDF en su correo electrónico con la tarjeta del estudiante. Imprímala y entréguela al estudiante.';

  @override
  String get requestDeleteAccountMessage =>
      '¿Está seguro de solicitar la eliminación de su cuenta? Si solicita la eliminación, su cuenta se eliminará después de 3 días. Puede cancelar la solicitud si inicia sesión en su cuenta en los próximos 3 días.';

  @override
  String get requestCoins => 'Solicitar monedas';

  @override
  String get emailVerification => 'Verificación de correo electrónico';

  @override
  String get enterCode => 'Ingrese el código enviado a ';

  @override
  String get invalidOtp => 'OTP inválido';

  @override
  String get resendCode => 'Código reenviado';

  @override
  String get back => 'Atrás';

  @override
  String get verify => 'VERIFICAR';

  @override
  String get needHelp => '¿Necesita ayuda? ';

  @override
  String get contactUs => 'Contáctenos';

  @override
  String get languageUpdatedSuccessfully => 'Idioma actualizado correctamente.';
}
