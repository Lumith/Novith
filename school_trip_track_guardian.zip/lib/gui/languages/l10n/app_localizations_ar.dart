// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get students => 'الطلاب';

  @override
  String get notificationSettings => 'إعدادات الإشعارات';

  @override
  String get busArrivedAtPickupLocationNotification =>
      'وصول الحافلة إلى نقطة الالتقاط';

  @override
  String get busArrivedAtDropOffLocationNotification =>
      'وصول الحافلة إلى نقطة النزول';

  @override
  String get busLeftPickupLocationNotification =>
      'مغادرة الحافلة نقطة الالتقاط';

  @override
  String get busLeftDropOffLocationNotification => 'مغادرة الحافلة نقطة النزول';

  @override
  String get busArrivedAtSchoolNotification => 'وصول الحافلة إلى المدرسة';

  @override
  String get busLeftSchoolNotification => 'مغادرة الحافلة المدرسة';

  @override
  String get busNearPickupLocationNotificationByDistance =>
      'الحافلة قريبة من نقطة الالتقاط';

  @override
  String get busNearDropOffLocationNotification =>
      'الحافلة قريبة من نقطة النزول';

  @override
  String get nextStopIsYourPickupLocationNotification =>
      'المحطة التالية هي نقطة الالتقاط الخاصة بك';

  @override
  String get studentIsPickedUpNotification => 'تم اصطحاب الطالب';

  @override
  String get studentIsMissedPickupNotification => 'فوات اصطحاب الطالب';

  @override
  String get pickupNotifications => 'إشعارات الالتقاط';

  @override
  String get dropOffNotifications => 'إشعارات النزول';

  @override
  String get guardians => 'أولياء الأمور';

  @override
  String get myProfile => 'ملفي الشخصي';

  @override
  String get changeLanguage => 'تغيير اللغة';

  @override
  String get aboutApp => 'عن التطبيق';

  @override
  String get linkedDevices => 'الأجهزة المرتبطة';

  @override
  String get devices => 'الأجهزة';

  @override
  String get networkError => 'خطأ في الشبكة';

  @override
  String get anyDevicesYet => 'عذرًا... لا توجد أجهزة بعد.';

  @override
  String get currentDevice => 'الجهاز الحالي';

  @override
  String get cancel => 'إلغاء';

  @override
  String get continueText => 'متابعة';

  @override
  String get termsConditions => 'الشروط والأحكام';

  @override
  String get login => 'تسجيل الدخول';

  @override
  String get logout => 'تسجيل الخروج';

  @override
  String get requestDelete => 'طلب الحذف';

  @override
  String get shareApp => 'شارك هذا التطبيق';

  @override
  String get basicInformation => 'المعلومات الأساسية';

  @override
  String get accountInformation => 'معلومات الحساب';

  @override
  String get save => 'حفظ';

  @override
  String get wallet => 'المحفظة';

  @override
  String get camera => 'الكاميرا';

  @override
  String get gallery => 'المعرض';

  @override
  String get balance => 'الرصيد';

  @override
  String get history => 'السجل';

  @override
  String get myWalletBalance => 'رصيد محفظتي';

  @override
  String get activeTrips => 'الرحلات النشطة';

  @override
  String get trips => 'الرحلات';

  @override
  String get tripTimeline => 'الجدول الزمني للرحلة';

  @override
  String get tripDetails => 'تفاصيل الرحلة';

  @override
  String get startTrip => 'بدء الرحلة';

  @override
  String get ok => 'موافق';

  @override
  String get no => 'لا';

  @override
  String get yes => 'نعم';

  @override
  String get exit => 'خروج';

  @override
  String get forgetOrChangePassword => 'نسيت كلمة المرور أو تغييرها';

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get enterYourEmail => 'أدخل بريدك الإلكتروني';

  @override
  String get welcomeBack => 'مرحبًا بعودتك';

  @override
  String get rememberMe => 'تذكرني';

  @override
  String get dontHaveAccount => 'ليس لديك حساب؟';

  @override
  String get signUp => 'اشتراك';

  @override
  String get logoutWarning => 'هل أنت متأكد أنك تريد تسجيل الخروج؟';

  @override
  String get signOut => 'تسجيل الخروج';

  @override
  String get youNeedToLoginToContinue => 'يجب تسجيل الدخول للمتابعة.';

  @override
  String get emailAddress => 'عنوان البريد الإلكتروني';

  @override
  String get password => 'كلمة المرور';

  @override
  String get confirmPassword => 'تأكيد كلمة المرور';

  @override
  String get signUpText => 'يرجى ملء النموذج أدناه لإنشاء حساب جديد.';

  @override
  String get userName => 'اسم المستخدم';

  @override
  String get pleaseEnterValidEmail => 'يرجى إدخال بريد إلكتروني صالح';

  @override
  String get pleaseEnterYourEmail => 'يرجى إدخال البريد الإلكتروني';

  @override
  String get stops => 'المحطات';

  @override
  String get routes => 'الطرق';

  @override
  String get phoneNumber => 'رقم الهاتف';

  @override
  String get pleaseEnterPhoneNumber => 'يرجى إدخال رقم الهاتف';

  @override
  String get address => 'العنوان';

  @override
  String get pleaseEnterAddress => 'يرجى إدخال عنوانك';

  @override
  String get noStops => 'عذرًا... لم يتم العثور على محطات.';

  @override
  String get noRoutes => 'عذرًا... لم يتم العثور على طرق.';

  @override
  String get warning => 'تحذير';

  @override
  String get areYouSureDeleteDevice => 'هل أنت متأكد من حذف هذا الجهاز؟';

  @override
  String get lastActive => 'نشط آخر مرة ';

  @override
  String get deposit => 'إيداع';

  @override
  String get addMoney => 'إضافة أموال';

  @override
  String get noTransactionsYet => 'عذرًا... لا توجد معاملات بعد.';

  @override
  String get active => 'نشط';

  @override
  String get noTrips => 'عذرًا... لا توجد رحلات.';

  @override
  String get sendComplaint => 'إرسال شكوى';

  @override
  String get enterComplaint => 'أدخل شكواك';

  @override
  String get pleaseEnterComplaint => 'يرجى إدخال شكواك';

  @override
  String get pleaseEnterValidComplaint =>
      'يرجى إدخال شكوى صالحة (أكثر من 10 أحرف)';

  @override
  String get paidOn => 'دفع في ';

  @override
  String get startSearch => 'بدء البحث';

  @override
  String get favorites => 'المفضلة';

  @override
  String get addNew => '+ إضافة جديد';

  @override
  String get lastTrips => 'آخر الرحلات';

  @override
  String get start => 'بداية';

  @override
  String get destination => 'الوجهة';

  @override
  String get go => 'انطلق';

  @override
  String get chooseYourTrip => 'اختر رحلتك';

  @override
  String get book => 'حجز';

  @override
  String get bookTrip => 'حجز رحلة';

  @override
  String get notEnoughMoney => 'ليس لديك رصيد كافٍ في محفظتك.';

  @override
  String get error => 'خطأ';

  @override
  String get areYouSureDeletePlace => 'هل أنت متأكد من حذف هذا المكان؟';

  @override
  String get savePlace => 'حفظ المكان';

  @override
  String get newPlace => 'مكان جديد';

  @override
  String get addFavoritePlace => 'إضافة مكان مفضل';

  @override
  String get editPlace => 'تعديل المكان';

  @override
  String get setAddress => 'تعيين العنوان';

  @override
  String get noTripsMatchYourSearch => 'عذرًا... لا توجد رحلة تطابق بحثك.';

  @override
  String get recentPlaces => 'الأماكن الحديثة';

  @override
  String get noRecentPlacesYet => 'عذرًا... لا توجد أماكن حديثة بعد.';

  @override
  String get areYouSureLogout => 'هل أنت متأكد من تسجيل الخروج؟';

  @override
  String get tripHasEnded => 'انتهت الرحلة';

  @override
  String get tripNotStartedYet => 'لم تبدأ الرحلة بعد';

  @override
  String get resetPassword => 'إعادة تعيين كلمة المرور';

  @override
  String get newAccount => 'حساب جديد';

  @override
  String get favoritePlaces => 'الأماكن المفضلة';

  @override
  String get noFavoritePlacesYet => 'عذرًا... لا توجد أماكن مفضلة بعد.';

  @override
  String get addMoneyToWallet => 'إضافة أموال إلى المحفظة';

  @override
  String get notifications => 'الإشعارات';

  @override
  String get date => 'التاريخ';

  @override
  String get time => 'الوقت';

  @override
  String get from => 'من';

  @override
  String get price => 'السعر';

  @override
  String get ticketDetails => 'تفاصيل التذكرة';

  @override
  String get anyNotificationsYet => 'عذرًا... لا توجد إشعارات بعد.';

  @override
  String get showMore => 'عرض المزيد';

  @override
  String get showLess => 'عرض أقل';

  @override
  String get alert => 'تنبيه';

  @override
  String get markAllNotificationsAsSeen => 'تعليم جميع الإشعارات كمقروءة';

  @override
  String get markAllAsRead => 'تعليم الكل كمقروء';

  @override
  String get newStudent => 'طالب جديد';

  @override
  String get studentName => 'اسم الطالب';

  @override
  String get studentNameRequired => 'اسم الطالب مطلوب';

  @override
  String get studentId => 'معرف الطالب';

  @override
  String get studentIdRequired => 'معرف الطالب مطلوب';

  @override
  String get studentNotes => 'ملاحظات الطالب';

  @override
  String get studentNotesRequired => 'ملاحظات الطالب مطلوبة';

  @override
  String get studentPicture => 'صورة الطالب';

  @override
  String get submit => 'إرسال';

  @override
  String get studentPicRequired => 'صورة الطالب مطلوبة';

  @override
  String get schools => 'المدارس';

  @override
  String get school => 'المدرسة';

  @override
  String get schoolIsRequired => 'المدرسة مطلوبة';

  @override
  String get anySchoolsYet => 'عذرًا... لا توجد مدارس بعد.';

  @override
  String get addStudent => 'إضافة طالب';

  @override
  String get editStudent => 'تعديل الطالب';

  @override
  String get delete => 'حذف';

  @override
  String get areYouSureAbsent =>
      'هل أنت متأكد أنك تريد تعليم هذا الطالب كغائب؟';

  @override
  String get deleteStudent => 'حذف الطالب';

  @override
  String get deleteStudentWarning => 'هل أنت متأكد أنك تريد حذف هذا الطالب؟';

  @override
  String get add => 'إضافة';

  @override
  String get noStudents => 'لا يوجد طلاب.';

  @override
  String get noStudentsYet => 'لا توجد أي طلاب بعد. يرجى إضافة طلاب إلى حسابك.';

  @override
  String get notesHint => 'ملاحظات: مثل الصف، السنة، إلخ.';

  @override
  String get rejected => 'مرفوض';

  @override
  String get suspended => 'موقوف';

  @override
  String get outOfCredit => 'نفد الرصيد';

  @override
  String get underReview => 'قيد المراجعة';

  @override
  String get noGuardians => 'لا يوجد أولياء أمور';

  @override
  String get noGuardiansYet =>
      'لا توجد أي أولياء أمور بعد. يرجى إضافة أولياء أمور إلى حسابك.';

  @override
  String get coins => 'العملات';

  @override
  String get oneCoinInfo => 'تسمح لك عملة واحدة بتتبع طالب واحد\n ليوم واحد.';

  @override
  String get updatingStatus => 'جاري تحديث الحالة...';

  @override
  String get absent => 'غائب';

  @override
  String get notAbsent => 'غير غائب';

  @override
  String get areYouSureNotAbsent =>
      'هل أنت متأكد أنك تريد تعليم هذا الطالب كغير غائب؟';

  @override
  String get studentIsNotAbsent => 'الطالب غير غائب';

  @override
  String get adjustNotificationSettings => 'ضبط إعدادات الإشعارات للطالب.';

  @override
  String get pickup => 'الالتقاط';

  @override
  String get dropOff => 'النزول';

  @override
  String get morning => 'الصباح';

  @override
  String get afternoon => 'بعد الظهر';

  @override
  String get morningBusNotAssigned => 'لم يتم تعيين حافلة الصباح للطالب.';

  @override
  String get afternoonBusNotAssigned => 'لم يتم تعيين حافلة بعد الظهر للطالب.';

  @override
  String get selectTime => 'اختر الوقت';

  @override
  String get settings => 'الإعدادات';

  @override
  String get selectPickupStop => 'اختر محطة الالتقاط';

  @override
  String get selectDropOffStop => 'اختر محطة النزول';

  @override
  String get selectPickupStopStudent => 'اختر محطة الالتقاط لهذا الطالب.';

  @override
  String get selectDropOffStopStudent => 'اختر محطة النزول لهذا الطالب.';

  @override
  String get trackMorningBus => 'تتبع حافلة الصباح';

  @override
  String get trackAfternoonBus => 'تتبع حافلة بعد الظهر';

  @override
  String get addGuardian => 'إضافة ولي أمر';

  @override
  String get enterGuardianEmail =>
      'أدخل اسم وعنوان البريد الإلكتروني لولي الأمر.';

  @override
  String get name => 'الاسم';

  @override
  String get confirmEmail => 'تأكيد البريد الإلكتروني';

  @override
  String get selectStopForStudent => 'اختر المحطة لهذا الطالب.';

  @override
  String get noTripIsAvailable => 'لا توجد رحلة متاحة.';

  @override
  String get deleteAllNotifications => 'حذف جميع الإشعارات';

  @override
  String get printStudentCard => 'طباعة بطاقة الطالب';

  @override
  String get printStudentCardMessage =>
      'ستحصل على ملف PDF على عنوان بريدك الإلكتروني يحتوي على بطاقة الطالب. يرجى طباعتها وتسليمها للطالب.';

  @override
  String get requestDeleteAccountMessage =>
      'هل أنت متأكد أنك تريد طلب حذف الحساب؟ إذا طلبت حذف الحساب، سيتم حذف حسابك بعد 3 أيام. يمكنك إلغاء الطلب إذا قمت بتسجيل الدخول إلى حسابك خلال الأيام الثلاثة القادمة';

  @override
  String get requestCoins => 'طلب عملات';

  @override
  String get emailVerification => 'التحقق من البريد الإلكتروني';

  @override
  String get enterCode => 'أدخل الرمز المرسل إلى ';

  @override
  String get invalidOtp => 'رمز OTP غير صالح';

  @override
  String get resendCode => 'تم إعادة إرسال الرمز';

  @override
  String get back => 'رجوع';

  @override
  String get verify => 'التحقق';

  @override
  String get needHelp => 'تحتاج مساعدة؟';

  @override
  String get contactUs => 'اتصل بنا';

  @override
  String get languageUpdatedSuccessfully => 'تم تحديث اللغة بنجاح.';
}
