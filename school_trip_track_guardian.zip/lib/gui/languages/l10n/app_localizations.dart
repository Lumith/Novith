import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_de.dart';
import 'app_localizations_en.dart';
import 'app_localizations_es.dart';
import 'app_localizations_fr.dart';
import 'app_localizations_hi.dart';
import 'app_localizations_it.dart';
import 'app_localizations_pt.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('de'),
    Locale('en'),
    Locale('es'),
    Locale('fr'),
    Locale('hi'),
    Locale('it'),
    Locale('pt'),
  ];

  /// No description provided for @students.
  ///
  /// In en, this message translates to:
  /// **'Students'**
  String get students;

  /// No description provided for @notificationSettings.
  ///
  /// In en, this message translates to:
  /// **'Notification Settings'**
  String get notificationSettings;

  /// No description provided for @busArrivedAtPickupLocationNotification.
  ///
  /// In en, this message translates to:
  /// **'Bus arrived at pickup location'**
  String get busArrivedAtPickupLocationNotification;

  /// No description provided for @busArrivedAtDropOffLocationNotification.
  ///
  /// In en, this message translates to:
  /// **'Bus arrived at drop off location'**
  String get busArrivedAtDropOffLocationNotification;

  /// No description provided for @busLeftPickupLocationNotification.
  ///
  /// In en, this message translates to:
  /// **'Bus left pickup location'**
  String get busLeftPickupLocationNotification;

  /// No description provided for @busLeftDropOffLocationNotification.
  ///
  /// In en, this message translates to:
  /// **'Bus left drop off location'**
  String get busLeftDropOffLocationNotification;

  /// No description provided for @busArrivedAtSchoolNotification.
  ///
  /// In en, this message translates to:
  /// **'Bus arrived at school'**
  String get busArrivedAtSchoolNotification;

  /// No description provided for @busLeftSchoolNotification.
  ///
  /// In en, this message translates to:
  /// **'Bus left school'**
  String get busLeftSchoolNotification;

  /// No description provided for @busNearPickupLocationNotificationByDistance.
  ///
  /// In en, this message translates to:
  /// **'Bus is near pickup location'**
  String get busNearPickupLocationNotificationByDistance;

  /// No description provided for @busNearDropOffLocationNotification.
  ///
  /// In en, this message translates to:
  /// **'Bus is near drop off location'**
  String get busNearDropOffLocationNotification;

  /// No description provided for @nextStopIsYourPickupLocationNotification.
  ///
  /// In en, this message translates to:
  /// **'Next Stop Is Your Pickup Location'**
  String get nextStopIsYourPickupLocationNotification;

  /// No description provided for @studentIsPickedUpNotification.
  ///
  /// In en, this message translates to:
  /// **'Student is picked up'**
  String get studentIsPickedUpNotification;

  /// No description provided for @studentIsMissedPickupNotification.
  ///
  /// In en, this message translates to:
  /// **'Student is missed pickup'**
  String get studentIsMissedPickupNotification;

  /// No description provided for @pickupNotifications.
  ///
  /// In en, this message translates to:
  /// **'Pickup Notifications'**
  String get pickupNotifications;

  /// No description provided for @dropOffNotifications.
  ///
  /// In en, this message translates to:
  /// **'Drop Off Notifications'**
  String get dropOffNotifications;

  /// No description provided for @guardians.
  ///
  /// In en, this message translates to:
  /// **'Guardians'**
  String get guardians;

  /// No description provided for @myProfile.
  ///
  /// In en, this message translates to:
  /// **'My Profile'**
  String get myProfile;

  /// No description provided for @changeLanguage.
  ///
  /// In en, this message translates to:
  /// **'Change Language'**
  String get changeLanguage;

  /// No description provided for @aboutApp.
  ///
  /// In en, this message translates to:
  /// **'About App'**
  String get aboutApp;

  /// No description provided for @linkedDevices.
  ///
  /// In en, this message translates to:
  /// **'Linked devices'**
  String get linkedDevices;

  /// No description provided for @devices.
  ///
  /// In en, this message translates to:
  /// **'Devices'**
  String get devices;

  /// No description provided for @networkError.
  ///
  /// In en, this message translates to:
  /// **'Network error'**
  String get networkError;

  /// No description provided for @anyDevicesYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any devices yet.'**
  String get anyDevicesYet;

  /// No description provided for @currentDevice.
  ///
  /// In en, this message translates to:
  /// **'Current device'**
  String get currentDevice;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @continueText.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continueText;

  /// No description provided for @termsConditions.
  ///
  /// In en, this message translates to:
  /// **'Terms and Conditions'**
  String get termsConditions;

  /// No description provided for @login.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get login;

  /// No description provided for @logout.
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get logout;

  /// No description provided for @requestDelete.
  ///
  /// In en, this message translates to:
  /// **'Request Delete'**
  String get requestDelete;

  /// No description provided for @shareApp.
  ///
  /// In en, this message translates to:
  /// **'Share this App'**
  String get shareApp;

  /// No description provided for @basicInformation.
  ///
  /// In en, this message translates to:
  /// **'Basic information'**
  String get basicInformation;

  /// No description provided for @accountInformation.
  ///
  /// In en, this message translates to:
  /// **'Account information'**
  String get accountInformation;

  /// No description provided for @save.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// No description provided for @wallet.
  ///
  /// In en, this message translates to:
  /// **'Wallet'**
  String get wallet;

  /// No description provided for @camera.
  ///
  /// In en, this message translates to:
  /// **'Camera'**
  String get camera;

  /// No description provided for @gallery.
  ///
  /// In en, this message translates to:
  /// **'Gallery'**
  String get gallery;

  /// No description provided for @balance.
  ///
  /// In en, this message translates to:
  /// **'Balance'**
  String get balance;

  /// No description provided for @history.
  ///
  /// In en, this message translates to:
  /// **'History'**
  String get history;

  /// No description provided for @myWalletBalance.
  ///
  /// In en, this message translates to:
  /// **'My Wallet Balance'**
  String get myWalletBalance;

  /// No description provided for @activeTrips.
  ///
  /// In en, this message translates to:
  /// **'Active Trips'**
  String get activeTrips;

  /// No description provided for @trips.
  ///
  /// In en, this message translates to:
  /// **'Trips'**
  String get trips;

  /// No description provided for @tripTimeline.
  ///
  /// In en, this message translates to:
  /// **'Trip Timeline'**
  String get tripTimeline;

  /// No description provided for @tripDetails.
  ///
  /// In en, this message translates to:
  /// **'Trip Details'**
  String get tripDetails;

  /// No description provided for @startTrip.
  ///
  /// In en, this message translates to:
  /// **'Start Trip'**
  String get startTrip;

  /// No description provided for @ok.
  ///
  /// In en, this message translates to:
  /// **'OK'**
  String get ok;

  /// No description provided for @no.
  ///
  /// In en, this message translates to:
  /// **'No'**
  String get no;

  /// No description provided for @yes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get yes;

  /// No description provided for @exit.
  ///
  /// In en, this message translates to:
  /// **'Exit'**
  String get exit;

  /// No description provided for @forgetOrChangePassword.
  ///
  /// In en, this message translates to:
  /// **'Forget or change password'**
  String get forgetOrChangePassword;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// No description provided for @enterYourEmail.
  ///
  /// In en, this message translates to:
  /// **'Enter your email'**
  String get enterYourEmail;

  /// No description provided for @welcomeBack.
  ///
  /// In en, this message translates to:
  /// **'Welcome Back'**
  String get welcomeBack;

  /// No description provided for @rememberMe.
  ///
  /// In en, this message translates to:
  /// **'Remember Me'**
  String get rememberMe;

  /// No description provided for @dontHaveAccount.
  ///
  /// In en, this message translates to:
  /// **'Don\'t have an account? '**
  String get dontHaveAccount;

  /// No description provided for @signUp.
  ///
  /// In en, this message translates to:
  /// **'Sign Up'**
  String get signUp;

  /// No description provided for @logoutWarning.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to logout?'**
  String get logoutWarning;

  /// No description provided for @signOut.
  ///
  /// In en, this message translates to:
  /// **'Sign Out'**
  String get signOut;

  /// No description provided for @youNeedToLoginToContinue.
  ///
  /// In en, this message translates to:
  /// **'You need to login to continue.'**
  String get youNeedToLoginToContinue;

  /// No description provided for @emailAddress.
  ///
  /// In en, this message translates to:
  /// **'Email Address'**
  String get emailAddress;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @confirmPassword.
  ///
  /// In en, this message translates to:
  /// **'Confirm Password'**
  String get confirmPassword;

  /// No description provided for @signUpText.
  ///
  /// In en, this message translates to:
  /// **'Please fill in the form below to create a new account.'**
  String get signUpText;

  /// No description provided for @userName.
  ///
  /// In en, this message translates to:
  /// **'User Name'**
  String get userName;

  /// No description provided for @pleaseEnterValidEmail.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid email'**
  String get pleaseEnterValidEmail;

  /// No description provided for @pleaseEnterYourEmail.
  ///
  /// In en, this message translates to:
  /// **'Please enter email'**
  String get pleaseEnterYourEmail;

  /// No description provided for @stops.
  ///
  /// In en, this message translates to:
  /// **'Stops'**
  String get stops;

  /// No description provided for @routes.
  ///
  /// In en, this message translates to:
  /// **'Routes'**
  String get routes;

  /// No description provided for @phoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Phone Number'**
  String get phoneNumber;

  /// No description provided for @pleaseEnterPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Please enter phone number'**
  String get pleaseEnterPhoneNumber;

  /// No description provided for @address.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get address;

  /// No description provided for @pleaseEnterAddress.
  ///
  /// In en, this message translates to:
  /// **'Please enter your address'**
  String get pleaseEnterAddress;

  /// No description provided for @noStops.
  ///
  /// In en, this message translates to:
  /// **'Oops... No stops found.'**
  String get noStops;

  /// No description provided for @noRoutes.
  ///
  /// In en, this message translates to:
  /// **'Oops... No routes found.'**
  String get noRoutes;

  /// No description provided for @warning.
  ///
  /// In en, this message translates to:
  /// **'Warning'**
  String get warning;

  /// No description provided for @areYouSureDeleteDevice.
  ///
  /// In en, this message translates to:
  /// **'Are you sure to delete this device?'**
  String get areYouSureDeleteDevice;

  /// No description provided for @lastActive.
  ///
  /// In en, this message translates to:
  /// **'Last active  '**
  String get lastActive;

  /// No description provided for @deposit.
  ///
  /// In en, this message translates to:
  /// **'Deposit'**
  String get deposit;

  /// No description provided for @addMoney.
  ///
  /// In en, this message translates to:
  /// **'Add Money'**
  String get addMoney;

  /// No description provided for @noTransactionsYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... No transactions yet.'**
  String get noTransactionsYet;

  /// No description provided for @active.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get active;

  /// No description provided for @noTrips.
  ///
  /// In en, this message translates to:
  /// **'Oops... No trips.'**
  String get noTrips;

  /// No description provided for @sendComplaint.
  ///
  /// In en, this message translates to:
  /// **'Send Complaint'**
  String get sendComplaint;

  /// No description provided for @enterComplaint.
  ///
  /// In en, this message translates to:
  /// **'Enter your complaint'**
  String get enterComplaint;

  /// No description provided for @pleaseEnterComplaint.
  ///
  /// In en, this message translates to:
  /// **'Please enter your complaint'**
  String get pleaseEnterComplaint;

  /// No description provided for @pleaseEnterValidComplaint.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid complaint (more than 10 characters)'**
  String get pleaseEnterValidComplaint;

  /// No description provided for @paidOn.
  ///
  /// In en, this message translates to:
  /// **'Paid on '**
  String get paidOn;

  /// No description provided for @startSearch.
  ///
  /// In en, this message translates to:
  /// **'Start search'**
  String get startSearch;

  /// No description provided for @favorites.
  ///
  /// In en, this message translates to:
  /// **'Favorites'**
  String get favorites;

  /// No description provided for @addNew.
  ///
  /// In en, this message translates to:
  /// **'+ Add new'**
  String get addNew;

  /// No description provided for @lastTrips.
  ///
  /// In en, this message translates to:
  /// **'Last Trips'**
  String get lastTrips;

  /// No description provided for @start.
  ///
  /// In en, this message translates to:
  /// **'Start'**
  String get start;

  /// No description provided for @destination.
  ///
  /// In en, this message translates to:
  /// **'Destination'**
  String get destination;

  /// No description provided for @go.
  ///
  /// In en, this message translates to:
  /// **'Go'**
  String get go;

  /// No description provided for @chooseYourTrip.
  ///
  /// In en, this message translates to:
  /// **'Choose your trip'**
  String get chooseYourTrip;

  /// No description provided for @book.
  ///
  /// In en, this message translates to:
  /// **'Book'**
  String get book;

  /// No description provided for @bookTrip.
  ///
  /// In en, this message translates to:
  /// **'Book trip'**
  String get bookTrip;

  /// No description provided for @notEnoughMoney.
  ///
  /// In en, this message translates to:
  /// **'You don\'t have enough money in your wallet.'**
  String get notEnoughMoney;

  /// No description provided for @error.
  ///
  /// In en, this message translates to:
  /// **'Error'**
  String get error;

  /// No description provided for @areYouSureDeletePlace.
  ///
  /// In en, this message translates to:
  /// **'Are you sure to delete this place?'**
  String get areYouSureDeletePlace;

  /// No description provided for @savePlace.
  ///
  /// In en, this message translates to:
  /// **'Save Place'**
  String get savePlace;

  /// No description provided for @newPlace.
  ///
  /// In en, this message translates to:
  /// **'New Place'**
  String get newPlace;

  /// No description provided for @addFavoritePlace.
  ///
  /// In en, this message translates to:
  /// **'Add Favorite Place'**
  String get addFavoritePlace;

  /// No description provided for @editPlace.
  ///
  /// In en, this message translates to:
  /// **'Edit Place'**
  String get editPlace;

  /// No description provided for @setAddress.
  ///
  /// In en, this message translates to:
  /// **'Set Address'**
  String get setAddress;

  /// No description provided for @noTripsMatchYourSearch.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any trip that match your search.'**
  String get noTripsMatchYourSearch;

  /// No description provided for @recentPlaces.
  ///
  /// In en, this message translates to:
  /// **'Recent Places'**
  String get recentPlaces;

  /// No description provided for @noRecentPlacesYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any recent places yet.'**
  String get noRecentPlacesYet;

  /// No description provided for @areYouSureLogout.
  ///
  /// In en, this message translates to:
  /// **'Are you sure to log out?'**
  String get areYouSureLogout;

  /// No description provided for @tripHasEnded.
  ///
  /// In en, this message translates to:
  /// **'Trip has ended'**
  String get tripHasEnded;

  /// No description provided for @tripNotStartedYet.
  ///
  /// In en, this message translates to:
  /// **'Trip has not started yet'**
  String get tripNotStartedYet;

  /// No description provided for @resetPassword.
  ///
  /// In en, this message translates to:
  /// **'Reset Password'**
  String get resetPassword;

  /// No description provided for @newAccount.
  ///
  /// In en, this message translates to:
  /// **'New Account'**
  String get newAccount;

  /// No description provided for @favoritePlaces.
  ///
  /// In en, this message translates to:
  /// **'Favorite Places'**
  String get favoritePlaces;

  /// No description provided for @noFavoritePlacesYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any favorite places yet.'**
  String get noFavoritePlacesYet;

  /// No description provided for @addMoneyToWallet.
  ///
  /// In en, this message translates to:
  /// **'Add Money to Wallet'**
  String get addMoneyToWallet;

  /// No description provided for @notifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get notifications;

  /// No description provided for @date.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get date;

  /// No description provided for @time.
  ///
  /// In en, this message translates to:
  /// **'Time'**
  String get time;

  /// No description provided for @from.
  ///
  /// In en, this message translates to:
  /// **'From'**
  String get from;

  /// No description provided for @price.
  ///
  /// In en, this message translates to:
  /// **'Price'**
  String get price;

  /// No description provided for @ticketDetails.
  ///
  /// In en, this message translates to:
  /// **'Ticket Details'**
  String get ticketDetails;

  /// No description provided for @anyNotificationsYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any notifications yet.'**
  String get anyNotificationsYet;

  /// No description provided for @showMore.
  ///
  /// In en, this message translates to:
  /// **'Show More'**
  String get showMore;

  /// No description provided for @showLess.
  ///
  /// In en, this message translates to:
  /// **'Show Less'**
  String get showLess;

  /// No description provided for @alert.
  ///
  /// In en, this message translates to:
  /// **'Alert'**
  String get alert;

  /// No description provided for @markAllNotificationsAsSeen.
  ///
  /// In en, this message translates to:
  /// **'Mark all notifications as seen'**
  String get markAllNotificationsAsSeen;

  /// No description provided for @markAllAsRead.
  ///
  /// In en, this message translates to:
  /// **'Mark all as read'**
  String get markAllAsRead;

  /// No description provided for @newStudent.
  ///
  /// In en, this message translates to:
  /// **'New Student'**
  String get newStudent;

  /// No description provided for @studentName.
  ///
  /// In en, this message translates to:
  /// **'Student Name'**
  String get studentName;

  /// No description provided for @studentNameRequired.
  ///
  /// In en, this message translates to:
  /// **'Student name is required'**
  String get studentNameRequired;

  /// No description provided for @studentId.
  ///
  /// In en, this message translates to:
  /// **'Student ID'**
  String get studentId;

  /// No description provided for @studentIdRequired.
  ///
  /// In en, this message translates to:
  /// **'Student ID is required'**
  String get studentIdRequired;

  /// No description provided for @studentNotes.
  ///
  /// In en, this message translates to:
  /// **'Student Notes'**
  String get studentNotes;

  /// No description provided for @studentNotesRequired.
  ///
  /// In en, this message translates to:
  /// **'Student notes are required'**
  String get studentNotesRequired;

  /// No description provided for @studentPicture.
  ///
  /// In en, this message translates to:
  /// **'Student Picture'**
  String get studentPicture;

  /// No description provided for @submit.
  ///
  /// In en, this message translates to:
  /// **'Submit'**
  String get submit;

  /// No description provided for @studentPicRequired.
  ///
  /// In en, this message translates to:
  /// **'Student picture is required'**
  String get studentPicRequired;

  /// No description provided for @schools.
  ///
  /// In en, this message translates to:
  /// **'Schools'**
  String get schools;

  /// No description provided for @school.
  ///
  /// In en, this message translates to:
  /// **'School'**
  String get school;

  /// No description provided for @schoolIsRequired.
  ///
  /// In en, this message translates to:
  /// **'School is required'**
  String get schoolIsRequired;

  /// No description provided for @anySchoolsYet.
  ///
  /// In en, this message translates to:
  /// **'Oops... There aren\'t any schools.'**
  String get anySchoolsYet;

  /// No description provided for @addStudent.
  ///
  /// In en, this message translates to:
  /// **'Add Student'**
  String get addStudent;

  /// No description provided for @editStudent.
  ///
  /// In en, this message translates to:
  /// **'Edit Student'**
  String get editStudent;

  /// No description provided for @delete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get delete;

  /// No description provided for @areYouSureAbsent.
  ///
  /// In en, this message translates to:
  /// **'Are you sure that you want to mark this student as absent?'**
  String get areYouSureAbsent;

  /// No description provided for @deleteStudent.
  ///
  /// In en, this message translates to:
  /// **'Delete Student'**
  String get deleteStudent;

  /// No description provided for @deleteStudentWarning.
  ///
  /// In en, this message translates to:
  /// **'Are you sure that you want to delete this student?'**
  String get deleteStudentWarning;

  /// No description provided for @add.
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get add;

  /// No description provided for @noStudents.
  ///
  /// In en, this message translates to:
  /// **'No students.'**
  String get noStudents;

  /// No description provided for @noStudentsYet.
  ///
  /// In en, this message translates to:
  /// **'There aren\'t any students yet. Please add students to your account.'**
  String get noStudentsYet;

  /// No description provided for @notesHint.
  ///
  /// In en, this message translates to:
  /// **'Notes: e.g. class, year, etc.'**
  String get notesHint;

  /// No description provided for @rejected.
  ///
  /// In en, this message translates to:
  /// **'Rejected'**
  String get rejected;

  /// No description provided for @suspended.
  ///
  /// In en, this message translates to:
  /// **'Suspended'**
  String get suspended;

  /// No description provided for @outOfCredit.
  ///
  /// In en, this message translates to:
  /// **'Out of credit'**
  String get outOfCredit;

  /// No description provided for @underReview.
  ///
  /// In en, this message translates to:
  /// **'Under review'**
  String get underReview;

  /// No description provided for @noGuardians.
  ///
  /// In en, this message translates to:
  /// **'No guardians'**
  String get noGuardians;

  /// No description provided for @noGuardiansYet.
  ///
  /// In en, this message translates to:
  /// **'There aren\'t any guardians yet. Please add guardians to your account.'**
  String get noGuardiansYet;

  /// No description provided for @coins.
  ///
  /// In en, this message translates to:
  /// **'Coins'**
  String get coins;

  /// No description provided for @oneCoinInfo.
  ///
  /// In en, this message translates to:
  /// **'One coin allows you to track one student\n for one day.'**
  String get oneCoinInfo;

  /// No description provided for @updatingStatus.
  ///
  /// In en, this message translates to:
  /// **'Updating status...'**
  String get updatingStatus;

  /// No description provided for @absent.
  ///
  /// In en, this message translates to:
  /// **'Absent'**
  String get absent;

  /// No description provided for @notAbsent.
  ///
  /// In en, this message translates to:
  /// **'Not absent'**
  String get notAbsent;

  /// No description provided for @areYouSureNotAbsent.
  ///
  /// In en, this message translates to:
  /// **'Are you sure that you want to mark this student as not absent?'**
  String get areYouSureNotAbsent;

  /// No description provided for @studentIsNotAbsent.
  ///
  /// In en, this message translates to:
  /// **'Student is not absent'**
  String get studentIsNotAbsent;

  /// No description provided for @adjustNotificationSettings.
  ///
  /// In en, this message translates to:
  /// **'Adjust notification settings for student.'**
  String get adjustNotificationSettings;

  /// No description provided for @pickup.
  ///
  /// In en, this message translates to:
  /// **'Pickup'**
  String get pickup;

  /// No description provided for @dropOff.
  ///
  /// In en, this message translates to:
  /// **'Drop Off'**
  String get dropOff;

  /// No description provided for @morning.
  ///
  /// In en, this message translates to:
  /// **'Morning'**
  String get morning;

  /// No description provided for @afternoon.
  ///
  /// In en, this message translates to:
  /// **'Afternoon'**
  String get afternoon;

  /// No description provided for @morningBusNotAssigned.
  ///
  /// In en, this message translates to:
  /// **'Morning bus is not assigned to the student.'**
  String get morningBusNotAssigned;

  /// No description provided for @afternoonBusNotAssigned.
  ///
  /// In en, this message translates to:
  /// **'Afternoon bus is not assigned to the student.'**
  String get afternoonBusNotAssigned;

  /// No description provided for @selectTime.
  ///
  /// In en, this message translates to:
  /// **'Select Time'**
  String get selectTime;

  /// No description provided for @settings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settings;

  /// No description provided for @selectPickupStop.
  ///
  /// In en, this message translates to:
  /// **'Select Pickup Stop'**
  String get selectPickupStop;

  /// No description provided for @selectDropOffStop.
  ///
  /// In en, this message translates to:
  /// **'Select Drop Off Stop'**
  String get selectDropOffStop;

  /// No description provided for @selectPickupStopStudent.
  ///
  /// In en, this message translates to:
  /// **'Select pickup stop for this student.'**
  String get selectPickupStopStudent;

  /// No description provided for @selectDropOffStopStudent.
  ///
  /// In en, this message translates to:
  /// **'Select drop off stop for this student.'**
  String get selectDropOffStopStudent;

  /// No description provided for @trackMorningBus.
  ///
  /// In en, this message translates to:
  /// **'Track Morning Bus'**
  String get trackMorningBus;

  /// No description provided for @trackAfternoonBus.
  ///
  /// In en, this message translates to:
  /// **'Track Afternoon Bus'**
  String get trackAfternoonBus;

  /// No description provided for @addGuardian.
  ///
  /// In en, this message translates to:
  /// **'Add Guardian'**
  String get addGuardian;

  /// No description provided for @enterGuardianEmail.
  ///
  /// In en, this message translates to:
  /// **'Enter name and email address of the guardian.'**
  String get enterGuardianEmail;

  /// No description provided for @name.
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get name;

  /// No description provided for @confirmEmail.
  ///
  /// In en, this message translates to:
  /// **'Confirm Email'**
  String get confirmEmail;

  /// No description provided for @selectStopForStudent.
  ///
  /// In en, this message translates to:
  /// **'Select stop for this student.'**
  String get selectStopForStudent;

  /// No description provided for @noTripIsAvailable.
  ///
  /// In en, this message translates to:
  /// **'No trip is available.'**
  String get noTripIsAvailable;

  /// No description provided for @deleteAllNotifications.
  ///
  /// In en, this message translates to:
  /// **'Delete all notifications'**
  String get deleteAllNotifications;

  /// No description provided for @printStudentCard.
  ///
  /// In en, this message translates to:
  /// **'Print Student Card'**
  String get printStudentCard;

  /// No description provided for @printStudentCardMessage.
  ///
  /// In en, this message translates to:
  /// **'You will get a PDF file at your email address with the student card. Please print it and give it to the student.'**
  String get printStudentCardMessage;

  /// No description provided for @requestDeleteAccountMessage.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to request account deletion? If you request account deletion, your account will be deleted after 3 days. You can cancel the request if you login to your account in the upcoming 3 days'**
  String get requestDeleteAccountMessage;

  /// No description provided for @requestCoins.
  ///
  /// In en, this message translates to:
  /// **'Request Coins'**
  String get requestCoins;

  /// No description provided for @emailVerification.
  ///
  /// In en, this message translates to:
  /// **'Email Verification'**
  String get emailVerification;

  /// No description provided for @enterCode.
  ///
  /// In en, this message translates to:
  /// **'Enter the code sent to '**
  String get enterCode;

  /// No description provided for @invalidOtp.
  ///
  /// In en, this message translates to:
  /// **'Invalid OTP'**
  String get invalidOtp;

  /// No description provided for @resendCode.
  ///
  /// In en, this message translates to:
  /// **'Code resent'**
  String get resendCode;

  /// No description provided for @back.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get back;

  /// No description provided for @verify.
  ///
  /// In en, this message translates to:
  /// **'VERIFY'**
  String get verify;

  /// No description provided for @needHelp.
  ///
  /// In en, this message translates to:
  /// **'Need Help? '**
  String get needHelp;

  /// No description provided for @contactUs.
  ///
  /// In en, this message translates to:
  /// **'Contact Us'**
  String get contactUs;

  /// No description provided for @languageUpdatedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Language updated successfully.'**
  String get languageUpdatedSuccessfully;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>[
    'ar',
    'de',
    'en',
    'es',
    'fr',
    'hi',
    'it',
    'pt',
  ].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar':
      return AppLocalizationsAr();
    case 'de':
      return AppLocalizationsDe();
    case 'en':
      return AppLocalizationsEn();
    case 'es':
      return AppLocalizationsEs();
    case 'fr':
      return AppLocalizationsFr();
    case 'hi':
      return AppLocalizationsHi();
    case 'it':
      return AppLocalizationsIt();
    case 'pt':
      return AppLocalizationsPt();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
