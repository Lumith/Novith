// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get students => 'Élèves';

  @override
  String get notificationSettings => 'Paramètres de notification';

  @override
  String get busArrivedAtPickupLocationNotification =>
      'Le bus est arrivé au point de prise en charge';

  @override
  String get busArrivedAtDropOffLocationNotification =>
      'Le bus est arrivé au point de dépôt';

  @override
  String get busLeftPickupLocationNotification =>
      'Le bus a quitté le point de prise en charge';

  @override
  String get busLeftDropOffLocationNotification =>
      'Le bus a quitté le point de dépôt';

  @override
  String get busArrivedAtSchoolNotification => 'Le bus est arrivé à l\'école';

  @override
  String get busLeftSchoolNotification => 'Le bus a quitté l\'école';

  @override
  String get busNearPickupLocationNotificationByDistance =>
      'Le bus est près du point de prise en charge';

  @override
  String get busNearDropOffLocationNotification =>
      'Le bus est près du point de dépôt';

  @override
  String get nextStopIsYourPickupLocationNotification =>
      'Le prochain arrêt est votre point de prise en charge';

  @override
  String get studentIsPickedUpNotification => 'L\'élève a été pris en charge';

  @override
  String get studentIsMissedPickupNotification =>
      'L\'élève n\'a pas été pris en charge';

  @override
  String get pickupNotifications => 'Notifications de prise en charge';

  @override
  String get dropOffNotifications => 'Notifications de dépôt';

  @override
  String get guardians => 'Responsables';

  @override
  String get myProfile => 'Mon profil';

  @override
  String get changeLanguage => 'Changer la langue';

  @override
  String get aboutApp => 'À propos de l\'application';

  @override
  String get linkedDevices => 'Appareils liés';

  @override
  String get devices => 'Appareils';

  @override
  String get networkError => 'Erreur réseau';

  @override
  String get anyDevicesYet => 'Oups... Aucun appareil pour le moment.';

  @override
  String get currentDevice => 'Appareil actuel';

  @override
  String get cancel => 'Annuler';

  @override
  String get continueText => 'Continuer';

  @override
  String get termsConditions => 'Conditions générales';

  @override
  String get login => 'Connexion';

  @override
  String get logout => 'Déconnexion';

  @override
  String get requestDelete => 'Demander la suppression';

  @override
  String get shareApp => 'Partager cette application';

  @override
  String get basicInformation => 'Informations de base';

  @override
  String get accountInformation => 'Informations du compte';

  @override
  String get save => 'Enregistrer';

  @override
  String get wallet => 'Portefeuille';

  @override
  String get camera => 'Caméra';

  @override
  String get gallery => 'Galerie';

  @override
  String get balance => 'Solde';

  @override
  String get history => 'Historique';

  @override
  String get myWalletBalance => 'Solde de mon portefeuille';

  @override
  String get activeTrips => 'Trajets actifs';

  @override
  String get trips => 'Trajets';

  @override
  String get tripTimeline => 'Chronologie du trajet';

  @override
  String get tripDetails => 'Détails du trajet';

  @override
  String get startTrip => 'Démarrer le trajet';

  @override
  String get ok => 'OK';

  @override
  String get no => 'Non';

  @override
  String get yes => 'Oui';

  @override
  String get exit => 'Quitter';

  @override
  String get forgetOrChangePassword => 'Mot de passe oublié ou changement';

  @override
  String get email => 'E-mail';

  @override
  String get enterYourEmail => 'Entrez votre e-mail';

  @override
  String get welcomeBack => 'Bon retour';

  @override
  String get rememberMe => 'Se souvenir de moi';

  @override
  String get dontHaveAccount => 'Vous n\'avez pas de compte ? ';

  @override
  String get signUp => 'S\'inscrire';

  @override
  String get logoutWarning => 'Êtes-vous sûr de vouloir vous déconnecter ?';

  @override
  String get signOut => 'Se déconnecter';

  @override
  String get youNeedToLoginToContinue =>
      'Vous devez vous connecter pour continuer.';

  @override
  String get emailAddress => 'Adresse e-mail';

  @override
  String get password => 'Mot de passe';

  @override
  String get confirmPassword => 'Confirmer le mot de passe';

  @override
  String get signUpText =>
      'Veuillez remplir le formulaire ci-dessous pour créer un nouveau compte.';

  @override
  String get userName => 'Nom d\'utilisateur';

  @override
  String get pleaseEnterValidEmail => 'Veuillez entrer un e-mail valide';

  @override
  String get pleaseEnterYourEmail => 'Veuillez entrer votre e-mail';

  @override
  String get stops => 'Arrêts';

  @override
  String get routes => 'Itinéraires';

  @override
  String get phoneNumber => 'Numéro de téléphone';

  @override
  String get pleaseEnterPhoneNumber =>
      'Veuillez entrer votre numéro de téléphone';

  @override
  String get address => 'Adresse';

  @override
  String get pleaseEnterAddress => 'Veuillez entrer votre adresse';

  @override
  String get noStops => 'Oups... Aucun arrêt trouvé.';

  @override
  String get noRoutes => 'Oups... Aucun itinéraire trouvé.';

  @override
  String get warning => 'Avertissement';

  @override
  String get areYouSureDeleteDevice =>
      'Êtes-vous sûr de vouloir supprimer cet appareil ?';

  @override
  String get lastActive => 'Dernière activité ';

  @override
  String get deposit => 'Dépôt';

  @override
  String get addMoney => 'Ajouter de l\'argent';

  @override
  String get noTransactionsYet => 'Oups... Aucune transaction pour le moment.';

  @override
  String get active => 'Actif';

  @override
  String get noTrips => 'Oups... Aucun trajet.';

  @override
  String get sendComplaint => 'Envoyer une plainte';

  @override
  String get enterComplaint => 'Saisissez votre plainte';

  @override
  String get pleaseEnterComplaint => 'Veuillez saisir votre plainte';

  @override
  String get pleaseEnterValidComplaint =>
      'Veuillez saisir une plainte valide (plus de 10 caractères)';

  @override
  String get paidOn => 'Payé le ';

  @override
  String get startSearch => 'Commencer la recherche';

  @override
  String get favorites => 'Favoris';

  @override
  String get addNew => '+ Ajouter';

  @override
  String get lastTrips => 'Derniers trajets';

  @override
  String get start => 'Départ';

  @override
  String get destination => 'Destination';

  @override
  String get go => 'Aller';

  @override
  String get chooseYourTrip => 'Choisissez votre trajet';

  @override
  String get book => 'Réserver';

  @override
  String get bookTrip => 'Réserver un trajet';

  @override
  String get notEnoughMoney =>
      'Vous n\'avez pas assez d\'argent dans votre portefeuille.';

  @override
  String get error => 'Erreur';

  @override
  String get areYouSureDeletePlace =>
      'Êtes-vous sûr de vouloir supprimer cet endroit ?';

  @override
  String get savePlace => 'Enregistrer le lieu';

  @override
  String get newPlace => 'Nouveau lieu';

  @override
  String get addFavoritePlace => 'Ajouter un lieu favori';

  @override
  String get editPlace => 'Modifier le lieu';

  @override
  String get setAddress => 'Définir l\'adresse';

  @override
  String get noTripsMatchYourSearch =>
      'Oups... Aucun trajet ne correspond à votre recherche.';

  @override
  String get recentPlaces => 'Lieux récents';

  @override
  String get noRecentPlacesYet => 'Oups... Aucun lieu récent pour le moment.';

  @override
  String get areYouSureLogout => 'Êtes-vous sûr de vouloir vous déconnecter ?';

  @override
  String get tripHasEnded => 'Le trajet est terminé';

  @override
  String get tripNotStartedYet => 'Le trajet n\'a pas encore commencé';

  @override
  String get resetPassword => 'Réinitialiser le mot de passe';

  @override
  String get newAccount => 'Nouveau compte';

  @override
  String get favoritePlaces => 'Lieux favoris';

  @override
  String get noFavoritePlacesYet => 'Oups... Aucun lieu favori pour le moment.';

  @override
  String get addMoneyToWallet => 'Ajouter de l\'argent au portefeuille';

  @override
  String get notifications => 'Notifications';

  @override
  String get date => 'Date';

  @override
  String get time => 'Heure';

  @override
  String get from => 'De';

  @override
  String get price => 'Prix';

  @override
  String get ticketDetails => 'Détails du billet';

  @override
  String get anyNotificationsYet =>
      'Oups... Aucune notification pour le moment.';

  @override
  String get showMore => 'Voir plus';

  @override
  String get showLess => 'Voir moins';

  @override
  String get alert => 'Alerte';

  @override
  String get markAllNotificationsAsSeen =>
      'Marquer toutes les notifications comme vues';

  @override
  String get markAllAsRead => 'Tout marquer comme lu';

  @override
  String get newStudent => 'Nouvel élève';

  @override
  String get studentName => 'Nom de l\'élève';

  @override
  String get studentNameRequired => 'Le nom de l\'élève est obligatoire';

  @override
  String get studentId => 'ID de l\'élève';

  @override
  String get studentIdRequired => 'L\'ID de l\'élève est obligatoire';

  @override
  String get studentNotes => 'Notes sur l\'élève';

  @override
  String get studentNotesRequired => 'Les notes sur l\'élève sont obligatoires';

  @override
  String get studentPicture => 'Photo de l\'élève';

  @override
  String get submit => 'Soumettre';

  @override
  String get studentPicRequired => 'La photo de l\'élève est obligatoire';

  @override
  String get schools => 'Écoles';

  @override
  String get school => 'École';

  @override
  String get schoolIsRequired => 'L\'école est obligatoire';

  @override
  String get anySchoolsYet => 'Oups... Aucune école pour le moment.';

  @override
  String get addStudent => 'Ajouter un élève';

  @override
  String get editStudent => 'Modifier l\'élève';

  @override
  String get delete => 'Supprimer';

  @override
  String get areYouSureAbsent =>
      'Êtes-vous sûr de vouloir marquer cet élève comme absent ?';

  @override
  String get deleteStudent => 'Supprimer l\'élève';

  @override
  String get deleteStudentWarning =>
      'Êtes-vous sûr de vouloir supprimer cet élève ?';

  @override
  String get add => 'Ajouter';

  @override
  String get noStudents => 'Aucun élève.';

  @override
  String get noStudentsYet =>
      'Il n\'y a encore aucun élève. Veuillez ajouter des élèves à votre compte.';

  @override
  String get notesHint => 'Notes : ex. classe, année, etc.';

  @override
  String get rejected => 'Rejeté';

  @override
  String get suspended => 'Suspendu';

  @override
  String get outOfCredit => 'Solde insuffisant';

  @override
  String get underReview => 'En cours d\'examen';

  @override
  String get noGuardians => 'Aucun responsable';

  @override
  String get noGuardiansYet =>
      'Il n\'y a encore aucun responsable. Veuillez ajouter des responsables à votre compte.';

  @override
  String get coins => 'Pièces';

  @override
  String get oneCoinInfo =>
      'Une pièce vous permet de suivre un élève\n pendant un jour.';

  @override
  String get updatingStatus => 'Mise à jour du statut...';

  @override
  String get absent => 'Absent';

  @override
  String get notAbsent => 'Non absent';

  @override
  String get areYouSureNotAbsent =>
      'Êtes-vous sûr de vouloir marquer cet élève comme non absent ?';

  @override
  String get studentIsNotAbsent => 'L\'élève n\'est pas absent';

  @override
  String get adjustNotificationSettings =>
      'Ajuster les paramètres de notification pour l\'élève.';

  @override
  String get pickup => 'Prise en charge';

  @override
  String get dropOff => 'Dépôt';

  @override
  String get morning => 'Matin';

  @override
  String get afternoon => 'Après-midi';

  @override
  String get morningBusNotAssigned =>
      'Aucun bus du matin n\'est assigné à l\'élève.';

  @override
  String get afternoonBusNotAssigned =>
      'Aucun bus d\'après-midi n\'est assigné à l\'élève.';

  @override
  String get selectTime => 'Sélectionner l\'heure';

  @override
  String get settings => 'Paramètres';

  @override
  String get selectPickupStop => 'Sélectionner l\'arrêt de prise en charge';

  @override
  String get selectDropOffStop => 'Sélectionner l\'arrêt de dépôt';

  @override
  String get selectPickupStopStudent =>
      'Sélectionner l\'arrêt de prise en charge pour cet élève.';

  @override
  String get selectDropOffStopStudent =>
      'Sélectionner l\'arrêt de dépôt pour cet élève.';

  @override
  String get trackMorningBus => 'Suivre le bus du matin';

  @override
  String get trackAfternoonBus => 'Suivre le bus d\'après-midi';

  @override
  String get addGuardian => 'Ajouter un responsable';

  @override
  String get enterGuardianEmail =>
      'Entrez le nom et l\'adresse e-mail du responsable.';

  @override
  String get name => 'Nom';

  @override
  String get confirmEmail => 'Confirmer l\'e-mail';

  @override
  String get selectStopForStudent => 'Sélectionner un arrêt pour cet élève.';

  @override
  String get noTripIsAvailable => 'Aucun trajet disponible.';

  @override
  String get deleteAllNotifications => 'Supprimer toutes les notifications';

  @override
  String get printStudentCard => 'Imprimer la carte d\'élève';

  @override
  String get printStudentCardMessage =>
      'Vous recevrez un fichier PDF à votre adresse e-mail avec la carte d\'élève. Veuillez l\'imprimer et la remettre à l\'élève.';

  @override
  String get requestDeleteAccountMessage =>
      'Êtes-vous sûr de vouloir demander la suppression du compte ? Si vous demandez la suppression, votre compte sera supprimé après 3 jours. Vous pouvez annuler la demande si vous vous connectez à votre compte dans les 3 prochains jours.';

  @override
  String get requestCoins => 'Demander des pièces';

  @override
  String get emailVerification => 'Vérification de l\'e-mail';

  @override
  String get enterCode => 'Entrez le code envoyé à ';

  @override
  String get invalidOtp => 'OTP invalide';

  @override
  String get resendCode => 'Code renvoyé';

  @override
  String get back => 'Retour';

  @override
  String get verify => 'VÉRIFIER';

  @override
  String get needHelp => 'Besoin d\'aide ? ';

  @override
  String get contactUs => 'Contactez-nous';

  @override
  String get languageUpdatedSuccessfully => 'Langue mise à jour avec succès.';
}
