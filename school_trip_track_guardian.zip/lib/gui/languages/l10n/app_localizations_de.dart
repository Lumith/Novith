// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for German (`de`).
class AppLocalizationsDe extends AppLocalizations {
  AppLocalizationsDe([String locale = 'de']) : super(locale);

  @override
  String get students => 'Studenten';

  @override
  String get notificationSettings => 'Notification Settings';

  @override
  String get busArrivedAtPickupLocationNotification =>
      'Bus arrived at pickup location';

  @override
  String get busArrivedAtDropOffLocationNotification =>
      'Bus arrived at drop off location';

  @override
  String get busLeftPickupLocationNotification => 'Bus left pickup location';

  @override
  String get busLeftDropOffLocationNotification => 'Bus left drop off location';

  @override
  String get busArrivedAtSchoolNotification => 'Bus arrived at school';

  @override
  String get busLeftSchoolNotification => 'Bus left school';

  @override
  String get busNearPickupLocationNotificationByDistance =>
      'Bus is near pickup location';

  @override
  String get busNearDropOffLocationNotification =>
      'Bus is near drop off location';

  @override
  String get nextStopIsYourPickupLocationNotification =>
      'Next Stop Is Your Pickup Location';

  @override
  String get studentIsPickedUpNotification => 'Student is picked up';

  @override
  String get studentIsMissedPickupNotification => 'Student is missed pickup';

  @override
  String get pickupNotifications => 'Pickup Notifications';

  @override
  String get dropOffNotifications => 'Drop Off Notifications';

  @override
  String get guardians => 'Wächter';

  @override
  String get myProfile => 'mein Profil';

  @override
  String get changeLanguage => 'Sprache ändern';

  @override
  String get aboutApp => 'Über die App';

  @override
  String get linkedDevices => 'Verknüpfte Geräte';

  @override
  String get devices => 'Geräte';

  @override
  String get networkError => 'Netzwerkfehler';

  @override
  String get anyDevicesYet => 'Oops... Noch keine Geräte';

  @override
  String get currentDevice => 'Aktuelles Gerät';

  @override
  String get cancel => 'Abbrechen';

  @override
  String get continueText => 'Weiter';

  @override
  String get termsConditions => 'Geschäftsbedingungen';

  @override
  String get login => 'Anmelden';

  @override
  String get logout => 'Abmelden';

  @override
  String get requestDelete => 'Request Delete';

  @override
  String get shareApp => 'App teilen';

  @override
  String get basicInformation => 'Grundinformationen';

  @override
  String get accountInformation => 'Kontoinformationen';

  @override
  String get save => 'Speichern';

  @override
  String get wallet => 'Brieftasche';

  @override
  String get camera => 'Kamera';

  @override
  String get gallery => 'Galerie';

  @override
  String get balance => 'Guthaben';

  @override
  String get history => 'Geschichte';

  @override
  String get myWalletBalance => 'Mein Brieftaschenguthaben';

  @override
  String get activeTrips => 'Aktive Reisen';

  @override
  String get trips => 'Reisen';

  @override
  String get tripTimeline => 'Reisezeitplan';

  @override
  String get tripDetails => 'Reisedetails';

  @override
  String get startTrip => 'Reise starten';

  @override
  String get ok => 'OK';

  @override
  String get no => 'No';

  @override
  String get yes => 'Yes';

  @override
  String get exit => 'Ausgang';

  @override
  String get forgetOrChangePassword => 'Passwort vergessen oder ändern';

  @override
  String get email => 'Email';

  @override
  String get enterYourEmail => 'Geben Sie Ihre E-Mail-Adresse ein';

  @override
  String get welcomeBack => 'Willkommen zurück';

  @override
  String get rememberMe => 'Erinnere dich an mich';

  @override
  String get dontHaveAccount => 'Haben Sie kein Konto? ';

  @override
  String get signUp => 'Anmelden';

  @override
  String get logoutWarning => 'Möchten Sie sich wirklich abmelden?';

  @override
  String get signOut => 'Ausloggen';

  @override
  String get youNeedToLoginToContinue =>
      'Sie müssen sich anmelden, um fortzufahren';

  @override
  String get emailAddress => 'E-Mail-Addresse';

  @override
  String get password => 'Passwort';

  @override
  String get confirmPassword => 'Bestätige das Passwort';

  @override
  String get signUpText =>
      'Bitte füllen Sie das untenstehende Formular aus, um ein neues Konto zu erstellen.';

  @override
  String get userName => 'Benutzername';

  @override
  String get pleaseEnterValidEmail =>
      'Bitte geben Sie eine gültige E-Mail-Adresse ein';

  @override
  String get pleaseEnterYourEmail => 'Bitte geben Sie Ihre E-Mail-Adresse ein';

  @override
  String get stops => 'Stops';

  @override
  String get routes => 'Routen';

  @override
  String get phoneNumber => 'Telefonnummer';

  @override
  String get pleaseEnterPhoneNumber => 'Bitte geben Sie Ihre Telefonnummer ein';

  @override
  String get address => 'Adresse';

  @override
  String get pleaseEnterAddress => 'Bitte geben Sie Ihre Adresse ein';

  @override
  String get noStops => 'Keine Haltestellen gefunden.';

  @override
  String get noRoutes => 'Keine Routen gefunden.';

  @override
  String get warning => 'Warnung';

  @override
  String get areYouSureDeleteDevice =>
      'Möchten Sie dieses Gerät wirklich löschen?';

  @override
  String get lastActive => 'Zuletzt aktiv ';

  @override
  String get deposit => 'Anzahlung';

  @override
  String get addMoney => 'Geld hinzufügen';

  @override
  String get noTransactionsYet => 'Noch keine Transaktionen';

  @override
  String get active => 'Aktiv';

  @override
  String get noTrips => 'Keine Reisen';

  @override
  String get sendComplaint => 'Beschwerde senden';

  @override
  String get enterComplaint => 'Beschwerde eingeben';

  @override
  String get pleaseEnterComplaint => 'Bitte geben Sie Ihre Beschwerde ein';

  @override
  String get pleaseEnterValidComplaint =>
      'Bitte geben Sie eine gültige Beschwerde ein (mehr als 10 Zeichen)';

  @override
  String get paidOn => 'Bezahlt am ';

  @override
  String get startSearch => 'Suche starten';

  @override
  String get favorites => 'Favoriten';

  @override
  String get addNew => '+ Hinzufügen';

  @override
  String get lastTrips => 'Letzte Reisen';

  @override
  String get start => 'Start';

  @override
  String get destination => 'Ziel';

  @override
  String get go => 'Los';

  @override
  String get chooseYourTrip => 'Wählen Sie Ihre Reise';

  @override
  String get book => 'Buch';

  @override
  String get bookTrip => 'Reise buchen';

  @override
  String get notEnoughMoney =>
      'Sie haben nicht genug Geld in Ihrer Brieftasche.';

  @override
  String get error => 'Fehler';

  @override
  String get areYouSureDeletePlace =>
      'Möchten Sie diesen Ort wirklich löschen?';

  @override
  String get savePlace => 'Ort speichern';

  @override
  String get newPlace => 'Neuer Ort';

  @override
  String get addFavoritePlace => 'Fügen Sie Ihren Lieblingsort hinzu';

  @override
  String get editPlace => 'Ort bearbeiten';

  @override
  String get setAddress => 'Adresse festlegen';

  @override
  String get noTripsMatchYourSearch => 'Keine Reisen entsprechen Ihrer Suche';

  @override
  String get recentPlaces => 'Letzte Orte';

  @override
  String get noRecentPlacesYet =>
      'Es sind noch keine aktuellen Orte vorhanden.';

  @override
  String get areYouSureLogout => 'Möchten Sie sich wirklich abmelden?';

  @override
  String get tripHasEnded => 'Die Reise ist beendet';

  @override
  String get tripNotStartedYet => 'Die Reise hat noch nicht begonnen';

  @override
  String get resetPassword => 'Passwort zurücksetzen';

  @override
  String get newAccount => 'Neues Konto';

  @override
  String get favoritePlaces => 'Lieblingsorte';

  @override
  String get noFavoritePlacesYet =>
      'Es sind noch keine Lieblingsorte vorhanden.';

  @override
  String get addMoneyToWallet => 'Geldbörse aufladen';

  @override
  String get notifications => 'Benachrichtigungen';

  @override
  String get date => 'Datum';

  @override
  String get time => 'Zeit';

  @override
  String get from => 'Von';

  @override
  String get price => 'Preis';

  @override
  String get ticketDetails => 'Einzelheiten zum Ticket';

  @override
  String get anyNotificationsYet => 'Oops... Noch keine Benachrichtigungen';

  @override
  String get showMore => 'Mehr anzeigen';

  @override
  String get showLess => 'Weniger anzeigen';

  @override
  String get alert => 'Alarm';

  @override
  String get markAllNotificationsAsSeen =>
      'Markieren Sie alle Benachrichtigungen als gesehen';

  @override
  String get markAllAsRead => 'Markiere alle als gelesen';

  @override
  String get newStudent => 'New Student';

  @override
  String get studentName => 'Student Name';

  @override
  String get studentNameRequired => 'Student name is required';

  @override
  String get studentId => 'Student ID';

  @override
  String get studentIdRequired => 'Student ID is required';

  @override
  String get studentNotes => 'Student Notes';

  @override
  String get studentNotesRequired => 'Student notes are required';

  @override
  String get studentPicture => 'Student Picture';

  @override
  String get submit => 'Submit';

  @override
  String get studentPicRequired => 'Student picture is required';

  @override
  String get schools => 'Schools';

  @override
  String get school => 'School';

  @override
  String get schoolIsRequired => 'School is required';

  @override
  String get anySchoolsYet => 'Oops... There aren\'t any schools.';

  @override
  String get addStudent => 'Add Student';

  @override
  String get editStudent => 'Edit Student';

  @override
  String get delete => 'Delete';

  @override
  String get areYouSureAbsent =>
      'Are you sure that you want to mark this student as absent?';

  @override
  String get deleteStudent => 'Delete Student';

  @override
  String get deleteStudentWarning =>
      'Are you sure that you want to delete this student?';

  @override
  String get add => 'Add';

  @override
  String get noStudents => 'No students.';

  @override
  String get noStudentsYet =>
      'There aren\'t any students yet. Please add students to your account.';

  @override
  String get notesHint => 'Notes: e.g. class, year, etc.';

  @override
  String get rejected => 'Rejected';

  @override
  String get suspended => 'Suspended';

  @override
  String get outOfCredit => 'Out of credit';

  @override
  String get underReview => 'Under review';

  @override
  String get noGuardians => 'No guardians';

  @override
  String get noGuardiansYet =>
      'There aren\'t any guardians yet. Please add guardians to your account.';

  @override
  String get coins => 'Coins';

  @override
  String get oneCoinInfo =>
      'One coin allows you to track one student\n for one day.';

  @override
  String get updatingStatus => 'Updating status...';

  @override
  String get absent => 'Absent';

  @override
  String get notAbsent => 'Not absent';

  @override
  String get areYouSureNotAbsent =>
      'Are you sure that you want to mark this student as not absent?';

  @override
  String get studentIsNotAbsent => 'Student is not absent';

  @override
  String get adjustNotificationSettings =>
      'Adjust notification settings for student.';

  @override
  String get pickup => 'Pickup';

  @override
  String get dropOff => 'Drop Off';

  @override
  String get morning => 'Morning';

  @override
  String get afternoon => 'Afternoon';

  @override
  String get morningBusNotAssigned =>
      'Morning bus is not assigned to the student.';

  @override
  String get afternoonBusNotAssigned =>
      'Afternoon bus is not assigned to the student.';

  @override
  String get selectTime => 'Select Time';

  @override
  String get settings => 'Settings';

  @override
  String get selectPickupStop => 'Select Pickup Stop';

  @override
  String get selectDropOffStop => 'Select Drop Off Stop';

  @override
  String get selectPickupStopStudent => 'Select pickup stop for this student.';

  @override
  String get selectDropOffStopStudent =>
      'Select drop off stop for this student.';

  @override
  String get trackMorningBus => 'Track Morning Bus';

  @override
  String get trackAfternoonBus => 'Track Afternoon Bus';

  @override
  String get addGuardian => 'Add Guardian';

  @override
  String get enterGuardianEmail =>
      'Enter name and email address of the guardian.';

  @override
  String get name => 'Name';

  @override
  String get confirmEmail => 'Confirm Email';

  @override
  String get selectStopForStudent => 'Select stop for this student.';

  @override
  String get noTripIsAvailable => 'No trip is available.';

  @override
  String get deleteAllNotifications => 'Delete all notifications';

  @override
  String get printStudentCard => 'Print Student Card';

  @override
  String get printStudentCardMessage =>
      'You will get a PDF file at your email address with the student card. Please print it and give it to the student.';

  @override
  String get requestDeleteAccountMessage =>
      'Are you sure you want to request account deletion? If you request account deletion, your account will be deleted after 3 days. You can cancel the request if you login to your account in the upcoming 3 days';

  @override
  String get requestCoins => 'Request Coins';

  @override
  String get emailVerification => 'Email Verification';

  @override
  String get enterCode => 'Enter the code sent to ';

  @override
  String get invalidOtp => 'Invalid OTP';

  @override
  String get resendCode => 'Code resent';

  @override
  String get back => 'Back';

  @override
  String get verify => 'VERIFY';

  @override
  String get needHelp => 'Need Help? ';

  @override
  String get contactUs => 'Contact Us';

  @override
  String get languageUpdatedSuccessfully => 'Sprache erfolgreich aktualisiert.';
}
