// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Portuguese (`pt`).
class AppLocalizationsPt extends AppLocalizations {
  AppLocalizationsPt([String locale = 'pt']) : super(locale);

  @override
  String get students => 'Alunos';

  @override
  String get notificationSettings => 'Configurações de notificação';

  @override
  String get busArrivedAtPickupLocationNotification =>
      'O transporte chegou ao local de embarque';

  @override
  String get busArrivedAtDropOffLocationNotification =>
      'O transporte chegou ao local de desembarque';

  @override
  String get busLeftPickupLocationNotification =>
      'Local de embarque do transporte à esquerda';

  @override
  String get busLeftDropOffLocationNotification =>
      'Local de parada do transporte à esquerda';

  @override
  String get busArrivedAtSchoolNotification => 'O transporte chegou na escola';

  @override
  String get busLeftSchoolNotification => 'O transporte saiu da escola';

  @override
  String get busNearPickupLocationNotificationByDistance =>
      'O transporte está próximo ao local de partida';

  @override
  String get busNearDropOffLocationNotification =>
      'O transporte está próximo ao local de entrega';

  @override
  String get nextStopIsYourPickupLocationNotification =>
      'A próxima parada é o seu local de embarque';

  @override
  String get studentIsPickedUpNotification => 'Aluno embarcou';

  @override
  String get studentIsMissedPickupNotification => 'Aluno perdeu o embarque';

  @override
  String get pickupNotifications => 'Notificações de partida';

  @override
  String get dropOffNotifications => 'Notificações de entrega';

  @override
  String get guardians => 'Responsáveis';

  @override
  String get myProfile => 'Meu perfil';

  @override
  String get changeLanguage => 'Mudar idioma';

  @override
  String get aboutApp => 'Sobre o App';

  @override
  String get linkedDevices => 'Dispositivos vinculados';

  @override
  String get devices => 'Dispositivos';

  @override
  String get networkError => 'Erro de rede';

  @override
  String get anyDevicesYet => 'Ops... Ainda não existem dispositivos.';

  @override
  String get currentDevice => 'Dispositivo atual';

  @override
  String get cancel => 'Cancelar';

  @override
  String get continueText => 'Continue';

  @override
  String get termsConditions => 'Termos & Condições';

  @override
  String get login => 'Login';

  @override
  String get logout => 'Sair';

  @override
  String get requestDelete => 'Solicitar exclusão';

  @override
  String get shareApp => 'Compartilhe este App';

  @override
  String get basicInformation => 'Informação básica';

  @override
  String get accountInformation => 'Informação da conta';

  @override
  String get save => 'Salvar';

  @override
  String get wallet => 'Carteira';

  @override
  String get camera => 'Camera';

  @override
  String get gallery => 'Gallery';

  @override
  String get balance => 'Balanço';

  @override
  String get history => 'Histórico';

  @override
  String get myWalletBalance => 'Balanço da minha carteira';

  @override
  String get activeTrips => 'Viagens ativas';

  @override
  String get trips => 'Viagens';

  @override
  String get tripTimeline => 'Cronograma da viagem';

  @override
  String get tripDetails => 'Detalhes da viagem';

  @override
  String get startTrip => 'Iniciar viagem';

  @override
  String get ok => 'OK';

  @override
  String get no => 'Não';

  @override
  String get yes => 'Sim';

  @override
  String get exit => 'Saída';

  @override
  String get forgetOrChangePassword => 'Esquecer ou alterar a senha';

  @override
  String get email => 'Email';

  @override
  String get enterYourEmail => 'Digite seu e-mail';

  @override
  String get welcomeBack => 'Bem vindo(a)!';

  @override
  String get rememberMe => 'Lembre de mim';

  @override
  String get dontHaveAccount => 'Não tem uma conta?';

  @override
  String get signUp => 'Inscrever-se';

  @override
  String get logoutWarning => 'Tem certeza que deseja sair?';

  @override
  String get signOut => 'Sair';

  @override
  String get youNeedToLoginToContinue =>
      'Você precisa fazer login para continuar.';

  @override
  String get emailAddress => 'Endereço de email';

  @override
  String get password => 'Senha';

  @override
  String get confirmPassword => 'Confirme sua senha';

  @override
  String get signUpText =>
      'Por favor preencha o formulário abaixo para criar uma nova conta.';

  @override
  String get userName => 'Nome de usuário';

  @override
  String get pleaseEnterValidEmail => 'Por favor digite um email válido';

  @override
  String get pleaseEnterYourEmail => 'Por favor insira o e-mail';

  @override
  String get stops => 'Paradas';

  @override
  String get routes => 'Rotas';

  @override
  String get phoneNumber => 'Número de telefone';

  @override
  String get pleaseEnterPhoneNumber => 'Por favor insira o número de telefone';

  @override
  String get address => 'Endereço';

  @override
  String get pleaseEnterAddress => 'Por favor insira seu endereço';

  @override
  String get noStops => 'Ops... Nenhuma parada encontrada.';

  @override
  String get noRoutes => 'Ops... Nenhuma rota encontrada.';

  @override
  String get warning => 'Aviso';

  @override
  String get areYouSureDeleteDevice =>
      'Tem certeza de que deseja excluir este dispositivo?';

  @override
  String get lastActive => 'Ativo pela última vez';

  @override
  String get deposit => 'Depósito';

  @override
  String get addMoney => 'Adicionar dinheiro';

  @override
  String get noTransactionsYet => 'Ops... Nenhuma transação ainda.';

  @override
  String get active => 'Ativo';

  @override
  String get noTrips => 'Ops... Sem viagens.';

  @override
  String get sendComplaint => 'Enviar reclamação';

  @override
  String get enterComplaint => 'Insira sua reclamação';

  @override
  String get pleaseEnterComplaint => 'Por favor insira sua reclamação';

  @override
  String get pleaseEnterValidComplaint =>
      'Insira uma reclamação válida (mais de 10 caracteres)';

  @override
  String get paidOn => 'Pago em';

  @override
  String get startSearch => 'Começe a pesquisar';

  @override
  String get favorites => 'Favoritos';

  @override
  String get addNew => '+ Add novo';

  @override
  String get lastTrips => 'Últimas viagens';

  @override
  String get start => 'Começar';

  @override
  String get destination => 'Destino';

  @override
  String get go => 'Ir';

  @override
  String get chooseYourTrip => 'Escolha sua viagem';

  @override
  String get book => 'Reserva';

  @override
  String get bookTrip => 'Reservar viagem';

  @override
  String get notEnoughMoney =>
      'Você não tem dinheiro suficiente em sua carteira.';

  @override
  String get error => 'Erro';

  @override
  String get areYouSureDeletePlace =>
      'Tem certeza de que deseja excluir este lugar?';

  @override
  String get savePlace => 'Salvar lugar';

  @override
  String get newPlace => 'Novo lugar';

  @override
  String get addFavoritePlace => 'Add lugar favorito';

  @override
  String get editPlace => 'Editar lugar';

  @override
  String get setAddress => 'Definir endereço';

  @override
  String get noTripsMatchYourSearch =>
      'Ops... Não há nenhuma viagem que corresponda à sua pesquisa.';

  @override
  String get recentPlaces => 'Lugares recentes';

  @override
  String get noRecentPlacesYet => 'Ops... Ainda não há lugares recentes.';

  @override
  String get areYouSureLogout => 'Tem certeza de que deseja sair?';

  @override
  String get tripHasEnded => 'A viagem terminou';

  @override
  String get tripNotStartedYet => 'A viagem ainda não começou';

  @override
  String get resetPassword => 'Redefinir senha';

  @override
  String get newAccount => 'Nova conta';

  @override
  String get favoritePlaces => 'Lugares favoritos';

  @override
  String get noFavoritePlacesYet => 'Ops... Ainda não há lugares favoritos.';

  @override
  String get addMoneyToWallet => 'Add dinheiro à carteira';

  @override
  String get notifications => 'Notificações';

  @override
  String get date => 'Data';

  @override
  String get time => 'Tempo';

  @override
  String get from => 'De';

  @override
  String get price => 'Preço';

  @override
  String get ticketDetails => 'Detalhes do ticket';

  @override
  String get anyNotificationsYet => 'Ops... Ainda não há notificações.';

  @override
  String get showMore => 'Mostre mais';

  @override
  String get showLess => 'Mostre menos';

  @override
  String get alert => 'Alerta';

  @override
  String get markAllNotificationsAsSeen =>
      'Marcar todas as notificações como vistas';

  @override
  String get markAllAsRead => 'Marcar tudo como lido';

  @override
  String get newStudent => 'Novo aluno';

  @override
  String get studentName => 'Nome do aluno';

  @override
  String get studentNameRequired => 'O nome do aluno é obrigatório';

  @override
  String get studentId => 'ID do aluno';

  @override
  String get studentIdRequired => ' ID do aluno é obrigatório';

  @override
  String get studentNotes => 'Observações do aluno';

  @override
  String get studentNotesRequired => 'Observações do aluno é obrigatório';

  @override
  String get studentPicture => 'Foto do aluno';

  @override
  String get submit => 'Enviar';

  @override
  String get studentPicRequired => 'Foto do aluno é obrigatório';

  @override
  String get schools => 'Escolas';

  @override
  String get school => 'Escola';

  @override
  String get schoolIsRequired => 'Escola é obrigatório';

  @override
  String get anySchoolsYet => 'Ops... Não há escolas.';

  @override
  String get addStudent => 'Adicionar aluno';

  @override
  String get editStudent => 'Editar aluno';

  @override
  String get delete => 'Deletar';

  @override
  String get areYouSureAbsent =>
      'Tem certeza de que deseja marcar este aluno como ausente?';

  @override
  String get deleteStudent => 'Deletar aluno';

  @override
  String get deleteStudentWarning =>
      'Tem certeza de que deseja excluir este aluno?';

  @override
  String get add => 'Adicionar';

  @override
  String get noStudents => 'Nenhum aluno.';

  @override
  String get noStudentsYet =>
      'Ainda não há alunos. Por favor, adicione alunos à sua conta.';

  @override
  String get notesHint => 'Observações: ex. classe, ano, etc.';

  @override
  String get rejected => 'Rejeitado';

  @override
  String get suspended => 'Suspenso';

  @override
  String get outOfCredit => 'Sem crédito';

  @override
  String get underReview => 'Em revisão';

  @override
  String get noGuardians => 'Nenhum responsável.';

  @override
  String get noGuardiansYet =>
      'Ainda não há responsáveis. Por favor, adicione responsáveis à sua conta.';

  @override
  String get coins => 'Moedas';

  @override
  String get oneCoinInfo =>
      'Uma moeda permite que você rastreie um aluno\n por um dia.';

  @override
  String get updatingStatus => 'Atualizando status...';

  @override
  String get absent => 'Ausente';

  @override
  String get notAbsent => 'Não ausente';

  @override
  String get areYouSureNotAbsent =>
      'Tem certeza de que deseja marcar este aluno como não ausente?';

  @override
  String get studentIsNotAbsent => 'O aluno não está ausente';

  @override
  String get adjustNotificationSettings =>
      'Ajustar configurações de notificação';

  @override
  String get pickup => 'Embarque';

  @override
  String get dropOff => 'Desembarque';

  @override
  String get morning => 'Manhã';

  @override
  String get afternoon => 'Tarde';

  @override
  String get morningBusNotAssigned =>
      'Manhã ônibus não está atribuído ao aluno.';

  @override
  String get afternoonBusNotAssigned =>
      'Tarde ônibus não está atribuído ao aluno.';

  @override
  String get selectTime => 'Selecione o tempo';

  @override
  String get settings => 'Configurações';

  @override
  String get selectPickupStop => 'Selecione a parada de embarque';

  @override
  String get selectDropOffStop => 'Selecione a parada de desembarque';

  @override
  String get selectPickupStopStudent =>
      'Selecione a parada de embarque para este aluno.';

  @override
  String get selectDropOffStopStudent =>
      'Selecione a parada de desembarque para este aluno.';

  @override
  String get trackMorningBus => 'Rastrear ônibus da manhã';

  @override
  String get trackAfternoonBus => 'Rastrear ônibus da tarde';

  @override
  String get addGuardian => 'Adicionar responsável';

  @override
  String get enterGuardianEmail => 'Insira o e-mail do responsável';

  @override
  String get name => 'Nome';

  @override
  String get confirmEmail => 'Confirme o e-mail';

  @override
  String get selectStopForStudent => 'Selecione a parada para este aluno.';

  @override
  String get noTripIsAvailable => 'Nenhuma viagem disponível.';

  @override
  String get deleteAllNotifications => 'Excluir todas as notificações';

  @override
  String get printStudentCard => 'Imprimir cartão do aluno';

  @override
  String get printStudentCardMessage =>
      'Você receberá um arquivo PDF no seu endereço de e-mail com o cartão do aluno. Por favor, imprima e entregue ao aluno.';

  @override
  String get requestDeleteAccountMessage =>
      'Tem certeza de que deseja solicitar a exclusão da conta? Se você solicitar a exclusão da conta, sua conta será excluída após 3 dias. Você pode cancelar a solicitação se fizer login em sua conta nos próximos 3 dias';

  @override
  String get requestCoins => 'Request Coins';

  @override
  String get emailVerification => 'Email Verification';

  @override
  String get enterCode => 'Enter the code sent to ';

  @override
  String get invalidOtp => 'Invalid OTP';

  @override
  String get resendCode => 'Code resent';

  @override
  String get back => 'Back';

  @override
  String get verify => 'VERIFY';

  @override
  String get needHelp => 'Need Help? ';

  @override
  String get contactUs => 'Contact Us';

  @override
  String get languageUpdatedSuccessfully => 'Idioma atualizado com sucesso.';
}
