import 'package:flutter/material.dart';

abstract class SchoolFromToWidgetChild extends StatelessWidget {
  const SchoolFromToWidgetChild({super.key});
  @override
  double get width;
}