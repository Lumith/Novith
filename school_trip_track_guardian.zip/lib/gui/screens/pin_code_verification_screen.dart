import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../../main.dart';
import '../../services/service_locator.dart';
import '../../utils/app_theme.dart';
import '../../view_models/this_application_view_model.dart';
import '../languages/language_constants.dart';

class PinCodeVerificationScreen extends StatefulWidget {
  const PinCodeVerificationScreen({
    Key? key,
    this.emailAddress, this.nextScreen,
  }) : super(key: key);

  final String? emailAddress;
  final Widget? nextScreen;

  @override
  State<PinCodeVerificationScreen> createState() =>
      _PinCodeVerificationScreenState();
}

class _PinCodeVerificationScreenState extends State<PinCodeVerificationScreen> {
  TextEditingController textEditingController = TextEditingController();

  // ignore: close_sinks
  StreamController<ErrorAnimationType>? errorController;

  ThisApplicationViewModel thisAppModel = serviceLocator<ThisApplicationViewModel>();

  bool hasError = false;
  bool loading = false;
  String currentText = "";
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    errorController = StreamController<ErrorAnimationType>();
    super.initState();
  }

  @override
  void dispose() {
    errorController!.close();

    super.dispose();
  }

  // snackBar Widget
  snackBar(String? message) {
    return ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message!),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: GestureDetector(
        onTap: () {},
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: ListView(
            children: <Widget>[
              SizedBox(height: 60.h),
              SizedBox(
                height: MediaQuery.of(context).size.height / 3,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(30),
                  child: Image.asset(
                    'assets/images/otp.png',
                    fit: BoxFit.scaleDown,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0),
                child: Text(
                  translation(context)?.emailVerification ?? 'Email Verification',
                  style: AppTheme.textPrimaryLarge,
                  textAlign: TextAlign.center,
                ),
              ),
              Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 30.0, vertical: 8),
                child: RichText(
                  text: TextSpan(
                    text: translation(context)?.enterCode ?? 'Enter the code sent to ',
                    children: [
                      TextSpan(
                        text: "${widget.emailAddress}",
                        style: AppTheme.textPrimaryMedium,
                      ),
                    ],
                    style: AppTheme.textGreySmall,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(
                height: 20.h,
              ),
              Form(
                key: formKey,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 8.0,
                    horizontal: 30,
                  ),
                  child: PinCodeTextField(
                    appContext: context,
                    pastedTextStyle: TextStyle(
                      color: Colors.green.shade600,
                      fontWeight: FontWeight.bold,
                    ),
                    length: 6,
                    obscureText: false,
                    animationType: AnimationType.fade,
                    pinTheme: PinTheme(
                      shape: PinCodeFieldShape.underline,
                      // borderRadius: BorderRadius.circular(5),
                      fieldHeight: 50,
                      fieldWidth: 40,
                      activeFillColor: Colors.white,
                      inactiveColor: Colors.black,
                      inactiveFillColor: AppTheme.backgroundColor,
                      selectedFillColor: AppTheme.backgroundColor,
                    ),
                    cursorColor: Colors.black,
                    animationDuration: const Duration(milliseconds: 300),
                    enableActiveFill: true,
                    errorAnimationController: errorController,
                    controller: textEditingController,
                    keyboardType: TextInputType.number,
                    onCompleted: (v) {
                      debugPrint("Completed");
                    },
                    // onTap: () {
                    //   print("Pressed");
                    // },
                    onChanged: (value) {
                      debugPrint(value);
                      setState(() {
                        currentText = value;
                      });
                    },
                    beforeTextPaste: (text) {
                      debugPrint("Allowing to paste $text");
                      //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                      //but you can show anything you want here, like your pop up saying wrong paste format or etc
                      return true;
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.center,
              //   children: [
              //     Text(
              //       translation(context)?.didntReceiveCode ?? 'Didn\'t receive the code?',
              //       style: AppTheme.textGreySmall,
              //     ),
              //     TextButton(
              //       onPressed: () => snackBar(translation(context)?.resendCode ?? 'Code resent'),
              //       child: Text(
              //         translation(context)?.resend ?? 'Resend',
              //         style: AppTheme.textSecondaryMedium,
              //       ),
              //     )
              //   ],
              // ),
              SizedBox(
                height: 15.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  OutlinedButton(
                    onPressed: () {
                      //go back
                      Navigator.pop(context);
                    },
                    style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      side: const BorderSide(color: AppTheme.secondary, width: 2),
                      padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
                    ),
                    child: Text(
                      translation(context)?.back ?? 'Back',
                      style: AppTheme.textPrimaryMedium,
                    ),
                  ),
                  const SizedBox(width: 50),
                  ElevatedButton(
                    onPressed: () {
                      formKey.currentState!.validate();
                      // conditions for validating
                      if (currentText.length != 6) {
                        errorController!.add(ErrorAnimationType
                            .shake); // Triggering error shake animation
                        setState(() => hasError = true);
                      } else {
                        setState(
                              () {
                            hasError = false;
                            loading = true;
                          },
                        );
                        thisAppModel.verifyOtpEndpoint(currentText).then((value) {
                          if(value != null && value == true) {
                            snackBar("OTP Verified!!");
                            if (widget.nextScreen != null) {
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const MyHomePage()),
                                    (Route<dynamic> route) => false,
                              );
                            }
                            else {
                              Navigator.pop(
                                  context
                              );
                            }
                          }
                          else {
                            snackBar(translation(context)?.invalidOtp ?? 'Invalid OTP');
                            errorController!.add(ErrorAnimationType
                                .shake); // Triggering error shake animation
                            setState(() {
                              loading = false;
                              hasError = true;
                            });
                          }
                        });
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.secondary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
                    ),
                    child: Wrap(
                      children: [
                        Text(
                          translation(context)?.verify ?? 'Verify',
                          style: AppTheme.textWhiteMedium,
                        ),
                        //circle spinner if loading
                        loading?
                        Padding(
                          padding: const EdgeInsets.only(left: 10.0),
                          child: SizedBox(
                            height: 20.h,
                            width: 20.w,
                            child: const CircularProgressIndicator(
                              color: Colors.white,
                            ),
                          ),
                        ): Container(),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}