#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/media/dev/c75d3241-da08-456c-9c48-1024723bc892/home/dev/flutter_linux_3.35.3-stable/flutter"
export "FLUTTER_APPLICATION_PATH=/home/dev/Documents/Projects/SchoolTripTrack/Flutter3.35.3/school_trip_track_guardian"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
